import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.c641e8148a604e67b3e685f6a4963ac8',
  appName: 'A Lovable project',
  webDir: 'dist',
  server: {
    url: 'https://c641e814-8a60-4e67-b3e6-85f6a4963ac8.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  bundledWebRuntime: false
};

export default config;