-- Permitir acesso público às tabelas necesssárias para o sistema de login customizado

-- Para tabela usuarios (sistema legado) - permitir SELECT público para login
DROP POLICY IF EXISTS "Permitir acesso para login" ON public.usuarios;
CREATE POLICY "Permitir acesso público para login" 
ON public.usuarios 
FOR SELECT 
TO public
USING (true);

-- Para tabela profiles - permitir acesso público para login e cadastro
DROP POLICY IF EXISTS "Users can view own profile or admins view all" ON public.profiles;
CREATE POLICY "Acesso público para autenticação" 
ON public.profiles 
FOR SELECT 
TO public
USING (true);

DROP POLICY IF EXISTS "Anyone can create profiles" ON public.profiles;
CREATE POLICY "Permitir cadastro público" 
ON public.profiles 
FOR INSERT 
TO public
WITH CHECK (true);