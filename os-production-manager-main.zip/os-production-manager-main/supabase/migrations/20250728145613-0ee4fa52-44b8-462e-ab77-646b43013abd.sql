-- Fix RLS policies for sheet_sync_log to allow authenticated users to read
DROP POLICY IF EXISTS "Admins can view sync log" ON public.sheet_sync_log;
DROP POLICY IF EXISTS "Admins can manage sync log" ON public.sheet_sync_log;

-- Allow authenticated users to view sync log (for analytics page)
CREATE POLICY "Authenticated users can view sync log" 
ON public.sheet_sync_log 
FOR SELECT 
TO authenticated
USING (true);

-- Only admins can manage (insert/update/delete) sync log
CREATE POLICY "Admins can manage sync log" 
ON public.sheet_sync_log 
FOR ALL 
TO authenticated
USING (get_current_user_role() = 'admin')
WITH CHECK (get_current_user_role() = 'admin');

-- Fix profiles policies to allow proper querying
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;

-- Allow admins to view all profiles and authenticated users to search by nome_completo
CREATE POLICY "Allow profile queries" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (
  auth.uid() = user_id OR 
  get_current_user_role() = 'admin' OR
  auth.uid() IS NOT NULL
);