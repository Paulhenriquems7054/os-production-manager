-- Fix profiles policies to handle users without auth.uid() (like 'administrador')
DROP POLICY IF EXISTS "Allow profile queries" ON public.profiles;

-- Create a more permissive policy for profile queries that allows:
-- 1. Users to view their own profile
-- 2. Admins to view all profiles
-- 3. Anyone to query by nome_completo for login purposes
CREATE POLICY "Allow profile access" 
ON public.profiles 
FOR SELECT 
TO authenticated, anon
USING (
  user_id IS NULL OR 
  auth.uid() = user_id OR 
  get_current_user_role() = 'admin'
);