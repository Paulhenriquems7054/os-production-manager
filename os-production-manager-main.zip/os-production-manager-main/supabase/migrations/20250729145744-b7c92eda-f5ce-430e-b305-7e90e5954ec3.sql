-- Update RLS policy for production_records to allow inserts with local authentication
DROP POLICY IF EXISTS "Users can create production records" ON public.production_records;

CREATE POLICY "Users can create production records" 
ON public.production_records 
FOR INSERT 
WITH CHECK (true);

-- Update RLS policy for viewing to allow authenticated users to see all records
DROP POLICY IF EXISTS "Authenticated users can view own production records" ON public.production_records;

CREATE POLICY "Authenticated users can view production records" 
ON public.production_records 
FOR SELECT 
USING (true);