-- Remover todas as políticas da tabela service_orders primeiro
DROP POLICY IF EXISTS "Supervisors and admins can view all orders" ON public.service_orders;
DROP POLICY IF EXISTS "Supervisors and admins can update all orders" ON public.service_orders;
DROP POLICY IF EXISTS "Supervisors and admins can delete orders" ON public.service_orders;
DROP POLICY IF EXISTS "Authenticated users can view own orders" ON public.service_orders;
DROP POLICY IF EXISTS "Authenticated users can update orders" ON public.service_orders;
DROP POLICY IF EXISTS "Users can create their own orders" ON public.service_orders;

-- Agora alterar o tipo da coluna user_id para TEXT
ALTER TABLE public.service_orders ALTER COLUMN user_id TYPE TEXT;

-- Recriar as políticas com suporte a usuários locais
CREATE POLICY "Allow authenticated users to create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text) OR 
  (user_id LIKE 'local-%')
);

CREATE POLICY "Users can view orders based on auth type" 
ON public.service_orders 
FOR SELECT 
USING (
  -- Usuários Supabase podem ver suas próprias ordens
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text) OR
  -- Supervisores e admins podem ver todas
  (get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text])) OR
  -- Para usuários locais, permitir visualização (será filtrado no frontend)
  (user_id LIKE 'local-%')
);

CREATE POLICY "Users can update orders based on auth type" 
ON public.service_orders 
FOR UPDATE 
USING (
  -- Usuários Supabase podem atualizar suas próprias ordens
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text) OR
  -- Supervisores e admins podem atualizar todas
  (get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text])) OR
  -- Para usuários locais, permitir atualização (será filtrado no frontend)
  (user_id LIKE 'local-%')
);

CREATE POLICY "Supervisors and admins can delete orders" 
ON public.service_orders 
FOR DELETE 
USING (get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text]));