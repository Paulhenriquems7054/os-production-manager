-- Ajustar políticas RLS para permitir usuários anônimos criarem ordens
DROP POLICY IF EXISTS "Users can create their own orders" ON public.service_orders;
DROP POLICY IF EXISTS "Allow insert for authorized users" ON public.service_orders;

-- Nova política mais permissiva para criação de ordens
CREATE POLICY "Allow authenticated users to create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (true);

-- Garantir que usuários podem ver suas próprias ordens ou qualquer uma se for anônimo
DROP POLICY IF EXISTS "Users can view their own orders" ON public.service_orders;

CREATE POLICY "Users can view orders" 
ON public.service_orders 
FOR SELECT 
USING (
  CASE 
    WHEN auth.uid() IS NULL THEN true  -- Usuários anônimos podem ver tudo
    ELSE auth.uid() = user_id OR get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text])
  END
);

-- Permitir atualizações para usuários autenticados ou anônimos
DROP POLICY IF EXISTS "Users can update their own orders" ON public.service_orders;

CREATE POLICY "Users can update orders" 
ON public.service_orders 
FOR UPDATE 
USING (
  CASE 
    WHEN auth.uid() IS NULL THEN true  -- Usuários anônimos podem atualizar
    ELSE auth.uid() = user_id OR get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text])
  END
);