-- Corrigir políticas RLS na tabela profiles para permitir criação de usuários
-- Remover a política problemática e criar uma nova que permita inserts apropriados

-- Primeiro, vamos dropar as políticas existentes problemáticas
DROP POLICY IF EXISTS "Allow profile creation during authentication" ON public.profiles;
DROP POLICY IF EXISTS "Allow profile access" ON public.profiles;

-- Criar nova política para permitir criação de perfis
CREATE POLICY "Allow profile creation" 
ON public.profiles 
FOR INSERT 
WITH CHECK (true);

-- Política para visualização de perfis
CREATE POLICY "Users can view profiles" 
ON public.profiles 
FOR SELECT 
USING (
  (auth.uid() IS NOT NULL AND auth.uid() = user_id) OR 
  (auth.uid() IS NULL) OR 
  (get_current_user_role() = 'admin')
);

-- Política para atualização de perfis
CREATE POLICY "Users can update own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id OR get_current_user_role() = 'admin');