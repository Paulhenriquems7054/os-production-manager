-- Enable RLS on service_orders table (it seems to be missing)
ALTER TABLE public.service_orders ENABLE ROW LEVEL SECURITY;

-- Create a security definer function to get current user role
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE user_id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Create policy for supervisors and admins to view all orders
CREATE POLICY "Supervisors and admins can view all orders" ON public.service_orders
FOR SELECT USING (
  public.get_current_user_role() IN ('supervisor', 'admin') OR auth.uid() = user_id
);

-- Create policy for supervisors and admins to update all orders
CREATE POLICY "Supervisors and admins can update all orders" ON public.service_orders
FOR UPDATE USING (
  public.get_current_user_role() IN ('supervisor', 'admin') OR auth.uid() = user_id
);

-- Create policy for supervisors and admins to delete orders
CREATE POLICY "Supervisors and admins can delete orders" ON public.service_orders
FOR DELETE USING (
  public.get_current_user_role() IN ('supervisor', 'admin')
);