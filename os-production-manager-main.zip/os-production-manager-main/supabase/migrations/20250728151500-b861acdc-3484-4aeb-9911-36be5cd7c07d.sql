-- Verificar e corrigir a policy de INSERT para service_orders
-- A policy atual deve funcionar, mas vamos garantir que está correta

-- Primeiro, vamos dropar a policy existente para recriar
DROP POLICY IF EXISTS "Authenticated users can create orders" ON public.service_orders;

-- Recriar a policy de INSERT mais robusta
CREATE POLICY "Users can create their own orders" 
ON public.service_orders 
FOR INSERT 
TO authenticated
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  user_id = auth.uid()
);

-- Verificar se a coluna user_id pode ser NOT NULL (recomendado para RLS)
-- Se não estiver como NOT NULL, vamos alterar para garantir integridade
ALTER TABLE public.service_orders 
ALTER COLUMN user_id SET NOT NULL;