-- Inserir usuário desenvolvedor na tabela profiles
INSERT INTO public.profiles (user_id, nome_completo, department, role, senha_hash)
VALUES (null, 'desenvolvedor', 'desenvolvedor', 'admin', 'dev123');