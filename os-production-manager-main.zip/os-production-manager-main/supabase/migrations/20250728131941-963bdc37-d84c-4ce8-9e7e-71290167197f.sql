-- Fix service_orders insert policy to allow authenticated users to create their own orders
DROP POLICY IF EXISTS "Authenticated users can create orders" ON public.service_orders;

-- Create proper policy that allows authenticated users to create orders
CREATE POLICY "Authenticated users can create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  user_id = auth.uid()
);