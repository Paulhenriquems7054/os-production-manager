-- Remover política restritiva atual
DROP POLICY IF EXISTS "Permitir login de usuários" ON public.usuarios;

-- Criar política que permite SELECT sem autenticação (apenas para login)
CREATE POLICY "Permitir acesso para login" 
ON public.usuarios 
FOR SELECT 
USING (true);