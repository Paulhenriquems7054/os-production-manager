-- Atualizar tabela service_orders para corresponder aos componentes existentes
ALTER TABLE public.service_orders 
  DROP COLUMN client_name,
  DROP COLUMN client_phone,
  DROP COLUMN client_email,
  DROP COLUMN service_type,
  DROP COLUMN description,
  DROP COLUMN priority,
  DROP COLUMN estimated_hours,
  DROP COLUMN actual_hours,
  DROP COLUMN total_cost,
  DROP COLUMN scheduled_date,
  DROP COLUMN completed_date,
  DROP COLUMN notes;

-- Adicionar colunas que os componentes esperam
ALTER TABLE public.service_orders 
  ADD COLUMN employee TEXT NOT NULL DEFAULT '',
  ADD COLUMN quantity INTEGER NOT NULL DEFAULT 1,
  ADD COLUMN category_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN category_name TEXT NOT NULL DEFAULT '',
  ADD COLUMN piece TEXT NOT NULL DEFAULT '',
  ADD COLUMN service_id TEXT NOT NULL DEFAULT '',
  ADD COLUMN service_name TEXT NOT NULL DEFAULT '',
  ADD COLUMN start_time TEXT NOT NULL DEFAULT '',
  ADD COLUMN end_time TEXT NOT NULL DEFAULT '',
  ADD COLUMN observations TEXT,
  ADD COLUMN approved_by TEXT,
  ADD COLUMN approved_at TIMESTAMP WITH TIME ZONE,
  ADD COLUMN rejected_by TEXT,
  ADD COLUMN rejected_at TIMESTAMP WITH TIME ZONE,
  ADD COLUMN rework_count INTEGER DEFAULT 0,
  ADD COLUMN rework_history JSONB DEFAULT '[]'::jsonb;

-- Atualizar status enum para incluir todos os valores esperados
ALTER TABLE public.service_orders 
  DROP CONSTRAINT IF EXISTS service_orders_status_check;

-- Renomear created_at para createdAt para corresponder aos componentes
ALTER TABLE public.service_orders 
  RENAME COLUMN created_at TO "createdAt";

-- Atualizar tabela production_records para corresponder aos componentes existentes
ALTER TABLE public.production_records 
  DROP COLUMN employee_name,
  DROP COLUMN function_role,
  DROP COLUMN service_type,
  DROP COLUMN quantity,
  DROP COLUMN date,
  DROP COLUMN start_time,
  DROP COLUMN end_time,
  DROP COLUMN notes;

-- Adicionar colunas que os componentes esperam
ALTER TABLE public.production_records 
  ADD COLUMN timestamp TEXT NOT NULL DEFAULT '',
  ADD COLUMN executante TEXT NOT NULL DEFAULT '',
  ADD COLUMN funcao TEXT NOT NULL DEFAULT '',
  ADD COLUMN supervisor TEXT NOT NULL DEFAULT '',
  ADD COLUMN suspensor_tc1a TEXT,
  ADD COLUMN suspensor_t16 TEXT,
  ADD COLUMN anel_suspensor TEXT,
  ADD COLUMN luva TEXT,
  ADD COLUMN niple_longo TEXT,
  ADD COLUMN difusor TEXT,
  ADD COLUMN packer TEXT,
  ADD COLUMN valvula_dreno TEXT,
  ADD COLUMN valvula_check TEXT,
  ADD COLUMN desareador TEXT,
  ADD COLUMN tubo_filtro TEXT,
  ADD COLUMN acoplamentos TEXT,
  ADD COLUMN cabeca_descarga TEXT,
  ADD COLUMN outro_servico TEXT,
  ADD COLUMN colaborador_outro_servico TEXT CHECK (colaborador_outro_servico IN ('SIM', 'NÃO')),
  ADD COLUMN observacoes TEXT;