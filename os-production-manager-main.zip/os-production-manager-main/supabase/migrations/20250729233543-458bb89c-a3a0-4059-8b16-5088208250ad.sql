-- Adicionar usuário supervisor para facilitar o login
INSERT INTO usuarios (nome, senha, role, departamento) 
VALUES ('supervisor', 'super123', 'supervisor', 'supervisão');

INSERT INTO profiles (nome_completo, senha_hash, role, department) 
VALUES ('supervisor', 'super123', 'supervisor', 'supervisão');