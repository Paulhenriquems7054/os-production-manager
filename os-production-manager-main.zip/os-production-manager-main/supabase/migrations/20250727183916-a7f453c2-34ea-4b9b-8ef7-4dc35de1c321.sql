-- Add missing SELECT policy for regular users to view their own service orders
CREATE POLICY "Users can view their own orders" ON public.service_orders
FOR SELECT 
USING (auth.uid() = user_id);