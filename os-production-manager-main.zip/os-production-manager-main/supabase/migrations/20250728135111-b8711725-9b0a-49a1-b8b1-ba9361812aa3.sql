-- Fix RLS policy for profiles table to allow system user creation
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

-- Create a more permissive policy for profile creation during authentication
CREATE POLICY "Allow profile creation during authentication" ON public.profiles
FOR INSERT 
WITH CHECK (
  auth.uid() = user_id OR 
  auth.uid() IS NULL -- Allow system/function level inserts
);

-- Fix the handle_new_user function to work properly with RLS
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
BEGIN
  INSERT INTO public.profiles (user_id, nome_completo, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    'user'
  );
  RETURN NEW;
END;
$function$;