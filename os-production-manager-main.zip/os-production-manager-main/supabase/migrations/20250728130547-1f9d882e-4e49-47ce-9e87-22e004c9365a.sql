-- FINAL SECURITY HARDENING - Fix all remaining critical vulnerabilities

-- 1. Remove dangerous "System can manage employees" policy that allows anonymous access
DROP POLICY IF EXISTS "System can manage employees" ON public.employees;

-- Replace with admin-only management
CREATE POLICY "Admins can manage employees" 
ON public.employees 
FOR ALL 
USING (get_current_user_role() = 'admin');

-- 2. Fix material_movements anonymous access
DROP POLICY IF EXISTS "Everyone can view material movements" ON public.material_movements;

-- Replace with authenticated-only access
CREATE POLICY "Authenticated users can view material movements" 
ON public.material_movements 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- 3. Remove dangerous "System can manage sync log" policy
DROP POLICY IF EXISTS "System can manage sync log" ON public.sheet_sync_log;

-- Replace with admin-only management
CREATE POLICY "Admins can manage sync log" 
ON public.sheet_sync_log 
FOR ALL 
USING (get_current_user_role() = 'admin');

-- 4. Remove duplicate/old conflicting policies on profiles
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;

-- 5. Fix notifications anonymous access - replace with proper authentication checks
DROP POLICY IF EXISTS "System can create notifications for users" ON public.notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can view their own notifications" ON public.notifications;

-- Secure notifications policies
CREATE POLICY "Authenticated users can view own notifications" 
ON public.notifications 
FOR SELECT 
USING (auth.uid() IS NOT NULL AND auth.uid() = user_id);

CREATE POLICY "Authenticated users can update own notifications" 
ON public.notifications 
FOR UPDATE 
USING (auth.uid() IS NOT NULL AND auth.uid() = user_id);

CREATE POLICY "System/Admins can create notifications" 
ON public.notifications 
FOR INSERT 
WITH CHECK (get_current_user_role() IN ('admin', 'system'));

-- 6. Fix production_records policy
DROP POLICY IF EXISTS "Users can view their own production records" ON public.production_records;

CREATE POLICY "Authenticated users can view own production records" 
ON public.production_records 
FOR SELECT 
USING (auth.uid() IS NOT NULL AND auth.uid() = user_id);

-- 7. Remove old service_orders policies that allow anonymous access
DROP POLICY IF EXISTS "Users can insert orders with role check" ON public.service_orders;

-- Create secure insert policy
CREATE POLICY "Authenticated users can create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  (user_id = auth.uid() OR get_current_user_role() IN ('admin', 'supervisor'))
);

-- 8. Add missing policies for materials table (currently read-only)
CREATE POLICY "Admins can manage materials" 
ON public.materials 
FOR ALL 
USING (get_current_user_role() = 'admin');

-- 9. Add missing policies for quality_inspections updates
CREATE POLICY "Inspectors can update their own inspections" 
ON public.quality_inspections 
FOR UPDATE 
USING (auth.uid() IS NOT NULL AND auth.uid() = inspector_id);

CREATE POLICY "Admins can manage quality inspections" 
ON public.quality_inspections 
FOR ALL 
USING (get_current_user_role() = 'admin');