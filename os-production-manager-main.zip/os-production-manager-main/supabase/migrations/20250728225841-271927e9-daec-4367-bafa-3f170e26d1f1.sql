-- Corrigir política RLS para permitir que admins e desenvolvedores criem novos usuários
-- Remover política atual e criar nova que permite INSERT para admins/desenvolvedores

-- Dropar política atual de INSERT
DROP POLICY IF EXISTS "Allow insert for authenticated users" ON public.profiles;

-- Criar nova política para permitir que admins e desenvolvedores insiram novos perfis
CREATE POLICY "Admins podem inserir perfis"
ON public.profiles 
FOR INSERT 
WITH CHECK (
    EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.user_id = auth.uid()
        AND (p.role = 'admin' OR p.role = 'desenvolvedor')
    )
);