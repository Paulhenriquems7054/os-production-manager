-- Ajustar políticas RLS para permitir usuários específicos criarem ordens
DROP POLICY IF EXISTS "Allow authenticated users to create orders" ON public.service_orders;
DROP POLICY IF EXISTS "Users can view orders" ON public.service_orders;
DROP POLICY IF EXISTS "Users can update orders" ON public.service_orders;

-- Política simplificada para criação de ordens - qualquer usuário autenticado
CREATE POLICY "Authenticated users can create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Política para visualização de ordens
CREATE POLICY "Users can view orders based on role" 
ON public.service_orders 
FOR SELECT 
USING (
  CASE 
    WHEN auth.uid() IS NULL THEN true  -- Usuários anônimos podem ver temporariamente
    ELSE (
      auth.uid() = user_id OR 
      get_current_user_role() = ANY (ARRAY['admin'::text, 'supervisor'::text, 'developer'::text])
    )
  END
);

-- Política para atualização de ordens
CREATE POLICY "Authorized users can update orders" 
ON public.service_orders 
FOR UPDATE 
USING (
  CASE 
    WHEN auth.uid() IS NULL THEN true  -- Usuários anônimos podem atualizar temporariamente
    ELSE (
      auth.uid() = user_id OR 
      get_current_user_role() = ANY (ARRAY['admin'::text, 'supervisor'::text, 'developer'::text])
    )
  END
);