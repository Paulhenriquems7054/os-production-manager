-- Corrigir política RLS na tabela profiles para permitir criação de usuários
-- A política deve usar WITH CHECK para INSERT, não USING

-- Primeiro, dropar todas as políticas existentes na tabela profiles
DROP POLICY IF EXISTS "Allow profile creation" ON public.profiles;
DROP POLICY IF EXISTS "Users can view profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Allow profile creation during authentication" ON public.profiles;
DROP POLICY IF EXISTS "Allow profile access" ON public.profiles;

-- Criar política correta para permitir INSERT apenas para usuários autenticados
-- O user_id deve ser igual ao auth.uid()
CREATE POLICY "Allow insert for authenticated users"
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Política para SELECT - usuários podem ver seu próprio perfil
CREATE POLICY "Users can view own profile"
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id OR get_current_user_role() = 'admin');

-- Política para UPDATE - usuários podem atualizar seu próprio perfil
CREATE POLICY "Users can update own profile"
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id OR get_current_user_role() = 'admin');