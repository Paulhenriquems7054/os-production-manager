-- Criar tabela de funcionários com dados da planilha
CREATE TABLE IF NOT EXISTS public.employees (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome_completo TEXT NOT NULL,
  funcao TEXT NOT NULL,
  department TEXT,
  supervisor TEXT,
  status TEXT DEFAULT 'active',
  email TEXT,
  telefone TEXT,
  data_admissao DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

-- Create policies for employees
CREATE POLICY "Everyone can view employees" 
ON public.employees 
FOR SELECT 
USING (true);

CREATE POLICY "System can manage employees" 
ON public.employees 
FOR ALL 
USING (true);

-- Criar tabela para sincronização de planilhas
CREATE TABLE IF NOT EXISTS public.sheet_sync_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sheet_id TEXT NOT NULL,
  sheet_name TEXT NOT NULL,
  last_sync TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  records_processed INTEGER DEFAULT 0,
  status TEXT DEFAULT 'success',
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sheet_sync_log ENABLE ROW LEVEL SECURITY;

-- Create policies for sync log
CREATE POLICY "Everyone can view sync log" 
ON public.sheet_sync_log 
FOR SELECT 
USING (true);

CREATE POLICY "System can manage sync log" 
ON public.sheet_sync_log 
FOR ALL 
USING (true);

-- Inserir funcionários baseados nos dados da planilha
INSERT INTO public.employees (nome_completo, funcao, supervisor, department, status) VALUES
('Ronald de Oliveira', 'Torneiro', 'Welber Oliveira', 'Produção', 'active'),
('João Paulo', 'Torneiro', 'Welber Oliveira', 'Produção', 'active'),
('Jacques Thadeu', 'Fresador', 'Welber Oliveira', 'Produção', 'active'),
('Silvio Cezar', 'Torneiro', 'Welber Oliveira', 'Produção', 'active'),
('Welber Oliveira', 'Supervisor', 'Welber Oliveira', 'Supervisão', 'active')
ON CONFLICT DO NOTHING;

-- Inserir alguns materiais básicos
INSERT INTO public.materials (name, description, unit, current_stock, minimum_stock, category, unit_cost) VALUES
('Aço AISI 4140', 'Aço liga para usinagem', 'kg', 150.5, 50, 'metal', 12.50),
('Aço AISI 1020', 'Aço carbono comum', 'kg', 200.0, 100, 'metal', 8.75),
('Óleo de corte', 'Fluido para usinagem', 'l', 45.0, 20, 'chemical', 25.00),
('Broca HSS 10mm', 'Broca de aço rápido', 'pcs', 25, 10, 'tool', 15.90),
('Pastilha WNMG', 'Pastilha de metal duro', 'pcs', 50, 20, 'tool', 8.50),
('EPI - Óculos', 'Óculos de proteção', 'pcs', 30, 15, 'safety', 12.00)
ON CONFLICT DO NOTHING;

-- Adicionar trigger para atualizar updated_at
CREATE TRIGGER update_employees_updated_at
BEFORE UPDATE ON public.employees
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Registrar sincronização inicial
INSERT INTO public.sheet_sync_log (sheet_id, sheet_name, records_processed, status) 
VALUES ('1AhgzO2tRdmHUjk_4YMBqP1orLJ0rR2UPQFOkqCoBTiM', 'Ordens de Serviços', 5, 'success');