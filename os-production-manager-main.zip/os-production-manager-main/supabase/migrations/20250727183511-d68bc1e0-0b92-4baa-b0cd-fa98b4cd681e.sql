-- Add missing INSERT policy for regular users to create their own service orders
CREATE POLICY "Users can create their own orders" ON public.service_orders
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Also add UPDATE policy for users to update their own orders
CREATE POLICY "Users can update their own orders" ON public.service_orders
FOR UPDATE 
USING (auth.uid() = user_id);