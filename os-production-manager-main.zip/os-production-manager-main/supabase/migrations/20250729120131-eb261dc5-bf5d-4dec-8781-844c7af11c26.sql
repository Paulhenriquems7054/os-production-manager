-- Adicionar política RLS mais permissiva para service_orders para permitir sistema local
-- Remover políticas restritivas e criar uma mais flexível

DROP POLICY IF EXISTS "Users can create their own orders" ON public.service_orders;

-- Criar política que permite inserção para usuários autenticados (local ou Supabase)
CREATE POLICY "Allow authenticated users to create orders" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text) OR 
  (user_id LIKE 'local-%')
);

-- Atualizar política de SELECT para incluir usuários locais
DROP POLICY IF EXISTS "Authenticated users can view own orders" ON public.service_orders;
DROP POLICY IF EXISTS "Supervisors and admins can view all orders" ON public.service_orders;

CREATE POLICY "Users can view orders based on auth type" 
ON public.service_orders 
FOR SELECT 
USING (
  -- Usuários Supabase podem ver suas próprias ordens
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text) OR
  -- Supervisores e admins podem ver todas
  (get_current_user_role() = ANY (ARRAY['supervisor'::text, 'admin'::text])) OR
  -- Para usuários locais, permitir visualização (será filtrado no frontend)
  (user_id LIKE 'local-%')
);