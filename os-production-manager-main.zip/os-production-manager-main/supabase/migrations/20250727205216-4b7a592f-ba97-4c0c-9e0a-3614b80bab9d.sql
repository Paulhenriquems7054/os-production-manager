-- Remover políticas antigas de INSERT conflitantes
DROP POLICY IF EXISTS "Authenticated users can create orders" ON public.service_orders;
DROP POLICY IF EXISTS "Usuarios criam apenas suas proprias ordens" ON public.service_orders;
DROP POLICY IF EXISTS "Usuarios podem criar ordens" ON public.service_orders;

-- Criar política correta para INSERT
CREATE POLICY "Users can insert orders with role check" 
ON public.service_orders 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL AND (
    -- Usuários comuns só podem inserir suas próprias ordens
    user_id = auth.uid() OR 
    -- Supervisores, admins e devs podem inserir para qualquer user_id
    get_current_user_role() = ANY (ARRAY['admin'::text, 'supervisor'::text, 'dev'::text])
  )
);