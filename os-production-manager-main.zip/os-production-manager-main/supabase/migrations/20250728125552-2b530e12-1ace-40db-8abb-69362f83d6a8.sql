-- CRITICAL SECURITY FIXES - Phase 1: RLS and Access Control

-- 1. Enable RLS on profiles table (CRITICAL)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2. Create secure RLS policies for profiles table
-- Users can only view their own profile
CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can update their own profile
CREATE POLICY "Users can update own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Only authenticated users can insert profiles
CREATE POLICY "Users can insert own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Admins can view all profiles
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (get_current_user_role() = 'admin');

-- 3. Remove dangerous anonymous access from employees table
DROP POLICY IF EXISTS "Everyone can view employees" ON public.employees;

-- Replace with authenticated-only access
CREATE POLICY "Authenticated users can view employees" 
ON public.employees 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- 4. Remove dangerous anonymous access from materials table
DROP POLICY IF EXISTS "Everyone can view materials" ON public.materials;

-- Replace with authenticated-only access
CREATE POLICY "Authenticated users can view materials" 
ON public.materials 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- 5. Remove dangerous anonymous access from sheet_sync_log
DROP POLICY IF EXISTS "Everyone can view sync log" ON public.sheet_sync_log;

-- Replace with admin-only access
CREATE POLICY "Admins can view sync log" 
ON public.sheet_sync_log 
FOR SELECT 
USING (get_current_user_role() = 'admin');

-- 6. Remove dangerous anonymous access from quality_inspections
DROP POLICY IF EXISTS "Everyone can view quality inspections" ON public.quality_inspections;

-- Replace with authenticated-only access
CREATE POLICY "Authenticated users can view quality inspections" 
ON public.quality_inspections 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- 7. Fix service_orders anonymous access vulnerability
DROP POLICY IF EXISTS "Users can view orders based on role" ON public.service_orders;
DROP POLICY IF EXISTS "Authorized users can update orders" ON public.service_orders;

-- Replace with secure authenticated-only policies
CREATE POLICY "Authenticated users can view own orders" 
ON public.service_orders 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND 
  (auth.uid() = user_id OR get_current_user_role() IN ('admin', 'supervisor'))
);

CREATE POLICY "Authenticated users can update orders" 
ON public.service_orders 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL AND 
  (auth.uid() = user_id OR get_current_user_role() IN ('admin', 'supervisor'))
);

-- 8. Secure database function with proper search path
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public, auth
AS $$
  SELECT role FROM public.profiles WHERE user_id = auth.uid();
$$;