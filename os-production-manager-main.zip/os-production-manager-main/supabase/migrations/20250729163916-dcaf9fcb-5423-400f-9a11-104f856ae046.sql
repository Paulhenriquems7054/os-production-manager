-- Drop the existing restrictive policies for profiles table
DROP POLICY IF EXISTS "Allow profile creation" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;

-- Create new, more permissive policies for profiles
-- Allow anyone to create profiles (needed for signup)
CREATE POLICY "Anyone can create profiles" 
ON public.profiles 
FOR INSERT 
WITH CHECK (true);

-- Allow users to view their own profile or admins to view all
CREATE POLICY "Users can view own profile or admins view all" 
ON public.profiles 
FOR SELECT 
USING (
  (auth.uid() = user_id) OR 
  (get_current_user_role() = 'admin'::text) OR
  (auth.uid() IS NULL)
);

-- Allow users to update their own profile or admins to update any
CREATE POLICY "Users can update own profile or admins update any" 
ON public.profiles 
FOR UPDATE 
USING (
  (auth.uid() = user_id) OR 
  (get_current_user_role() = 'admin'::text)
);

-- Allow admins to delete profiles
CREATE POLICY "Admins can delete profiles" 
ON public.profiles 
FOR DELETE 
USING (get_current_user_role() = 'admin'::text);