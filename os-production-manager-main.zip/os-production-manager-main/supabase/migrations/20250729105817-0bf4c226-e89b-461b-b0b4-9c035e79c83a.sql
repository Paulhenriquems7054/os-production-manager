-- Criar tabela usuarios para autenticação personalizada
CREATE TABLE public.usuarios (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  senha TEXT NOT NULL,
  departamento TEXT NOT NULL,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;

-- Política para permitir SELECT (para login)
CREATE POLICY "Permitir login de usuários" 
ON public.usuarios 
FOR SELECT 
USING (true);

-- Política para admins gerenciarem usuários
CREATE POLICY "Admins podem gerenciar usuários" 
ON public.usuarios 
FOR ALL 
USING (get_current_user_role() = 'admin')
WITH CHECK (get_current_user_role() = 'admin');

-- Inserir alguns usuários de exemplo
INSERT INTO public.usuarios (nome, senha, departamento, role) VALUES
('Paulo Henrique de Morais Silva', '123456', 'Produção', 'admin'),
('João Silva', '123456', 'Qualidade', 'supervisor'),
('Maria Santos', '123456', 'Materiais', 'user');