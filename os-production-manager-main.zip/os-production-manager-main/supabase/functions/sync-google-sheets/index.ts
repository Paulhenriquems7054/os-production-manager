import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { sheetId, sheetName } = await req.json();
    
    console.log(`🔄 Sincronizando planilha: ${sheetId}`);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch data from Google Sheets
    const sheetUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=1598789956`;
    console.log(`📊 Buscando dados de: ${sheetUrl}`);
    
    const response = await fetch(sheetUrl);
    
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }
    
    const csvText = await response.text();
    
    if (!csvText.trim()) {
      throw new Error('Planilha vazia ou sem dados');
    }

    // Parse CSV
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
    
    console.log(`📋 Headers encontrados: ${headers.length}`);
    console.log(`📄 Linhas de dados: ${lines.length - 1}`);
    
    const rows = lines.slice(1).map(line => {
      const result = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    });

    // Convert to objects
    const sheetsData = rows.map((row: string[]) => {
      const record: any = {};
      headers.forEach((header: string, index: number) => {
        record[header] = row[index] || "";
      });
      return record;
    });

    console.log(`📊 Dados processados: ${sheetsData.length} registros`);

    // Extract unique employees from sheets data
    const uniqueEmployees = new Map();
    
    sheetsData.forEach(record => {
      const executante = record["Execultante:"]?.trim();
      const funcao = record["Função:"]?.trim();
      const supervisor = record["Supervisor:"]?.trim();
      
      if (executante && !uniqueEmployees.has(executante)) {
        uniqueEmployees.set(executante, {
          nome_completo: executante,
          funcao: funcao || 'Não especificado',
          supervisor: supervisor || 'Não especificado',
          department: funcao === 'Supervisor' ? 'Supervisão' : 'Produção',
          status: 'active'
        });
      }
    });

    const employeesList = Array.from(uniqueEmployees.values());
    console.log(`👥 Funcionários únicos encontrados: ${employeesList.length}`);

    // Sync employees to database
    if (employeesList.length > 0) {
      const { error: employeesError } = await supabase
        .from('employees')
        .upsert(employeesList, {
          onConflict: 'nome_completo',
          ignoreDuplicates: false
        });

      if (employeesError) {
        console.error('❌ Erro ao sincronizar funcionários:', employeesError);
      } else {
        console.log(`✅ ${employeesList.length} funcionários sincronizados`);
      }
    }

    // Transform sheets data to production records
    const productionRecords = sheetsData.map((item, index) => {
      // Get services performed (non-empty fields)
      const services = [];
      
      const serviceFields = [
        'Peças 1 - [Suspensor TC1A]',
        'Peças 1 - [Suspensor T16]',
        'Peças 1 - [Anel para suspensor]',
        'Peças 1 - [Luva]',
        'Peças 1 - [Niple Longo]',
        'Peças 2 - [Difusor]',
        'Peças 2 - [Packer]',
        'Peças 2 - [Válvula Dreno]',
        'Peças 2 - [Válvula Check]',
        'Peças 2 - [Desareador]',
        'Tubo Filtro [Tubo Filtro]',
        'Peças 3 -  [Acoplamentos]',
        'Peças 3 -  [Cabeça de descarga]',
        'Peças 3 -  [Outro serviço]'
      ];

      serviceFields.forEach(field => {
        if (item[field] && item[field].trim()) {
          services.push(`${field}: ${item[field]}`);
        }
      });

      return {
        timestamp: item["Carimbo de data/hora"] || new Date().toLocaleString('pt-BR'),
        executante: item["Execultante:"] || '',
        funcao: item["Função:"] || '',
        supervisor: item["Supervisor:"] || '',
        suspensor_tc1a: item["Peças 1 - [Suspensor TC1A]"] || '',
        suspensor_t16: item["Peças 1 - [Suspensor T16]"] || '',
        anel_suspensor: item["Peças 1 - [Anel para suspensor]"] || '',
        luva: item["Peças 1 - [Luva]"] || '',
        niple_longo: item["Peças 1 - [Niple Longo]"] || '',
        difusor: item["Peças 2 - [Difusor]"] || '',
        packer: item["Peças 2 - [Packer]"] || '',
        valvula_dreno: item["Peças 2 - [Válvula Dreno]"] || '',
        valvula_check: item["Peças 2 - [Válvula Check]"] || '',
        desareador: item["Peças 2 - [Desareador]"] || '',
        tubo_filtro: item["Tubo Filtro [Tubo Filtro]"] || '',
        acoplamentos: item["Peças 3 -  [Acoplamentos]"] || '',
        cabeca_descarga: item["Peças 3 -  [Cabeça de descarga]"] || '',
        outro_servico: item["Peças 3 -  [Outro serviço]"] || '',
        colaborador_outro_servico: item["O COLABORADOR FARÁ OUTRO SERVIÇO:"] || '',
        observacoes: services.join('; ') || item["Coluna 17"] || '',
        user_id: '00000000-0000-0000-0000-000000000000' // Default user for system imports
      };
    });

    console.log(`🏭 Registros de produção preparados: ${productionRecords.length}`);

    // Sync production records to database
    if (productionRecords.length > 0) {
      const { error: productionError } = await supabase
        .from('production_records')
        .upsert(productionRecords, {
          onConflict: 'timestamp,executante',
          ignoreDuplicates: true
        });

      if (productionError) {
        console.error('❌ Erro ao sincronizar registros de produção:', productionError);
      } else {
        console.log(`✅ ${productionRecords.length} registros de produção sincronizados`);
      }
    }

    // Log the sync operation
    const { error: logError } = await supabase
      .from('sheet_sync_log')
      .insert({
        sheet_id: sheetId,
        sheet_name: sheetName,
        records_processed: employeesList.length + productionRecords.length,
        status: 'success'
      });

    if (logError) {
      console.error('❌ Erro ao registrar log:', logError);
    }

    return new Response(JSON.stringify({
      success: true,
      employees: employeesList,
      production_records: productionRecords,
      sync_log: {
        processed: employeesList.length + productionRecords.length,
        timestamp: new Date().toISOString()
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Erro na sincronização:', error);
    
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});