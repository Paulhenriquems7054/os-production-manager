import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface EmailData {
  to: string[]
  subject: string
  html: string
  text?: string
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { notification, recipients } = await req.json()

    if (!notification || !recipients || recipients.length === 0) {
      return new Response(
        JSON.stringify({ error: 'Dados de notificação ou destinatários em falta' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get email service configuration from Supabase secrets
    const resendApiKey = Deno.env.get('RESEND_API_KEY')
    
    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: 'Chave da API de email não configurada' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Format email content
    const priorityColors = {
      low: '#10b981',
      medium: '#f59e0b', 
      high: '#f97316',
      critical: '#ef4444'
    }

    const priorityLabels = {
      low: 'Baixa',
      medium: 'Média',
      high: 'Alta', 
      critical: 'Crítica'
    }

    const typeLabels = {
      quality: 'Qualidade',
      productivity: 'Produtividade',
      approval: 'Aprovação',
      system: 'Sistema',
      material: 'Material'
    }

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Notificação - OS Production Manager</title>
        </head>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px;">OS Production Manager</h1>
              <p style="color: rgba(255,255,255,0.9); margin: 5px 0 0 0;">Sistema de Notificações</p>
            </div>

            <!-- Content -->
            <div style="padding: 30px;">
              <!-- Priority Badge -->
              <div style="margin-bottom: 20px;">
                <span style="background-color: ${priorityColors[notification.priority]}; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; text-transform: uppercase;">
                  ${priorityLabels[notification.priority]} - ${typeLabels[notification.type]}
                </span>
              </div>

              <!-- Title -->
              <h2 style="color: #333; margin: 0 0 15px 0; font-size: 20px;">
                ${notification.title}
              </h2>

              <!-- Message -->
              <p style="color: #666; line-height: 1.6; margin: 0 0 20px 0; font-size: 16px;">
                ${notification.message}
              </p>

              ${notification.orderId ? `
                <!-- Order Info -->
                <div style="background-color: #f8f9fa; border-left: 4px solid #667eea; padding: 15px; margin: 20px 0; border-radius: 0 4px 4px 0;">
                  <p style="margin: 0; color: #495057;">
                    <strong>Ordem de Serviço:</strong> #${notification.orderId}
                  </p>
                </div>
              ` : ''}

              ${notification.actionRequired ? `
                <!-- Action Required -->
                <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px; padding: 15px; margin: 20px 0;">
                  <p style="margin: 0; color: #856404; font-weight: bold;">
                    ⚠️ Ação necessária
                  </p>
                </div>
              ` : ''}

              <!-- Timestamp -->
              <div style="border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 30px;">
                <p style="color: #868e96; font-size: 14px; margin: 0;">
                  Enviado em: ${new Date(notification.createdAt).toLocaleString('pt-BR')}
                </p>
              </div>
            </div>

            <!-- Footer -->
            <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
              <p style="color: #868e96; font-size: 12px; margin: 0;">
                Esta é uma notificação automática do OS Production Manager.<br>
                Para alterar suas preferências de notificação, acesse as configurações do sistema.
              </p>
            </div>
          </div>
        </body>
      </html>
    `

    const emailText = `
      OS Production Manager - Notificação
      
      Tipo: ${typeLabels[notification.type]} (${priorityLabels[notification.priority]})
      Título: ${notification.title}
      Mensagem: ${notification.message}
      
      ${notification.orderId ? `Ordem de Serviço: #${notification.orderId}` : ''}
      ${notification.actionRequired ? 'Ação necessária!' : ''}
      
      Enviado em: ${new Date(notification.createdAt).toLocaleString('pt-BR')}
    `

    // Send email using Resend
    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'OS Production Manager <noreply@os-production.com>',
        to: recipients,
        subject: `[${priorityLabels[notification.priority]}] ${notification.title}`,
        html: emailHtml,
        text: emailText,
      }),
    })

    if (!emailResponse.ok) {
      const error = await emailResponse.text()
      console.error('Erro ao enviar email:', error)
      return new Response(
        JSON.stringify({ error: 'Falha ao enviar email' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const result = await emailResponse.json()

    return new Response(
      JSON.stringify({ success: true, emailId: result.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Erro na função de email:', error)
    return new Response(
      JSON.stringify({ error: 'Erro interno do servidor' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})