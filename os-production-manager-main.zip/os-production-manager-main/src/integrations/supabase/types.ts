export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      employees: {
        Row: {
          created_at: string
          data_admissao: string | null
          department: string | null
          email: string | null
          funcao: string
          id: string
          nome_completo: string
          status: string | null
          supervisor: string | null
          telefone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          data_admissao?: string | null
          department?: string | null
          email?: string | null
          funcao: string
          id?: string
          nome_completo: string
          status?: string | null
          supervisor?: string | null
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          data_admissao?: string | null
          department?: string | null
          email?: string | null
          funcao?: string
          id?: string
          nome_completo?: string
          status?: string | null
          supervisor?: string | null
          telefone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      material_movements: {
        Row: {
          created_at: string
          id: string
          material_id: string
          movement_type: string
          order_id: string | null
          quantity: number
          reason: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          material_id: string
          movement_type: string
          order_id?: string | null
          quantity: number
          reason?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          material_id?: string
          movement_type?: string
          order_id?: string | null
          quantity?: number
          reason?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "material_movements_material_id_fkey"
            columns: ["material_id"]
            isOneToOne: false
            referencedRelation: "materials"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "material_movements_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "service_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      materials: {
        Row: {
          category: string
          created_at: string
          current_stock: number
          description: string | null
          id: string
          location: string | null
          minimum_stock: number
          name: string
          supplier: string | null
          unit: string
          unit_cost: number | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          current_stock?: number
          description?: string | null
          id?: string
          location?: string | null
          minimum_stock?: number
          name: string
          supplier?: string | null
          unit: string
          unit_cost?: number | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          current_stock?: number
          description?: string | null
          id?: string
          location?: string | null
          minimum_stock?: number
          name?: string
          supplier?: string | null
          unit?: string
          unit_cost?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read_at: string | null
          related_id: string | null
          related_table: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read_at?: string | null
          related_id?: string | null
          related_table?: string | null
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read_at?: string | null
          related_id?: string | null
          related_table?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      production_records: {
        Row: {
          acoplamentos: string | null
          anel_suspensor: string | null
          cabeca_descarga: string | null
          colaborador_outro_servico: string | null
          created_at: string
          desareador: string | null
          difusor: string | null
          executante: string
          funcao: string
          id: string
          luva: string | null
          niple_longo: string | null
          observacoes: string | null
          outro_servico: string | null
          packer: string | null
          supervisor: string
          suspensor_t16: string | null
          suspensor_tc1a: string | null
          timestamp: string
          tubo_filtro: string | null
          updated_at: string
          user_id: string
          valvula_check: string | null
          valvula_dreno: string | null
        }
        Insert: {
          acoplamentos?: string | null
          anel_suspensor?: string | null
          cabeca_descarga?: string | null
          colaborador_outro_servico?: string | null
          created_at?: string
          desareador?: string | null
          difusor?: string | null
          executante?: string
          funcao?: string
          id?: string
          luva?: string | null
          niple_longo?: string | null
          observacoes?: string | null
          outro_servico?: string | null
          packer?: string | null
          supervisor?: string
          suspensor_t16?: string | null
          suspensor_tc1a?: string | null
          timestamp?: string
          tubo_filtro?: string | null
          updated_at?: string
          user_id: string
          valvula_check?: string | null
          valvula_dreno?: string | null
        }
        Update: {
          acoplamentos?: string | null
          anel_suspensor?: string | null
          cabeca_descarga?: string | null
          colaborador_outro_servico?: string | null
          created_at?: string
          desareador?: string | null
          difusor?: string | null
          executante?: string
          funcao?: string
          id?: string
          luva?: string | null
          niple_longo?: string | null
          observacoes?: string | null
          outro_servico?: string | null
          packer?: string | null
          supervisor?: string
          suspensor_t16?: string | null
          suspensor_tc1a?: string | null
          timestamp?: string
          tubo_filtro?: string | null
          updated_at?: string
          user_id?: string
          valvula_check?: string | null
          valvula_dreno?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string | null
          department: string | null
          id: string
          nome_completo: string | null
          role: string | null
          senha_hash: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          department?: string | null
          id?: string
          nome_completo?: string | null
          role?: string | null
          senha_hash?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          department?: string | null
          id?: string
          nome_completo?: string | null
          role?: string | null
          senha_hash?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      quality_inspections: {
        Row: {
          corrective_actions: string | null
          created_at: string
          id: string
          inspection_date: string
          inspection_type: string
          inspector_id: string
          observations: string | null
          order_id: string
          score: number | null
          status: string
          updated_at: string
        }
        Insert: {
          corrective_actions?: string | null
          created_at?: string
          id?: string
          inspection_date?: string
          inspection_type: string
          inspector_id: string
          observations?: string | null
          order_id: string
          score?: number | null
          status?: string
          updated_at?: string
        }
        Update: {
          corrective_actions?: string | null
          created_at?: string
          id?: string
          inspection_date?: string
          inspection_type?: string
          inspector_id?: string
          observations?: string | null
          order_id?: string
          score?: number | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "quality_inspections_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "service_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      service_orders: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          category_id: string
          category_name: string
          client_email: string | null
          client_name: string | null
          client_phone: string | null
          createdAt: string
          description: string | null
          employee: string
          end_time: string
          estimated_hours: number | null
          id: string
          notes: string | null
          observations: string | null
          order_number: string
          piece: string
          priority: string | null
          quantity: number
          rejected_at: string | null
          rejected_by: string | null
          rework_count: number | null
          rework_history: Json | null
          scheduled_date: string | null
          service_id: string
          service_name: string
          service_type: string | null
          start_time: string
          status: string | null
          total_cost: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          category_id?: string
          category_name?: string
          client_email?: string | null
          client_name?: string | null
          client_phone?: string | null
          createdAt?: string
          description?: string | null
          employee?: string
          end_time?: string
          estimated_hours?: number | null
          id?: string
          notes?: string | null
          observations?: string | null
          order_number: string
          piece?: string
          priority?: string | null
          quantity?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rework_count?: number | null
          rework_history?: Json | null
          scheduled_date?: string | null
          service_id?: string
          service_name?: string
          service_type?: string | null
          start_time?: string
          status?: string | null
          total_cost?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          category_id?: string
          category_name?: string
          client_email?: string | null
          client_name?: string | null
          client_phone?: string | null
          createdAt?: string
          description?: string | null
          employee?: string
          end_time?: string
          estimated_hours?: number | null
          id?: string
          notes?: string | null
          observations?: string | null
          order_number?: string
          piece?: string
          priority?: string | null
          quantity?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rework_count?: number | null
          rework_history?: Json | null
          scheduled_date?: string | null
          service_id?: string
          service_name?: string
          service_type?: string | null
          start_time?: string
          status?: string | null
          total_cost?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      sheet_sync_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          last_sync: string
          records_processed: number | null
          sheet_id: string
          sheet_name: string
          status: string | null
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          last_sync?: string
          records_processed?: number | null
          sheet_id: string
          sheet_name: string
          status?: string | null
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          last_sync?: string
          records_processed?: number | null
          sheet_id?: string
          sheet_name?: string
          status?: string | null
        }
        Relationships: []
      }
      usuarios: {
        Row: {
          created_at: string
          departamento: string
          id: string
          nome: string
          role: string | null
          senha: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          departamento: string
          id?: string
          nome: string
          role?: string | null
          senha: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          departamento?: string
          id?: string
          nome?: string
          role?: string | null
          senha?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
