import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ProductionRecord } from '@/types/production';
import { Eye, Edit, Trash2, User, Calendar, Wrench } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface MobileProductionTableProps {
  records: ProductionRecord[];
  onEdit?: (record: ProductionRecord) => void;
  onDelete?: (id: string) => void;
  onView?: (record: ProductionRecord) => void;
}

const getServicesSummary = (record: ProductionRecord): string => {
  const services = [
    record.suspensorTC1A && 'Suspensor TC1A',
    record.suspensorT16 && 'Suspensor T16',
    record.anelSuspensor && 'Anel Suspensor',
    record.luva && 'Luva',
    record.nipleLongo && 'Niple Longo',
    record.difusor && 'Difusor',
    record.packer && 'Packer',
    record.valvulaDreno && 'Válvula Dreno',
    record.valvulaCheck && 'Válvula Check',
    record.desareador && 'Desareador',
    record.tuboFiltro && 'Tubo Filtro',
    record.acoplamentos && 'Acoplamentos',
    record.cabecaDescarga && 'Cabeça de Descarga',
    record.outroServico && 'Outro Serviço'
  ].filter(Boolean);

  return services.length > 0 ? services.join(', ') : 'Nenhum serviço registrado';
};

export const MobileProductionTable: React.FC<MobileProductionTableProps> = ({
  records,
  onEdit,
  onDelete,
  onView,
}) => {
  const isMobile = useIsMobile();

  if (!isMobile) {
    // Return null on desktop, let the regular table handle it
    return null;
  }

  if (records.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-muted-foreground">Nenhum registro encontrado</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {records.map((record) => (
        <Card key={record.id} className="relative">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span className="truncate">{record.executante}</span>
              </div>
              <Badge variant="outline" className="text-xs">
                {record.funcao}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{record.timestamp}</span>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <Wrench className="w-4 h-4 mt-0.5 text-primary" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Serviços:</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {getServicesSummary(record)}
                  </p>
                </div>
              </div>
              
              <div className="text-sm">
                <span className="font-medium">Supervisor: </span>
                <span className="text-muted-foreground">{record.supervisor}</span>
              </div>
            </div>

            {record.observacoes && (
              <div className="text-sm">
                <span className="font-medium">Obs: </span>
                <span className="text-muted-foreground line-clamp-2">{record.observacoes}</span>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              {onView && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => onView(record)}
                  className="flex-1"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Ver
                </Button>
              )}
              {onEdit && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => onEdit(record)}
                  className="flex-1"
                >
                  <Edit className="w-4 h-4 mr-1" />
                  Editar
                </Button>
              )}
              {onDelete && (
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={() => onDelete(record.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};