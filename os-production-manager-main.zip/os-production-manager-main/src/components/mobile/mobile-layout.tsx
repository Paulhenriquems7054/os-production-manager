import * as React from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

interface MobileLayoutProps {
  children: React.ReactNode;
  className?: string;
}

export const MobileLayout: React.FC<MobileLayoutProps> = ({ children, className }) => {
  const isMobile = useIsMobile();

  return (
    <div className={cn(
      "min-h-screen bg-background",
      isMobile ? "px-2 py-2" : "px-6 py-6",
      className
    )}>
      <div className={cn(
        "mx-auto space-y-4",
        isMobile ? "max-w-full" : "max-w-7xl space-y-6"
      )}>
        {children}
      </div>
    </div>
  );
};