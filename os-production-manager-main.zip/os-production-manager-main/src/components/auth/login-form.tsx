import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Logo } from '@/components/ui/logo';
import { UserCog, User, UserPlus } from 'lucide-react';

interface LoginFormProps {
  onLogin: (userType: 'admin' | 'supervisor' | 'user', username: string) => void;
}

export const LoginForm = ({ onLogin }: LoginFormProps) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [userType, setUserType] = useState<'admin' | 'supervisor' | 'user'>('user');
  const [isRegister, setIsRegister] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isRegister) {
      // Validação do cadastro
      if (!fullName.trim() || !username.trim() || !password.trim() || !confirmPassword.trim()) {
        alert('Preencha todos os campos');
        return;
      }
      if (password !== confirmPassword) {
        alert('As senhas não coincidem');
        return;
      }
      if (password.length < 6) {
        alert('A senha deve ter pelo menos 6 caracteres');
        return;
      }
      
      // Salvar usuário no localStorage (simulação de banco de dados)
      const newUser = {
        username: username.trim(),
        password: password,
        fullName: fullName.trim(),
        userType: userType
      };
      
      const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
      users.push(newUser);
      localStorage.setItem('registeredUsers', JSON.stringify(users));
      
      alert(`Usuário ${fullName} cadastrado com sucesso!`);
      setIsRegister(false);
      // Limpar campos
      setFullName('');
      setUsername('');
      setPassword('');
      setConfirmPassword('');
      return;
    }
    
    // Login com validação de credenciais
    if (!username.trim() || !password.trim()) {
      alert('Preencha todos os campos');
      return;
    }
    
    // Credenciais padrão para teste
    const defaultCredentials = {
      admin: { username: 'admin', password: 'admin123' },
      supervisor: { username: 'supervisor', password: 'super123' }
    };
    
    // Verificar usuários cadastrados
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const registeredUser = registeredUsers.find((user: any) => 
      user.username === username.trim() && user.password === password && user.userType === userType
    );
    
    // Verificar credenciais padrão
    const defaultUser = defaultCredentials[userType as keyof typeof defaultCredentials];
    const isDefaultUser = defaultUser && username === defaultUser.username && password === defaultUser.password;
    
    if (registeredUser || isDefaultUser) {
      onLogin(userType as 'admin' | 'supervisor', username);
    } else {
      alert('Usuário ou senha incorretos');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-2 sm:p-4">
      <Card className="w-full max-w-md mx-2 sm:mx-0">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <Logo size="lg" />
          </div>
          <div>
            <CardTitle className="text-2xl">Gestão de Funcionários</CardTitle>
            <CardDescription>
              Sistema de controle de ordens de serviço
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userType">Tipo de Usuário</Label>
              <Select value={userType} onValueChange={(value: 'admin' | 'supervisor' | 'user') => setUserType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user" className="flex items-center">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Usuário
                    </div>
                  </SelectItem>
                  <SelectItem value="supervisor" className="flex items-center">
                    <div className="flex items-center gap-2">
                      <UserCog className="w-4 h-4" />
                      Supervisor
                    </div>
                  </SelectItem>
                  <SelectItem value="admin" className="flex items-center">
                    <div className="flex items-center gap-2">
                      <UserCog className="w-4 h-4" />
                      Administrador
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {isRegister && (
              <div className="space-y-2">
                <Label htmlFor="fullName">Nome Completo</Label>
                <Input
                  id="fullName"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Digite seu nome completo"
                  required
                />
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="username">Usuário</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Digite seu usuário"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite sua senha"
                required
              />
            </div>
            
            {isRegister && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirme sua senha"
                  required
                />
              </div>
            )}
            
            <Button type="submit" className="w-full">
              {isRegister ? (
                <div className="flex items-center gap-2">
                  <UserPlus className="w-4 h-4" />
                  Cadastrar
                </div>
              ) : (
                'Entrar'
              )}
            </Button>
            
            <div className="text-center">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setIsRegister(!isRegister)}
                className="text-sm"
              >
                {isRegister ? 'Já tem conta? Fazer login' : 'Não tem conta? Cadastre-se'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};