import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Save, FileText } from 'lucide-react';
import { productionCatalog, PieceCategory } from '@/data/catalog';
import { useToast } from '@/hooks/use-toast';
import { ServiceOrderFormData } from '@/types/order';
import { generateOrderPDF } from '@/utils/pdf-generator';

interface NewOrderFormProps {
  onBack: () => void;
  onSave: (order: ServiceOrderFormData) => Promise<any>;
}

export const NewOrderForm = ({ onBack, onSave }: NewOrderFormProps) => {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<PieceCategory | null>(null);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [serviceType, setServiceType] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [estimatedHours, setEstimatedHours] = useState('');
  const [totalCost, setTotalCost] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!clientName || !serviceType) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }
    
    const orderData: ServiceOrderFormData = {
      client_name: clientName,
      client_phone: clientPhone,
      client_email: clientEmail,
      service_type: serviceType,
      description,
      priority,
      estimated_hours: estimatedHours ? parseFloat(estimatedHours) : undefined,
      total_cost: totalCost ? parseFloat(totalCost) : undefined,
      scheduled_date: scheduledDate,
      notes,
    };

    try {
      await onSave(orderData);
      
      toast({
        title: "Ordem de Serviço criada",
        description: "OS criada com sucesso",
        variant: "default"
      });
      
      // Reset form
      setClientName('');
      setClientPhone('');
      setClientEmail('');
      setServiceType('');
      setDescription('');
      setPriority('medium');
      setEstimatedHours('');
      setTotalCost('');
      setScheduledDate('');
      setNotes('');
    } catch (error) {
      console.error('Error creating order:', error);
    }
  };

  return (
    <div className="space-y-4 pb-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-4">
          <div className="space-y-2">
            <Label htmlFor="clientName">Nome do Cliente *</Label>
            <Input
              id="clientName"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              placeholder="Nome do cliente"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="clientPhone">Telefone</Label>
            <Input
              id="clientPhone"
              value={clientPhone}
              onChange={(e) => setClientPhone(e.target.value)}
              placeholder="(11) 99999-9999"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="clientEmail">Email do Cliente</Label>
          <Input
            id="clientEmail"
            type="email"
            value={clientEmail}
            onChange={(e) => setClientEmail(e.target.value)}
            placeholder="cliente@email.com"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-4">
          <div className="space-y-2">
            <Label htmlFor="serviceType">Tipo de Serviço *</Label>
            <Input
              id="serviceType"
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              placeholder="Ex: Soldagem, Montagem, Reparo"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="priority">Prioridade</Label>
            <Select value={priority} onValueChange={(value: 'low' | 'medium' | 'high' | 'urgent') => setPriority(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a prioridade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Baixa</SelectItem>
                <SelectItem value="medium">Média</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="urgent">Urgente</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Descrição</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Descrição detalhada do serviço..."
            rows={3}
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-4">
          <div className="space-y-2">
            <Label htmlFor="estimatedHours">Horas Estimadas</Label>
            <Input
              id="estimatedHours"
              type="number"
              step="0.5"
              value={estimatedHours}
              onChange={(e) => setEstimatedHours(e.target.value)}
              placeholder="Ex: 8.5"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="totalCost">Custo Total (R$)</Label>
            <Input
              id="totalCost"
              type="number"
              step="0.01"
              value={totalCost}
              onChange={(e) => setTotalCost(e.target.value)}
              placeholder="Ex: 1500.00"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="scheduledDate">Data Agendada</Label>
          <Input
            id="scheduledDate"
            type="datetime-local"
            value={scheduledDate}
            onChange={(e) => setScheduledDate(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Observações</Label>
          <Textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Observações adicionais sobre o serviço..."
            rows={3}
          />
        </div>

        <div className="flex pt-4">
          <Button type="submit" className="w-full">
            <Save className="w-4 h-4 mr-2" />
            Criar Ordem de Serviço
          </Button>
        </div>
      </form>
    </div>
  );
};