import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ServiceOrder } from '@/types/order';
import { FileText, Package, User } from 'lucide-react';
import { generateMultipleOrdersPDF } from '@/utils/pdf-generator';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface BulkPDFGeneratorProps {
  orders: ServiceOrder[];
}

export const BulkPDFGenerator = ({ orders }: BulkPDFGeneratorProps) => {
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const handleSelectOrder = (orderId: string, checked: boolean) => {
    if (checked) {
      setSelectedOrders(prev => [...prev, orderId]);
    } else {
      setSelectedOrders(prev => prev.filter(id => id !== orderId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedOrders(orders.map(order => order.id));
    } else {
      setSelectedOrders([]);
    }
  };

  const handleGeneratePDF = async () => {
    if (selectedOrders.length === 0) {
      toast({
        title: "Nenhuma ordem selecionada",
        description: "Selecione pelo menos uma ordem para gerar o PDF",
        variant: "destructive"
      });
      return;
    }

    const ordersToGenerate = orders.filter(order => selectedOrders.includes(order.id));
    
    try {
      // Aguarda o download ser concluído antes de mostrar sucesso
      await generateMultipleOrdersPDF(ordersToGenerate);
      
      toast({
        title: "PDF gerado com sucesso",
        description: `Relatório com ${ordersToGenerate.length} ordens foi baixado`,
      });

      setIsOpen(false);
      setSelectedOrders([]);
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Ocorreu um erro durante a geração do relatório. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString || dateString.trim() === '') return 'Não definido';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy', { locale: ptBR });
    } catch (error) {
      return 'Data inválida';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <FileText className="w-4 h-4" />
          PDF em Lote
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Gerar PDF em Lote
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="select-all"
                checked={selectedOrders.length === orders.length}
                onCheckedChange={handleSelectAll}
              />
              <label htmlFor="select-all" className="font-medium">
                Selecionar todas ({orders.length} ordens)
              </label>
            </div>
            <Badge variant="secondary">
              {selectedOrders.length} selecionadas
            </Badge>
          </div>

          <div className="grid gap-3 max-h-96 overflow-y-auto">
            {orders.map((order) => (
              <Card key={order.id} className="p-3">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id={`order-${order.id}`}
                    checked={selectedOrders.includes(order.id)}
                    onCheckedChange={(checked) => handleSelectOrder(order.id, checked as boolean)}
                  />
                  
                  <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{order.employee}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-muted-foreground" />
                      <span>{order.piece}</span>
                    </div>
                    
                    <div className="text-muted-foreground">
                      {formatDate(order.startTime)}
                    </div>
                  </div>
                  
                  <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                    {order.status === 'completed' ? 'Concluída' : 'Em andamento'}
                  </Badge>
                </div>
                
                <div className="mt-2 text-xs text-muted-foreground ml-6">
                  {order.serviceName} • Qtd: {order.quantity}
                </div>
              </Card>
            ))}
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              {selectedOrders.length > 0 
                ? `${selectedOrders.length} ordens selecionadas para PDF`
                : 'Selecione as ordens que deseja incluir no PDF'
              }
            </p>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancelar
              </Button>
              <Button 
                onClick={handleGeneratePDF}
                disabled={selectedOrders.length === 0}
              >
                <FileText className="w-4 h-4 mr-2" />
                Gerar PDF ({selectedOrders.length})
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};