import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Save, Trash2, FileText } from 'lucide-react';
import { productionCatalog, PieceCategory } from '@/data/catalog';
import { ServiceOrder } from '@/types/order';
import { useToast } from '@/hooks/use-toast';

interface EditOrderFormProps {
  order: ServiceOrder;
  onBack: () => void;
  onSave: (id: string, updates: Partial<ServiceOrder>) => void;
  onDelete: (id: string) => void;
}

export const EditOrderForm = ({ order, onBack, onSave, onDelete }: EditOrderFormProps) => {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<PieceCategory | null>(null);
  const [selectedPiece, setSelectedPiece] = useState(order.piece);
  const [selectedService, setSelectedService] = useState(order.serviceId);
  const [startTime, setStartTime] = useState(order.startTime);
  const [endTime, setEndTime] = useState(order.endTime);
  const [quantity, setQuantity] = useState(order.quantity.toString());
  const [observations, setObservations] = useState(order.observations || '');
  const [employee, setEmployee] = useState(order.employee);
  const [status, setStatus] = useState(order.status);

  useEffect(() => {
    const category = productionCatalog.find(c => c.id === order.categoryId);
    setSelectedCategory(category || null);
  }, [order.categoryId]);

  const handleCategoryChange = (categoryId: string) => {
    const category = productionCatalog.find(c => c.id === categoryId);
    setSelectedCategory(category || null);
    setSelectedPiece('');
    setSelectedService('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCategory || !selectedPiece || !selectedService || !startTime || !endTime || !quantity || !employee) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    const selectedServiceObj = selectedCategory.services.find(s => s.id === selectedService);
    
    const updates: Partial<ServiceOrder> = {
      employee,
      quantity: parseInt(quantity),
      categoryId: selectedCategory.id,
      categoryName: selectedCategory.name,
      piece: selectedPiece,
      serviceId: selectedService,
      serviceName: selectedServiceObj?.name || '',
      startTime,
      endTime,
      observations,
      status,
    };

    onSave(order.id, updates);
    
    toast({
      title: "Ordem atualizada",
      description: "OS atualizada com sucesso",
      variant: "default"
    });
  };

  const handleDelete = () => {
    if (confirm('Tem certeza que deseja excluir esta ordem de serviço?')) {
      onDelete(order.id);
      toast({
        title: "Ordem excluída",
        description: "OS excluída com sucesso",
        variant: "default"
      });
      onBack();
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-4">
          <div className="space-y-2">
            <Label htmlFor="employee">Funcionário *</Label>
            <Input
              id="employee"
              value={employee}
              onChange={(e) => setEmployee(e.target.value)}
              placeholder="Nome do funcionário"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantidade Produzida *</Label>
            <Input
              id="quantity"
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder="Ex: 10"
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">Status *</Label>
          <Select value={status} onValueChange={(value: 'active' | 'completed') => setStatus(value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Em andamento</SelectItem>
              <SelectItem value="completed">Concluída</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Categoria da Peça *</Label>
          <Select value={selectedCategory?.id || ''} onValueChange={handleCategoryChange}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione a categoria" />
            </SelectTrigger>
            <SelectContent>
              {productionCatalog.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedCategory && (
          <div className="space-y-2">
            <Label htmlFor="piece">Peça *</Label>
            <Select value={selectedPiece} onValueChange={setSelectedPiece}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a peça" />
              </SelectTrigger>
              <SelectContent>
                {selectedCategory.pieces.map((piece) => (
                  <SelectItem key={piece} value={piece}>
                    {piece}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {selectedCategory && selectedPiece && (
          <div className="space-y-2">
            <Label htmlFor="service">Serviço *</Label>
            <Select value={selectedService} onValueChange={setSelectedService}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent>
                {selectedCategory.services.map((service) => (
                  <SelectItem key={service.id} value={service.id}>
                    {service.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-4">
          <div className="space-y-2">
            <Label htmlFor="startTime">Horário de Início *</Label>
            <Input
              id="startTime"
              type="datetime-local"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="endTime">Horário de Término *</Label>
            <Input
              id="endTime"
              type="datetime-local"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="observations">Observações</Label>
          <Textarea
            id="observations"
            value={observations}
            onChange={(e) => setObservations(e.target.value)}
            placeholder="Observações adicionais sobre o serviço..."
            rows={3}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button type="submit" className="flex-1 order-1">
            <Save className="w-4 h-4 mr-2" />
            Salvar Alterações
          </Button>
          <Button 
            type="button" 
            variant="destructive" 
            onClick={handleDelete}
            className="order-2 sm:order-2"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Excluir
          </Button>
        </div>
      </form>
    </div>
  );
};