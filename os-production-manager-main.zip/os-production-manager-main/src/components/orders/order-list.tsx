import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Edit, Search, Calendar, User, Package, Clock, FileText } from 'lucide-react';
import { ServiceOrder } from '@/types/order';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useIsMobile } from '@/hooks/use-mobile';

interface OrderListProps {
  orders: ServiceOrder[];
  onEditOrder: (order: ServiceOrder) => void;
}

export const OrderList = ({ orders, onEditOrder }: OrderListProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const isMobile = useIsMobile();

  const filteredOrders = orders.filter(order =>
    order.employee.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.piece.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.serviceName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    if (!dateString || dateString.trim() === '') return 'Não definido';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy HH:mm', { locale: ptBR });
    } catch (error) {
      return 'Data inválida';
    }
  };

  const calculateDuration = (start: string, end: string): string => {
    if (!start || !end || start.trim() === '' || end.trim() === '') return 'Não calculado';
    try {
      const startDate = new Date(start);
      const endDate = new Date(end);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return 'Datas inválidas';
      const diffMs = endDate.getTime() - startDate.getTime();
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m`;
    } catch (error) {
      return 'Erro no cálculo';
    }
  };

  return (
    <div className="space-y-4">
      <div className={`flex items-center gap-4 ${isMobile ? 'flex-col' : ''}`}>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Buscar por funcionário, peça ou serviço..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Badge variant="secondary" className="px-3 py-1">
          {filteredOrders.length} ordens
        </Badge>
      </div>

      {filteredOrders.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FileText className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              {searchTerm ? 'Nenhuma ordem encontrada' : 'Nenhuma ordem de serviço cadastrada'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredOrders.map((order) => (
            <Card key={order.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="w-5 h-5" />
                    {order.employee}
                  </CardTitle>
                  <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                    {order.status === 'completed' ? 'Concluída' : 'Em andamento'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-muted-foreground" />
                    <span><strong>Peça:</strong> {order.piece}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span><strong>Serviço:</strong> {order.serviceName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span><strong>Quantidade:</strong> {order.quantity}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span><strong>Duração:</strong> {calculateDuration(order.startTime, order.endTime)}</span>
                  </div>
                </div>
                
                <div className="text-xs text-muted-foreground flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Início: {formatDate(order.startTime)}</span>
                  <span>•</span>
                  <span>Fim: {formatDate(order.endTime)}</span>
                </div>

                {order.observations && (
                  <div className="text-sm bg-muted p-3 rounded-md">
                    <strong>Observações:</strong> {order.observations}
                  </div>
                )}

                <div className="flex justify-end pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => onEditOrder(order)}
                    className="flex items-center gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    Editar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};