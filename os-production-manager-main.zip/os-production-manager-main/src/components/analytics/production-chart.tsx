import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ProductionStats } from '@/types/production';
import { TrendingUp, Users } from 'lucide-react';

interface ProductionChartProps {
  stats: ProductionStats;
  loading?: boolean;
}

interface ChartDataPoint {
  day: string;
  registros: number;
  funcionarios: number;
  date?: string;
}

export function ProductionChart({ stats, loading }: ProductionChartProps) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Produção por Período</CardTitle>
          <CardDescription>Carregando dados...</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px] flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">
            Sincronizando com Google Sheets...
          </div>
        </CardContent>
      </Card>
    );
  }

  // Se não há dados, criar dados de exemplo para demonstração
  const hasData = stats.dailyProduction && stats.dailyProduction.length > 0;
  
  const data: ChartDataPoint[] = hasData 
    ? stats.dailyProduction.map(day => ({
        day: day.date,
        registros: day.count,
        funcionarios: day.employees.length,
        date: day.date
      }))
    : [
        { day: '20/01', registros: 8, funcionarios: 4 },
        { day: '21/01', registros: 12, funcionarios: 5 },
        { day: '22/01', registros: 15, funcionarios: 6 },
        { day: '23/01', registros: 10, funcionarios: 4 },
        { day: '24/01', registros: 18, funcionarios: 7 },
        { day: '25/01', registros: 14, funcionarios: 5 },
        { day: '26/01', registros: 16, funcionarios: 6 }
      ];

  const totalRegistros = data.reduce((sum, day) => sum + day.registros, 0);
  const averageRegistros = data.length > 0 ? Math.round(totalRegistros / data.length) : 0;
  const totalFuncionarios = data.reduce((sum, day) => sum + day.funcionarios, 0);
  const averageFuncionarios = data.length > 0 ? Math.round(totalFuncionarios / data.length) : 0;

  return (
    <Card className="chart-card group hover:shadow-lg transition-all duration-300">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-primary animate-pulse" />
              Produção por Período
            </CardTitle>
            <CardDescription>
              Registros de produção nos últimos 7 dias
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-primary animate-fade-in">
              {totalRegistros}
            </div>
            <div className="text-xs text-muted-foreground">
              Total de registros
            </div>
          </div>
        </div>
        <div className="flex gap-4 mt-2">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 bg-primary rounded-full animate-pulse"></div>
            <span>Produção</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 bg-muted-foreground rounded-full opacity-70"></div>
            <span>Funcionários</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="animate-fade-in">
        <ResponsiveContainer width="100%" height={320}>
          <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="gradientRegistros" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="gradientFuncionarios" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="hsl(var(--border))" 
              opacity={0.3}
            />
            <XAxis 
              dataKey="day" 
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={false}
              tickLine={false}
              domain={[0, 'dataMax + 2']}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '12px',
                boxShadow: '0 10px 40px -10px hsl(var(--foreground) / 0.1)',
                color: 'hsl(var(--foreground))'
              }}
              formatter={(value, name) => [
                `${value} ${name === 'registros' ? 'registros' : 'funcionários'}`,
                name === 'registros' ? 'Registros de Produção' : 'Funcionários Ativos'
              ]}
              labelFormatter={(label) => `Data: ${label}`}
            />
            <Area
              type="monotone"
              dataKey="registros"
              stroke="hsl(var(--primary))"
              strokeWidth={3}
              fill="url(#gradientRegistros)"
              dot={{ 
                fill: 'hsl(var(--primary))', 
                strokeWidth: 2, 
                r: 5
              }}
              activeDot={{ 
                r: 7, 
                stroke: 'hsl(var(--primary))', 
                strokeWidth: 2,
                fill: 'hsl(var(--background))'
              }}
              animationBegin={200}
              animationDuration={1500}
            />
            <Line 
              type="monotone" 
              dataKey="funcionarios" 
              stroke="hsl(var(--muted-foreground))" 
              strokeWidth={2}
              strokeDasharray="6 4"
              dot={{ 
                fill: 'hsl(var(--muted-foreground))', 
                strokeWidth: 2, 
                r: 4,
                opacity: 0.8
              }}
              activeDot={{ 
                r: 6, 
                stroke: 'hsl(var(--muted-foreground))', 
                strokeWidth: 2,
                fill: 'hsl(var(--background))'
              }}
              animationBegin={400}
              animationDuration={1200}
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex justify-between text-xs text-muted-foreground mt-2 pt-2 border-t">
          <span>Média: {averageRegistros} registros/dia</span>
          <span className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {averageFuncionarios} funcionários/dia
          </span>
        </div>
      </CardContent>
    </Card>
  );
}