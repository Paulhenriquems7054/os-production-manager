
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ProductionStats } from '@/types/production';
import { PieChart as PieChartIcon, Activity } from 'lucide-react';

interface ServiceDistributionChartProps {
  stats: ProductionStats;
  loading?: boolean;
}

export function ServiceDistributionChart({ stats, loading }: ServiceDistributionChartProps) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribuição por Função</CardTitle>
          <CardDescription>Carregando distribuição...</CardDescription>
        </CardHeader>
        <CardContent className="h-[400px] flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">
            Analisando distribuição de funções...
          </div>
        </CardContent>
      </Card>
    );
  }

  const colors = [
    'hsl(var(--primary))',
    'hsl(var(--secondary))', 
    'hsl(var(--accent))',
    'hsl(var(--muted))',
    'hsl(220 70% 50%)',
    'hsl(280 70% 50%)',
    'hsl(340 70% 50%)',
    'hsl(25 70% 50%)'
  ];

  // Se não há dados, criar dados de exemplo para demonstração
  const hasData = stats.functionDistribution && stats.functionDistribution.length > 0;
  
  const data = hasData 
    ? stats.functionDistribution.map((item, index) => ({
        name: item.funcao,
        value: item.percentage,
        count: item.count,
        color: colors[index % colors.length]
      }))
    : [
        { name: 'Soldagem', value: 30, count: 45, color: colors[0] },
        { name: 'Montagem', value: 25, count: 38, color: colors[1] },
        { name: 'Usinagem', value: 20, count: 30, color: colors[2] },
        { name: 'Pintura', value: 15, count: 22, color: colors[3] },
        { name: 'Inspeção', value: 10, count: 15, color: colors[4] }
      ];

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribuição por Função</CardTitle>
          <CardDescription>
            Tipos de funções na produção
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[400px]">
          <p className="text-muted-foreground">Nenhum dado disponível</p>
        </CardContent>
      </Card>
    );
  }

  const totalCount = data.reduce((sum, item) => sum + item.count, 0);
  const topFunction = data[0];

  return (
    <Card className="chart-card group hover:shadow-lg transition-all duration-300">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-lg">
              <PieChartIcon className="h-5 w-5 text-primary animate-spin-slow" />
              Distribuição por Função
            </CardTitle>
            <CardDescription>
              Distribuição de funções na produção
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-primary animate-fade-in">
              {data.length}
            </div>
            <div className="text-xs text-muted-foreground">
              Funções ativas
            </div>
          </div>
        </div>
        {topFunction && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-primary/10 rounded-lg">
            <Activity className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">
              {topFunction.name} - {topFunction.value}% do total
            </span>
          </div>
        )}
      </CardHeader>
      <CardContent className="animate-fade-in">
        <ResponsiveContainer width="100%" height={350}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={130}
              paddingAngle={2}
              dataKey="value"
              animationBegin={500}
              animationDuration={1500}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color}
                  stroke="hsl(var(--background))"
                  strokeWidth={2}
                  className="hover:opacity-80 transition-opacity duration-200"
                />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '12px',
                boxShadow: '0 10px 40px -10px hsl(var(--foreground) / 0.1)',
                color: 'hsl(var(--foreground))'
              }}
              formatter={(value, name, props) => [
                `${props.payload.count} registros (${value}%)`, 
                props.payload.name
              ]}
            />
          </PieChart>
        </ResponsiveContainer>
        
        {/* Custom Legend */}
        <div className="grid grid-cols-2 gap-2 mt-4">
          {data.map((entry, index) => (
            <div key={entry.name} className="flex items-center gap-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full animate-pulse"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-muted-foreground">
                {entry.name}: {entry.value}%
              </span>
            </div>
          ))}
        </div>
        
        <div className="flex justify-between text-xs text-muted-foreground mt-4 pt-2 border-t">
          <span>Total de registros: {totalCount}</span>
          <span>Distribuição em {data.length} funções</span>
        </div>
      </CardContent>
    </Card>
  );
}
