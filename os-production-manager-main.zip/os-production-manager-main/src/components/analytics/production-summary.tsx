
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, Clock, Package } from "lucide-react";
import { ProductionRecord, ProductionStats } from "@/types/production";

interface ProductionSummaryProps {
  records: ProductionRecord[];
  stats: ProductionStats;
  loading?: boolean;
}

export function ProductionSummary({ records, stats, loading }: ProductionSummaryProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-2">
              <div className="h-4 bg-muted rounded w-3/4"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-muted rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const summaryData = [
    {
      title: "Total de Registros",
      value: stats.totalRecords.toString(),
      change: `${stats.servicesExecuted} serviços`,
      icon: Package,
      period: "executados"
    },
    {
      title: "Funcionários Ativos",
      value: stats.uniqueEmployees.toString(),
      change: stats.topEmployee ? `Destaque: ${stats.topEmployee}` : "nenhum",
      icon: Users,
      period: "únicos"
    },
    {
      title: "Função Principal",
      value: stats.topFunction || "N/A",
      change: stats.functionDistribution[0] ? `${stats.functionDistribution[0].count} registros` : "0",
      icon: Clock,
      period: "mais ativa"
    },
    {
      title: "Produção Diária",
      value: `${stats.dailyProduction.reduce((acc, day) => acc + day.count, 0) / 7}`,
      change: "média últimos 7 dias",
      icon: TrendingUp,
      period: "registros/dia"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {summaryData.map((item, index) => (
        <Card key={index} className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {item.title}
            </CardTitle>
            <item.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {parseFloat(item.value).toFixed(0)}
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-muted-foreground">{item.change}</span>
              <span className="text-xs text-muted-foreground">{item.period}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
