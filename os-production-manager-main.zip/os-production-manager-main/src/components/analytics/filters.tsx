import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Filter, RotateCcw } from 'lucide-react';
import { ServiceOrder } from '@/types/order';

interface FiltersProps {
  orders: ServiceOrder[];
  onFiltersChange: (filteredOrders: ServiceOrder[]) => void;
}

export const Filters = ({ orders, onFiltersChange }: FiltersProps) => {
  const [filters, setFilters] = useState({
    employee: '',
    piece: '',
    service: '',
    status: '',
    startDate: '',
    endDate: ''
  });

  // Obter valores únicos para os filtros
  const uniqueEmployees = [...new Set(orders.map(order => order.employee))];
  const uniquePieces = [...new Set(orders.map(order => order.piece))];
  const uniqueServices = [...new Set(orders.map(order => order.serviceName))];

  const applyFilters = () => {
    let filtered = orders;

    if (filters.employee && filters.employee !== 'all') {
      filtered = filtered.filter(order => 
        order.employee.toLowerCase().includes(filters.employee.toLowerCase())
      );
    }

    if (filters.piece && filters.piece !== 'all') {
      filtered = filtered.filter(order => 
        order.piece.toLowerCase().includes(filters.piece.toLowerCase())
      );
    }

    if (filters.service && filters.service !== 'all') {
      filtered = filtered.filter(order => 
        order.serviceName.toLowerCase().includes(filters.service.toLowerCase())
      );
    }

    if (filters.status && filters.status !== 'all') {
      filtered = filtered.filter(order => order.status === filters.status);
    }

    if (filters.startDate) {
      filtered = filtered.filter(order => {
        if (!order.startTime || order.startTime.trim() === '') return false;
        try {
          return new Date(order.startTime) >= new Date(filters.startDate);
        } catch (error) {
          return false;
        }
      });
    }

    if (filters.endDate) {
      filtered = filtered.filter(order => {
        if (!order.endTime || order.endTime.trim() === '') return false;
        try {
          return new Date(order.endTime) <= new Date(filters.endDate + 'T23:59:59');
        } catch (error) {
          return false;
        }
      });
    }

    onFiltersChange(filtered);
  };

  const clearFilters = () => {
    setFilters({
      employee: '',
      piece: '',
      service: '',
      status: '',
      startDate: '',
      endDate: ''
    });
    onFiltersChange(orders);
  };

  const updateFilter = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    
    // Auto-aplicar filtros quando algum valor muda
    setTimeout(() => {
      let filtered = orders;

      if (newFilters.employee && newFilters.employee !== 'all') {
        filtered = filtered.filter(order => 
          order.employee.toLowerCase().includes(newFilters.employee.toLowerCase())
        );
      }

      if (newFilters.piece && newFilters.piece !== 'all') {
        filtered = filtered.filter(order => 
          order.piece.toLowerCase().includes(newFilters.piece.toLowerCase())
        );
      }

      if (newFilters.service && newFilters.service !== 'all') {
        filtered = filtered.filter(order => 
          order.serviceName.toLowerCase().includes(newFilters.service.toLowerCase())
        );
      }

      if (newFilters.status && newFilters.status !== 'all') {
        filtered = filtered.filter(order => order.status === newFilters.status);
      }

      if (newFilters.startDate) {
        filtered = filtered.filter(order => {
          if (!order.startTime || order.startTime.trim() === '') return false;
          try {
            return new Date(order.startTime) >= new Date(newFilters.startDate);
          } catch (error) {
            return false;
          }
        });
      }

      if (newFilters.endDate) {
        filtered = filtered.filter(order => {
          if (!order.endTime || order.endTime.trim() === '') return false;
          try {
            return new Date(order.endTime) <= new Date(newFilters.endDate + 'T23:59:59');
          } catch (error) {
            return false;
          }
        });
      }

      onFiltersChange(filtered);
    }, 300);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Filter className="w-5 h-5" />
          Filtros de Análise
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Funcionário</Label>
            <Select value={filters.employee} onValueChange={(value) => updateFilter('employee', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos os funcionários" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os funcionários</SelectItem>
                {uniqueEmployees.map(employee => (
                  <SelectItem key={employee} value={employee}>
                    {employee}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Peça</Label>
            <Select value={filters.piece} onValueChange={(value) => updateFilter('piece', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Todas as peças" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as peças</SelectItem>
                {uniquePieces.map(piece => (
                  <SelectItem key={piece} value={piece}>
                    {piece}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Serviço</Label>
            <Select value={filters.service} onValueChange={(value) => updateFilter('service', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos os serviços" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os serviços</SelectItem>
                {uniqueServices.map(service => (
                  <SelectItem key={service} value={service}>
                    {service}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={filters.status} onValueChange={(value) => updateFilter('status', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos os status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="completed">Concluída</SelectItem>
                <SelectItem value="in-progress">Em andamento</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              Data Início
            </Label>
            <Input
              type="date"
              value={filters.startDate}
              onChange={(e) => updateFilter('startDate', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              Data Fim
            </Label>
            <Input
              type="date"
              value={filters.endDate}
              onChange={(e) => updateFilter('endDate', e.target.value)}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={clearFilters} className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4" />
            Limpar Filtros
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};