import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ProductionStats } from '@/types/production';
import { Award, User } from 'lucide-react';

interface EmployeePerformanceChartProps {
  stats: ProductionStats;
  loading?: boolean;
}

export function EmployeePerformanceChart({ stats, loading }: EmployeePerformanceChartProps) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Performance por Funcionário</CardTitle>
          <CardDescription>Carregando dados...</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px] flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">
            Processando dados de funcionários...
          </div>
        </CardContent>
      </Card>
    );
  }

  // Se não há dados, criar dados de exemplo para demonstração  
  const hasData = stats.employeePerformance && stats.employeePerformance.length > 0;
  
  const data = hasData 
    ? stats.employeePerformance
        .slice(0, 8) // Top 8 funcionários
        .map(emp => ({
          name: emp.executante.split(' ')[0], // Primeiro nome apenas
          fullName: emp.executante,
          servicos: emp.totalServices,
          funcoes: emp.functions.length
        }))
    : [
        { name: 'João', fullName: 'João Silva', servicos: 24, funcoes: 3 },
        { name: 'Maria', fullName: 'Maria Santos', servicos: 18, funcoes: 2 },
        { name: 'Pedro', fullName: 'Pedro Oliveira', servicos: 16, funcoes: 4 },
        { name: 'Ana', fullName: 'Ana Costa', servicos: 14, funcoes: 2 },
        { name: 'Carlos', fullName: 'Carlos Lima', servicos: 12, funcoes: 3 },
        { name: 'Lucia', fullName: 'Lucia Ferreira', servicos: 10, funcoes: 2 }
      ];

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Performance por Funcionário</CardTitle>
          <CardDescription>
            Ranking dos funcionários mais produtivos
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[300px]">
          <p className="text-muted-foreground">Nenhum dado disponível</p>
        </CardContent>
      </Card>
    );
  }

  const maxServicos = Math.max(...data.map(d => d.servicos));
  const topPerformer = data[0];
  
  const barColors = ['hsl(var(--primary))', 'hsl(var(--secondary))', 'hsl(var(--muted-foreground))'];

  return (
    <Card className="chart-card group hover:shadow-lg transition-all duration-300">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Award className="h-5 w-5 text-primary animate-bounce" />
              Performance por Funcionário
            </CardTitle>
            <CardDescription>
              Top {data.length} funcionários mais produtivos
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-primary animate-fade-in">
              {topPerformer?.servicos || 0}
            </div>
            <div className="text-xs text-muted-foreground">
              Líder em serviços
            </div>
          </div>
        </div>
        {topPerformer && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-primary/10 rounded-lg">
            <User className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">
              {topPerformer.fullName} - {topPerformer.servicos} serviços
            </span>
          </div>
        )}
      </CardHeader>
      <CardContent className="animate-fade-in">
        <ResponsiveContainer width="100%" height={320}>
          <BarChart 
            data={data} 
            layout="horizontal"
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="hsl(var(--border))" 
              opacity={0.3}
            />
            <XAxis 
              type="number"
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={false}
              tickLine={false}
              domain={[0, maxServicos + 2]}
            />
            <YAxis 
              type="category"
              dataKey="name" 
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={false}
              tickLine={false}
              width={70}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '12px',
                boxShadow: '0 10px 40px -10px hsl(var(--foreground) / 0.1)',
                color: 'hsl(var(--foreground))'
              }}
              formatter={(value, name, props) => {
                const employee = props.payload;
                return [
                  `${value} serviços executados`,
                  `${employee.fullName} (${employee.funcoes} funções)`
                ];
              }}
              labelFormatter={() => ''}
            />
            <Bar 
              dataKey="servicos" 
              name="servicos"
              radius={[0, 6, 6, 0]}
              animationDuration={1000}
              animationBegin={300}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={index === 0 ? 'hsl(var(--primary))' : 
                        index === 1 ? 'hsl(var(--secondary))' : 
                        index === 2 ? 'hsl(var(--accent))' : 
                        'hsl(var(--muted-foreground))'}
                  className="animate-pulse"
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="flex justify-between text-xs text-muted-foreground mt-2 pt-2 border-t">
          <span>Total: {data.reduce((sum, emp) => sum + emp.servicos, 0)} serviços</span>
          <span>Média: {Math.round(data.reduce((sum, emp) => sum + emp.servicos, 0) / data.length)} por funcionário</span>
        </div>
      </CardContent>
    </Card>
  );
}