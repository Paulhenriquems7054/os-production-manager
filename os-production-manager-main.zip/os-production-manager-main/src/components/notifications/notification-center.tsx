import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Bell, BellDot, Check, CheckCheck, Trash2, X, AlertTriangle } from 'lucide-react';
import { Notification } from '@/types/notifications';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface NotificationCenterProps {
  notifications: Notification[];
  unreadCount: number;
  criticalCount: number;
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onClear: (id: string) => void;
  onClearAll: () => void;
  onClose: () => void;
}

export function NotificationCenter({
  notifications,
  unreadCount,
  criticalCount,
  onMarkAsRead,
  onMarkAllAsRead,
  onClear,
  onClearAll,
  onClose
}: NotificationCenterProps) {
  const [filter, setFilter] = useState<'all' | 'unread' | 'critical'>('all');

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'unread') return !notification.read;
    if (filter === 'critical') return notification.priority === 'critical';
    return true;
  });

  const getPriorityColor = (priority: Notification['priority']) => {
    switch (priority) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'secondary';
    }
  };

  const getTypeIcon = (type: Notification['type']) => {
    switch (type) {
      case 'quality': return '🔍';
      case 'productivity': return '📊';
      case 'approval': return '✅';
      case 'material': return '📦';
      case 'system': return '⚙️';
      default: return '📋';
    }
  };

  return (
    <Card className="w-96 max-h-[600px] flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notificações
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-2">
                {unreadCount}
              </Badge>
            )}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            Todas ({notifications.length})
          </Button>
          <Button
            variant={filter === 'unread' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('unread')}
          >
            Não lidas ({unreadCount})
          </Button>
          <Button
            variant={filter === 'critical' ? 'destructive' : 'outline'}
            size="sm"
            onClick={() => setFilter('critical')}
          >
            Críticas ({criticalCount})
          </Button>
        </div>

        {notifications.length > 0 && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onMarkAllAsRead}>
              <CheckCheck className="h-4 w-4 mr-1" />
              Marcar todas lidas
            </Button>
            <Button variant="outline" size="sm" onClick={onClearAll}>
              <Trash2 className="h-4 w-4 mr-1" />
              Limpar todas
            </Button>
          </div>
        )}
      </CardHeader>

      <Separator />

      <CardContent className="p-0 flex-1">
        <ScrollArea className="h-[400px]">
          {filteredNotifications.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              {filter === 'all' && 'Nenhuma notificação'}
              {filter === 'unread' && 'Nenhuma notificação não lida'}
              {filter === 'critical' && 'Nenhuma notificação crítica'}
            </div>
          ) : (
            <div className="space-y-1">
              {filteredNotifications.map((notification, index) => (
                <div key={notification.id}>
                  <div
                    className={`p-4 hover:bg-muted/50 transition-colors ${
                      !notification.read ? 'bg-muted/30' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg">{getTypeIcon(notification.type)}</span>
                          <Badge 
                            variant={getPriorityColor(notification.priority)}
                            className="text-xs"
                          >
                            {notification.priority}
                          </Badge>
                          {notification.actionRequired && (
                            <Badge variant="outline" className="text-xs">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Ação necessária
                            </Badge>
                          )}
                          {!notification.read && (
                            <BellDot className="h-4 w-4 text-primary" />
                          )}
                        </div>
                        
                        <h4 className="font-medium text-sm mb-1 leading-snug">
                          {notification.title}
                        </h4>
                        
                        <p className="text-sm text-muted-foreground mb-2 leading-snug">
                          {notification.message}
                        </p>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(notification.createdAt), {
                              addSuffix: true,
                              locale: ptBR,
                            })}
                          </span>
                          
                          {notification.orderId && (
                            <Badge variant="outline" className="text-xs">
                              OS #{notification.orderId}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-col gap-1">
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onMarkAsRead(notification.id)}
                            title="Marcar como lida"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onClear(notification.id)}
                          title="Remover notificação"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {index < filteredNotifications.length - 1 && <Separator />}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}