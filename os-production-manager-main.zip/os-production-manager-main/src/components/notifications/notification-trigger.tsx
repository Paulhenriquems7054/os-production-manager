import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { NotificationCenter } from './notification-center';
import { Bell, BellDot } from 'lucide-react';
import { useNotifications } from '@/hooks/use-notifications';
import { ServiceOrder } from '@/types/order';

interface NotificationTriggerProps {
  orders: ServiceOrder[];
}

export function NotificationTrigger({ orders }: NotificationTriggerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const {
    notifications,
    unreadCount,
    criticalCount,
    markAsRead,
    markAllAsRead,
    clearNotification,
    clearAll,
    requestPermission,
    checkQualityIssues,
    checkProductivityAlerts,
    checkApprovalAlerts,
  } = useNotifications();

  // Request notification permission on mount
  useEffect(() => {
    requestPermission();
  }, [requestPermission]);

  // Check for new issues when orders change
  useEffect(() => {
    if (orders.length > 0) {
      checkQualityIssues(orders);
      checkProductivityAlerts(orders);
      checkApprovalAlerts(orders);
    }
  }, [orders, checkQualityIssues, checkProductivityAlerts, checkApprovalAlerts]);

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="relative">
          {unreadCount > 0 ? (
            <BellDot className="h-4 w-4" />
          ) : (
            <Bell className="h-4 w-4" />
          )}
          
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-fit p-0" align="end">
        <NotificationCenter
          notifications={notifications}
          unreadCount={unreadCount}
          criticalCount={criticalCount}
          onMarkAsRead={markAsRead}
          onMarkAllAsRead={markAllAsRead}
          onClear={clearNotification}
          onClearAll={clearAll}
          onClose={() => setIsOpen(false)}
        />
      </PopoverContent>
    </Popover>
  );
}