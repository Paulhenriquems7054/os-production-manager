import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { NotificationSettings } from '@/types/notifications';
import { Settings as SettingsIcon, Bell, Mail, Volume2, Webhook, TestTube } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface NotificationSettingsProps {
  settings: NotificationSettings;
  onUpdateSettings: (settings: Partial<NotificationSettings>) => void;
}

export function NotificationSettingsComponent({ settings, onUpdateSettings }: NotificationSettingsProps) {
  const [testWebhookLoading, setTestWebhookLoading] = useState(false);
  const { toast } = useToast();

  const handleTestWebhook = async () => {
    if (!settings.webhookUrl) {
      toast({
        title: "Erro",
        description: "Configure uma URL do webhook primeiro",
        variant: "destructive",
      });
      return;
    }

    setTestWebhookLoading(true);

    try {
      const response = await fetch(settings.webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        mode: "no-cors",
        body: JSON.stringify({
          test: true,
          title: "Teste de Webhook",
          message: "Este é um teste do sistema de notificações do OS Manager",
          timestamp: new Date().toISOString(),
          source: "OS Production Manager",
        }),
      });

      toast({
        title: "Webhook Enviado",
        description: "Verifique se o webhook foi recebido no Zapier",
      });
    } catch (error) {
      console.error("Erro ao testar webhook:", error);
      toast({
        title: "Erro",
        description: "Falha ao enviar webhook. Verifique a URL.",
        variant: "destructive",
      });
    } finally {
      setTestWebhookLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5" />
            Configurações de Notificações
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Configurações Gerais */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Configurações Gerais
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Notificações Push</Label>
                  <p className="text-sm text-muted-foreground">
                    Receber notificações do navegador
                  </p>
                </div>
                <Switch
                  checked={settings.enablePush}
                  onCheckedChange={(checked) => onUpdateSettings({ enablePush: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Som de Notificação</Label>
                  <p className="text-sm text-muted-foreground">
                    Tocar som para notificações críticas
                  </p>
                </div>
                <Switch
                  checked={settings.enableSound}
                  onCheckedChange={(checked) => onUpdateSettings({ enableSound: checked })}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Tipos de Alerta */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Tipos de Alerta</h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Alertas de Qualidade</Label>
                  <p className="text-sm text-muted-foreground">
                    Defeitos críticos e múltiplos retrabalhos
                  </p>
                </div>
                <Switch
                  checked={settings.qualityAlerts}
                  onCheckedChange={(checked) => onUpdateSettings({ qualityAlerts: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Alertas de Produtividade</Label>
                  <p className="text-sm text-muted-foreground">
                    Metas de produção não atingidas
                  </p>
                </div>
                <Switch
                  checked={settings.productivityAlerts}
                  onCheckedChange={(checked) => onUpdateSettings({ productivityAlerts: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Alertas de Aprovação</Label>
                  <p className="text-sm text-muted-foreground">
                    Muitas ordens aguardando aprovação
                  </p>
                </div>
                <Switch
                  checked={settings.approvalAlerts}
                  onCheckedChange={(checked) => onUpdateSettings({ approvalAlerts: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Alertas de Material</Label>
                  <p className="text-sm text-muted-foreground">
                    Estoque baixo e ferramentas
                  </p>
                </div>
                <Switch
                  checked={settings.materialAlerts}
                  onCheckedChange={(checked) => onUpdateSettings({ materialAlerts: checked })}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Integração Zapier */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Webhook className="h-5 w-5" />
              Integração Zapier
              <Badge variant="outline">Webhook</Badge>
            </h3>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="webhookUrl">URL do Webhook do Zapier</Label>
                <Input
                  id="webhookUrl"
                  placeholder="https://hooks.zapier.com/hooks/catch/..."
                  value={settings.webhookUrl || ''}
                  onChange={(e) => onUpdateSettings({ webhookUrl: e.target.value })}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Configure um webhook no Zapier para receber notificações por email, Slack, etc.
                </p>
              </div>

              {settings.webhookUrl && (
                <Button
                  variant="outline"
                  onClick={handleTestWebhook}
                  disabled={testWebhookLoading}
                  className="w-full"
                >
                  <TestTube className="h-4 w-4 mr-2" />
                  {testWebhookLoading ? 'Enviando...' : 'Testar Webhook'}
                </Button>
              )}
            </div>
          </div>

          <Separator />

          {/* Notificações por Email */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Notificações por Email
              <Badge variant="default" className="bg-green-600">Ativo</Badge>
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Ativar Email</Label>
                  <p className="text-sm text-muted-foreground">
                    Receber notificações por email
                  </p>
                </div>
                <Switch
                  checked={settings.enableEmail}
                  onCheckedChange={(checked) => onUpdateSettings({ enableEmail: checked })}
                />
              </div>

              <div>
                <Label htmlFor="emailRecipients">Destinatários</Label>
                <Textarea
                  id="emailRecipients"
                  placeholder="email1@empresa.com, email2@empresa.com"
                  value={settings.emailRecipients.join(', ')}
                  onChange={(e) => {
                    const emails = e.target.value
                      .split(',')
                      .map(email => email.trim())
                      .filter(email => email.length > 0);
                    onUpdateSettings({ emailRecipients: emails });
                  }}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Digite os emails separados por vírgula. Ex: joao@empresa.com, maria@empresa.com
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instruções Zapier */}
      <Card>
        <CardHeader>
          <CardTitle>Como configurar o Zapier</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm space-y-2">
            <p><strong>1.</strong> Acesse o Zapier e crie um novo Zap</p>
            <p><strong>2.</strong> Escolha "Webhooks by Zapier" como trigger</p>
            <p><strong>3.</strong> Selecione "Catch Hook" e copie a URL do webhook</p>
            <p><strong>4.</strong> Cole a URL no campo acima e teste</p>
            <p><strong>5.</strong> Configure a ação (email, Slack, etc.)</p>
            <p><strong>6.</strong> Ative o Zap</p>
          </div>
          
          <div className="bg-muted p-3 rounded-lg text-sm">
            <p className="font-medium mb-1">Dados enviados:</p>
            <code className="text-xs">
              {JSON.stringify({
                notification: {
                  title: "Título da notificação",
                  message: "Mensagem detalhada", 
                  type: "quality|productivity|approval|material",
                  priority: "low|medium|high|critical",
                  orderId: "12345"
                },
                timestamp: "2024-01-01T10:00:00Z",
                source: "OS Production Manager"
              }, null, 2)}
            </code>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}