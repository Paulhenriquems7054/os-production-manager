import * as React from 'react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, ArrowLeft, ChevronRight, BarChart3, FileText, Package, Shield } from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const slides = [
  {
    icon: BarChart3,
    title: "Sistema de Gestão Inteligente",
    description: "Tenha controle total da sua produção com dashboards em tempo real e relatórios detalhados.",
    image: "/lovable-uploads/8e2c22ab-7711-4fc6-a612-4fe42f054322.png"
  },
  {
    icon: FileText,
    title: "Ordens de Serviço Digitais",
    description: "Crie, gerencie e acompanhe todas as ordens de serviço em um só lugar, com geração automática de PDFs.",
    image: "/lovable-uploads/f8ac0261-0416-41ed-95ab-999cb3958579.png"
  },
  {
    icon: Package,
    title: "Controle de Materiais",
    description: "Gerencie estoques, movimentações e ferramentas com sistema completo de inventário.",
    image: "/lovable-uploads/6f4ef23e-e536-4a5f-b3e6-6fdbaee548f8.png"
  },
  {
    icon: Shield,
    title: "Qualidade Garantida",
    description: "Sistema de controle de qualidade integrado para garantir a excelência em todos os processos.",
    image: "/lovable-uploads/6f4ef23e-e536-4a5f-b3e6-6fdbaee548f8.png"
  }
];

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const slide = slides[currentSlide];
  const IconComponent = slide.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-30" />
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-primary/10 animate-pulse" />
        <div className="absolute top-32 right-20 w-16 h-16 rounded-full bg-accent/10 animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-20 left-1/4 w-12 h-12 rounded-full bg-primary/5 animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute bottom-32 right-1/3 w-14 h-14 rounded-full bg-accent/5 animate-pulse" style={{ animationDelay: '0.5s' }} />
      </div>
      
      <div className="w-full max-w-5xl mx-auto relative z-10">
        <Card className="modern-card border-0 shadow-2xl animate-scale-in">
          <CardContent className="p-0">
            <div className="grid md:grid-cols-2 gap-0 min-h-[600px]">
              {/* Conteúdo */}
              <div className="p-8 md:p-12 flex flex-col justify-center space-y-8 relative">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center shadow-lg">
                    <IconComponent className="w-8 h-8 text-primary animate-pulse-glow" />
                  </div>
                  <div className="flex flex-col">
                    <img 
                      src="/lovable-uploads/6f4ef23e-e536-4a5f-b3e6-6fdbaee548f8.png" 
                      alt="DClamps" 
                      className="h-10 w-auto filter drop-shadow-md"
                    />
                    <span className="text-xs text-muted-foreground mt-1 font-medium">Sistema de Gestão Industrial</span>
                  </div>
                </div>

                <div className="space-y-6">
                  <h1 className="text-4xl md:text-5xl font-bold gradient-text leading-tight">
                    {slide.title}
                  </h1>
                  <p className="text-xl text-muted-foreground leading-relaxed font-medium">
                    {slide.description}
                  </p>
                  <div className="flex items-center space-x-2 text-primary/70">
                    <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                    <span className="text-sm font-medium">Tecnologia de ponta para sua empresa</span>
                  </div>
                </div>

                {/* Indicadores de progresso */}
                <div className="flex space-x-3">
                  {slides.map((_, index) => (
                    <div
                      key={index}
                      className={`h-3 rounded-full transition-all duration-500 ease-out cursor-pointer hover:scale-110 ${
                        index === currentSlide 
                          ? 'w-12 bg-gradient-to-r from-primary to-accent shadow-lg' 
                          : 'w-3 bg-muted hover:bg-muted-foreground/20'
                      }`}
                      onClick={() => setCurrentSlide(index)}
                    />
                  ))}
                </div>

                {/* Botões de navegação */}
                <div className="flex items-center justify-between pt-6">
                  <Button
                    variant="ghost"
                    onClick={prevSlide}
                    disabled={currentSlide === 0}
                    className="button-hover text-muted-foreground hover:text-foreground disabled:opacity-30"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Anterior
                  </Button>

                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      onClick={onComplete}
                      className="button-hover border-border/50 hover:border-primary/50"
                    >
                      Pular
                    </Button>
                    <Button
                      onClick={nextSlide}
                      className="professional-button px-8 py-3 rounded-xl"
                    >
                      {currentSlide === slides.length - 1 ? 'Começar Agora' : 'Próximo'}
                      <ChevronRight className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Imagem/Visual */}
              <div className="bg-gradient-to-br from-primary/10 via-accent/5 to-primary/5 p-8 md:p-12 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/10 opacity-30" />
                
                {/* Elementos decorativos animados */}
                <div className="absolute top-8 right-8 w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-transparent animate-pulse" />
                <div className="absolute bottom-12 left-12 w-16 h-16 rounded-full bg-gradient-to-br from-accent/20 to-transparent animate-pulse" style={{ animationDelay: '1s' }} />
                <div className="absolute top-1/2 left-8 w-8 h-8 rounded-full bg-primary/30 animate-pulse" style={{ animationDelay: '2s' }} />
                <div className="absolute bottom-1/4 right-16 w-6 h-6 rounded-full bg-accent/40 animate-pulse" style={{ animationDelay: '0.5s' }} />
                
                <div className="relative z-10 text-center space-y-8">
                  <div className="w-40 h-40 mx-auto rounded-2xl bg-gradient-to-br from-primary/15 to-accent/10 flex items-center justify-center backdrop-blur-md border border-primary/20 shadow-2xl">
                    <IconComponent className="w-20 h-20 text-primary animate-pulse-glow" />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="inline-flex items-center space-x-2 px-4 py-2 bg-card/50 backdrop-blur-md rounded-full border border-border/30">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <span className="text-sm text-muted-foreground font-medium">
                        {currentSlide + 1} de {slides.length}
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-primary font-bold text-lg tracking-wide">
                        Sistema DClamps
                      </div>
                      <div className="text-xs text-muted-foreground max-w-48 mx-auto leading-relaxed">
                        Transformando a gestão industrial através da tecnologia
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}