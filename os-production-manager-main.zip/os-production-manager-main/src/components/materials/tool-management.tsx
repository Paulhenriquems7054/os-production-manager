import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Tool, ToolCheckout } from '@/types/materials';
import { Wrench, Plus, LogIn, LogOut, Edit2, Trash2, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ToolManagementProps {
  tools: Tool[];
  checkouts: ToolCheckout[];
  onAddTool: (tool: Omit<Tool, 'id'>) => void;
  onUpdateTool: (id: string, updates: Partial<Tool>) => void;
  onDeleteTool: (id: string) => void;
  onCheckoutTool: (checkout: Omit<ToolCheckout, 'id' | 'checkedOutAt'>) => void;
  onCheckinTool: (checkoutId: string, condition: ToolCheckout['condition'], notes?: string, damages?: string[]) => void;
}

export function ToolManagement({ 
  tools, 
  checkouts, 
  onAddTool, 
  onUpdateTool, 
  onDeleteTool, 
  onCheckoutTool, 
  onCheckinTool 
}: ToolManagementProps) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [checkoutDialog, setCheckoutDialog] = useState<{ tool: Tool; employee: string } | null>(null);
  const [checkinDialog, setCheckinDialog] = useState<{ checkout: ToolCheckout; condition: ToolCheckout['condition']; notes: string; damages: string[] } | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [newTool, setNewTool] = useState<Omit<Tool, 'id'>>({
    name: '',
    description: '',
    serialNumber: '',
    status: 'available',
    category: 'manual',
    condition: 'new',
    location: ''
  });

  const resetForm = () => {
    setNewTool({
      name: '',
      description: '',
      serialNumber: '',
      status: 'available',
      category: 'manual',
      condition: 'new',
      location: ''
    });
  };

  const handleAdd = () => {
    if (!newTool.name.trim()) return;
    onAddTool(newTool);
    resetForm();
    setIsAddOpen(false);
  };

  const handleCheckout = () => {
    if (!checkoutDialog) return;
    
    onCheckoutTool({
      toolId: checkoutDialog.tool.id,
      toolName: checkoutDialog.tool.name,
      employeeId: checkoutDialog.employee,
      condition: 'same'
    });
    
    setCheckoutDialog(null);
  };

  const handleCheckin = () => {
    if (!checkinDialog) return;
    
    const activeCheckout = checkouts.find(c => 
      c.toolId === checkinDialog.checkout.toolId && !c.checkedInAt
    );
    
    if (activeCheckout) {
      onCheckinTool(
        activeCheckout.id,
        checkinDialog.condition,
        checkinDialog.notes,
        checkinDialog.damages.length > 0 ? checkinDialog.damages : undefined
      );
    }
    
    setCheckinDialog(null);
  };

  const getStatusBadge = (tool: Tool) => {
    switch (tool.status) {
      case 'available':
        return <Badge variant="default">Disponível</Badge>;
      case 'in_use':
        return <Badge variant="secondary">Em Uso</Badge>;
      case 'maintenance':
        return <Badge variant="destructive">Manutenção</Badge>;
      case 'broken':
        return <Badge variant="destructive">Quebrada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  const getConditionBadge = (condition: Tool['condition']) => {
    switch (condition) {
      case 'new':
        return <Badge variant="default">Nova</Badge>;
      case 'good':
        return <Badge variant="default">Boa</Badge>;
      case 'fair':
        return <Badge variant="secondary">Regular</Badge>;
      case 'poor':
        return <Badge variant="destructive">Ruim</Badge>;
      default:
        return <Badge variant="outline">-</Badge>;
    }
  };

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.serialNumber?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || tool.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const availableTools = tools.filter(t => t.status === 'available').length;
  const toolsInUse = tools.filter(t => t.status === 'in_use').length;
  const toolsInMaintenance = tools.filter(t => t.status === 'maintenance').length;
  const activeCheckouts = checkouts.filter(c => !c.checkedInAt);

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Ferramentas</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tools.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disponíveis</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{availableTools}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Uso</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{toolsInUse}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Manutenção</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{toolsInMaintenance}</div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Wrench className="h-5 w-5" />
              Gestão de Ferramentas
            </CardTitle>
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Ferramenta
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Nova Ferramenta</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Nome</Label>
                    <Input
                      value={newTool.name}
                      onChange={(e) => setNewTool({...newTool, name: e.target.value})}
                      placeholder="Nome da ferramenta"
                    />
                  </div>
                  <div>
                    <Label>Descrição</Label>
                    <Input
                      value={newTool.description}
                      onChange={(e) => setNewTool({...newTool, description: e.target.value})}
                      placeholder="Descrição da ferramenta"
                    />
                  </div>
                  <div>
                    <Label>Número de Série</Label>
                    <Input
                      value={newTool.serialNumber}
                      onChange={(e) => setNewTool({...newTool, serialNumber: e.target.value})}
                      placeholder="Número de série"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Categoria</Label>
                      <Select 
                        value={newTool.category} 
                        onValueChange={(value: Tool['category']) => setNewTool({...newTool, category: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cutting">Corte</SelectItem>
                          <SelectItem value="measuring">Medição</SelectItem>
                          <SelectItem value="safety">Segurança</SelectItem>
                          <SelectItem value="pneumatic">Pneumática</SelectItem>
                          <SelectItem value="electric">Elétrica</SelectItem>
                          <SelectItem value="manual">Manual</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Condição</Label>
                      <Select 
                        value={newTool.condition} 
                        onValueChange={(value: Tool['condition']) => setNewTool({...newTool, condition: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">Nova</SelectItem>
                          <SelectItem value="good">Boa</SelectItem>
                          <SelectItem value="fair">Regular</SelectItem>
                          <SelectItem value="poor">Ruim</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Localização</Label>
                    <Input
                      value={newTool.location}
                      onChange={(e) => setNewTool({...newTool, location: e.target.value})}
                      placeholder="Localização da ferramenta"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={handleAdd} className="flex-1">
                      Adicionar
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddOpen(false)}>
                      Cancelar
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Input
              placeholder="Buscar ferramentas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="available">Disponível</SelectItem>
                <SelectItem value="in_use">Em Uso</SelectItem>
                <SelectItem value="maintenance">Manutenção</SelectItem>
                <SelectItem value="broken">Quebrada</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ferramenta</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Condição</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTools.map((tool) => (
                <TableRow key={tool.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{tool.name}</div>
                      {tool.description && (
                        <div className="text-sm text-muted-foreground">{tool.description}</div>
                      )}
                      {tool.serialNumber && (
                        <div className="text-xs text-muted-foreground">S/N: {tool.serialNumber}</div>
                      )}
                      {tool.location && (
                        <div className="text-xs text-muted-foreground">📍 {tool.location}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{tool.category}</Badge>
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(tool)}
                  </TableCell>
                  <TableCell>
                    {getConditionBadge(tool.condition)}
                  </TableCell>
                  <TableCell>
                    {tool.currentUser ? (
                      <div>
                        <div className="font-medium">{tool.currentUser}</div>
                        {tool.checkoutTime && (
                          <div className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(tool.checkoutTime), { 
                              addSuffix: true, 
                              locale: ptBR 
                            })}
                          </div>
                        )}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      {tool.status === 'available' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setCheckoutDialog({ tool, employee: '' })}
                        >
                          <LogOut className="h-4 w-4" />
                        </Button>
                      )}
                      {tool.status === 'in_use' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setCheckinDialog({ 
                            checkout: { toolId: tool.id } as ToolCheckout, 
                            condition: 'same', 
                            notes: '', 
                            damages: [] 
                          })}
                        >
                          <LogIn className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDeleteTool(tool.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Checkout Dialog */}
      {checkoutDialog && (
        <Dialog open={!!checkoutDialog} onOpenChange={() => setCheckoutDialog(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Empréstimo de Ferramenta</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Ferramenta</Label>
                <Input value={checkoutDialog.tool.name} disabled />
              </div>
              <div>
                <Label>Funcionário</Label>
                <Input
                  value={checkoutDialog.employee}
                  onChange={(e) => setCheckoutDialog({...checkoutDialog, employee: e.target.value})}
                  placeholder="Nome do funcionário"
                />
              </div>
              <div className="flex gap-3">
                <Button onClick={handleCheckout} className="flex-1" disabled={!checkoutDialog.employee.trim()}>
                  Emprestar
                </Button>
                <Button variant="outline" onClick={() => setCheckoutDialog(null)}>
                  Cancelar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Checkin Dialog */}
      {checkinDialog && (
        <Dialog open={!!checkinDialog} onOpenChange={() => setCheckinDialog(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Devolução de Ferramenta</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Condição da Ferramenta</Label>
                <Select 
                  value={checkinDialog.condition} 
                  onValueChange={(value: ToolCheckout['condition']) => 
                    setCheckinDialog({...checkinDialog, condition: value})
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="same">Mesma condição</SelectItem>
                    <SelectItem value="worse">Condição pior</SelectItem>
                    <SelectItem value="damaged">Danificada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Observações</Label>
                <Textarea
                  value={checkinDialog.notes}
                  onChange={(e) => setCheckinDialog({...checkinDialog, notes: e.target.value})}
                  placeholder="Observações sobre o uso..."
                  rows={3}
                />
              </div>
              {checkinDialog.condition === 'damaged' && (
                <div>
                  <Label>Danos Identificados</Label>
                  <Textarea
                    value={checkinDialog.damages.join('\n')}
                    onChange={(e) => setCheckinDialog({
                      ...checkinDialog, 
                      damages: e.target.value.split('\n').filter(d => d.trim())
                    })}
                    placeholder="Liste os danos identificados..."
                    rows={3}
                  />
                </div>
              )}
              <div className="flex gap-3">
                <Button onClick={handleCheckin} className="flex-1">
                  Devolver
                </Button>
                <Button variant="outline" onClick={() => setCheckinDialog(null)}>
                  Cancelar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}