import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MaterialInventory } from './material-inventory';
import { ToolManagement } from './tool-management';
import { useMaterials } from '@/hooks/use-materials';
import { Package, Wrench, BarChart3, AlertTriangle } from 'lucide-react';

export function MaterialsDashboard() {
  const {
    materials,
    tools,
    consumptions,
    checkouts,
    alerts,
    addMaterial,
    updateMaterial,
    deleteMaterial,
    addTool,
    updateTool,
    deleteTool,
    checkoutTool,
    checkinTool,
    acknowledgeAlert,
  } = useMaterials();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Gestão de Materiais e Ferramentas</h2>
          <p className="text-muted-foreground">
            Controle de estoque, ferramentas e consumo de materiais
          </p>
        </div>
        {alerts.length > 0 && (
          <div className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="h-5 w-5" />
            <span className="font-medium">{alerts.length} alerta(s) pendente(s)</span>
          </div>
        )}
      </div>

      <Tabs defaultValue="materials" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="materials" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            Materiais
          </TabsTrigger>
          <TabsTrigger value="tools" className="flex items-center gap-2">
            <Wrench className="h-4 w-4" />
            Ferramentas
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Análises
          </TabsTrigger>
        </TabsList>

        <TabsContent value="materials">
          <MaterialInventory
            materials={materials}
            onAddMaterial={addMaterial}
            onUpdateMaterial={updateMaterial}
            onDeleteMaterial={deleteMaterial}
          />
        </TabsContent>

        <TabsContent value="tools">
          <ToolManagement
            tools={tools}
            checkouts={checkouts}
            onAddTool={addTool}
            onUpdateTool={updateTool}
            onDeleteTool={deleteTool}
            onCheckoutTool={checkoutTool}
            onCheckinTool={checkinTool}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <div className="text-center py-12 text-muted-foreground">
            <BarChart3 className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Análises em Desenvolvimento</h3>
            <p>Relatórios de consumo e análises avançadas serão disponibilizados em breve.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}