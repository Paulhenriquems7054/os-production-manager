import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Material } from '@/types/materials';
import { Package, Plus, Edit2, Trash2, AlertTriangle, TrendingDown, TrendingUp } from 'lucide-react';

interface MaterialInventoryProps {
  materials: Material[];
  onAddMaterial: (material: Omit<Material, 'id'>) => void;
  onUpdateMaterial: (id: string, updates: Partial<Material>) => void;
  onDeleteMaterial: (id: string) => void;
}

export function MaterialInventory({ materials, onAddMaterial, onUpdateMaterial, onDeleteMaterial }: MaterialInventoryProps) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const [newMaterial, setNewMaterial] = useState<Omit<Material, 'id'>>({
    name: '',
    description: '',
    unit: 'pcs',
    currentStock: 0,
    minStock: 0,
    maxStock: 0,
    unitCost: 0,
    supplier: '',
    location: '',
    category: 'other'
  });

  const resetForm = () => {
    setNewMaterial({
      name: '',
      description: '',
      unit: 'pcs',
      currentStock: 0,
      minStock: 0,
      maxStock: 0,
      unitCost: 0,
      supplier: '',
      location: '',
      category: 'other'
    });
  };

  const handleAdd = () => {
    if (!newMaterial.name.trim()) return;
    onAddMaterial(newMaterial);
    resetForm();
    setIsAddOpen(false);
  };

  const handleUpdate = () => {
    if (!editingMaterial) return;
    onUpdateMaterial(editingMaterial.id, editingMaterial);
    setEditingMaterial(null);
  };

  const getStockStatus = (material: Material) => {
    if (material.currentStock === 0) return 'out';
    if (material.currentStock <= material.minStock) return 'low';
    if (material.currentStock >= material.maxStock * 0.8) return 'high';
    return 'normal';
  };

  const getStockBadge = (material: Material) => {
    const status = getStockStatus(material);
    switch (status) {
      case 'out':
        return <Badge variant="destructive">Esgotado</Badge>;
      case 'low':
        return <Badge variant="destructive">Baixo</Badge>;
      case 'high':
        return <Badge variant="default">Alto</Badge>;
      default:
        return <Badge variant="secondary">Normal</Badge>;
    }
  };

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || material.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const lowStockMaterials = materials.filter(m => m.currentStock <= m.minStock);
  const totalValue = materials.reduce((sum, m) => sum + (m.currentStock * m.unitCost), 0);

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Materiais</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{materials.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estoque Baixo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{lowStockMaterials.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totalValue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Itens Críticos</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {materials.filter(m => m.currentStock === 0).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Inventário de Materiais
            </CardTitle>
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Material
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Novo Material</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Nome</Label>
                    <Input
                      value={newMaterial.name}
                      onChange={(e) => setNewMaterial({...newMaterial, name: e.target.value})}
                      placeholder="Nome do material"
                    />
                  </div>
                  <div>
                    <Label>Descrição</Label>
                    <Input
                      value={newMaterial.description}
                      onChange={(e) => setNewMaterial({...newMaterial, description: e.target.value})}
                      placeholder="Descrição do material"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Unidade</Label>
                      <Select 
                        value={newMaterial.unit} 
                        onValueChange={(value: Material['unit']) => setNewMaterial({...newMaterial, unit: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="kg">kg</SelectItem>
                          <SelectItem value="g">g</SelectItem>
                          <SelectItem value="l">l</SelectItem>
                          <SelectItem value="ml">ml</SelectItem>
                          <SelectItem value="pcs">pcs</SelectItem>
                          <SelectItem value="m">m</SelectItem>
                          <SelectItem value="cm">cm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Categoria</Label>
                      <Select 
                        value={newMaterial.category} 
                        onValueChange={(value: Material['category']) => setNewMaterial({...newMaterial, category: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="metal">Metal</SelectItem>
                          <SelectItem value="chemical">Químico</SelectItem>
                          <SelectItem value="tool">Ferramenta</SelectItem>
                          <SelectItem value="consumable">Consumível</SelectItem>
                          <SelectItem value="safety">Segurança</SelectItem>
                          <SelectItem value="other">Outro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label>Estoque Atual</Label>
                      <Input
                        type="number"
                        value={newMaterial.currentStock}
                        onChange={(e) => setNewMaterial({...newMaterial, currentStock: parseFloat(e.target.value) || 0})}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Label>Estoque Mín.</Label>
                      <Input
                        type="number"
                        value={newMaterial.minStock}
                        onChange={(e) => setNewMaterial({...newMaterial, minStock: parseFloat(e.target.value) || 0})}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Label>Estoque Máx.</Label>
                      <Input
                        type="number"
                        value={newMaterial.maxStock}
                        onChange={(e) => setNewMaterial({...newMaterial, maxStock: parseFloat(e.target.value) || 0})}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Custo Unitário (R$)</Label>
                    <Input
                      type="number"
                      value={newMaterial.unitCost}
                      onChange={(e) => setNewMaterial({...newMaterial, unitCost: parseFloat(e.target.value) || 0})}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <Label>Fornecedor</Label>
                    <Input
                      value={newMaterial.supplier}
                      onChange={(e) => setNewMaterial({...newMaterial, supplier: e.target.value})}
                      placeholder="Nome do fornecedor"
                    />
                  </div>
                  <div>
                    <Label>Localização</Label>
                    <Input
                      value={newMaterial.location}
                      onChange={(e) => setNewMaterial({...newMaterial, location: e.target.value})}
                      placeholder="Localização no estoque"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={handleAdd} className="flex-1">
                      Adicionar
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddOpen(false)}>
                      Cancelar
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Input
              placeholder="Buscar materiais..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="metal">Metal</SelectItem>
                <SelectItem value="chemical">Químico</SelectItem>
                <SelectItem value="tool">Ferramenta</SelectItem>
                <SelectItem value="consumable">Consumível</SelectItem>
                <SelectItem value="safety">Segurança</SelectItem>
                <SelectItem value="other">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Material</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Estoque</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMaterials.map((material) => (
                <TableRow key={material.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{material.name}</div>
                      {material.description && (
                        <div className="text-sm text-muted-foreground">{material.description}</div>
                      )}
                      {material.location && (
                        <div className="text-xs text-muted-foreground">📍 {material.location}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{material.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {material.currentStock} {material.unit}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Min: {material.minStock} | Max: {material.maxStock}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    {getStockBadge(material)}
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        R$ {(material.currentStock * material.unitCost).toFixed(2)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Unit: R$ {material.unitCost.toFixed(2)}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingMaterial(material)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDeleteMaterial(material.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      {editingMaterial && (
        <Dialog open={!!editingMaterial} onOpenChange={() => setEditingMaterial(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Material</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Nome</Label>
                <Input
                  value={editingMaterial.name}
                  onChange={(e) => setEditingMaterial({...editingMaterial, name: e.target.value})}
                />
              </div>
              <div>
                <Label>Estoque Atual</Label>
                <Input
                  type="number"
                  value={editingMaterial.currentStock}
                  onChange={(e) => setEditingMaterial({...editingMaterial, currentStock: parseFloat(e.target.value) || 0})}
                  min="0"
                  step="0.1"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Estoque Mín.</Label>
                  <Input
                    type="number"
                    value={editingMaterial.minStock}
                    onChange={(e) => setEditingMaterial({...editingMaterial, minStock: parseFloat(e.target.value) || 0})}
                    min="0"
                    step="0.1"
                  />
                </div>
                <div>
                  <Label>Estoque Máx.</Label>
                  <Input
                    type="number"
                    value={editingMaterial.maxStock}
                    onChange={(e) => setEditingMaterial({...editingMaterial, maxStock: parseFloat(e.target.value) || 0})}
                    min="0"
                    step="0.1"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Button onClick={handleUpdate} className="flex-1">
                  Salvar
                </Button>
                <Button variant="outline" onClick={() => setEditingMaterial(null)}>
                  Cancelar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}