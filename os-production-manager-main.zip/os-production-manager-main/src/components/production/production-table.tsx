import * as React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ProductionRecord } from '@/types/production';
import { Edit, Trash2, Eye } from 'lucide-react';

interface ProductionTableProps {
  records: ProductionRecord[];
  onEdit?: (record: ProductionRecord) => void;
  onDelete?: (id: string) => void;
  onView?: (record: ProductionRecord) => void;
}

export function ProductionTable({ records, onEdit, onDelete, onView }: ProductionTableProps) {
  const getServicesSummary = (record: ProductionRecord) => {
    const services = [];
    if (record.suspensorTC1A) services.push('Suspensor TC1A');
    if (record.suspensorT16) services.push('Suspensor T16');
    if (record.anelSuspensor) services.push('Anel suspensor');
    if (record.luva) services.push('Luva');
    if (record.nipleLongo) services.push('Niple Longo');
    if (record.difusor) services.push('Difusor');
    if (record.packer) services.push('Packer');
    if (record.valvulaDreno) services.push('Válvula Dreno');
    if (record.valvulaCheck) services.push('Válvula Check');
    if (record.desareador) services.push('Desareador');
    if (record.tuboFiltro) services.push('Tubo Filtro');
    if (record.acoplamentos) services.push('Acoplamentos');
    if (record.cabecaDescarga) services.push('Cabeça descarga');
    if (record.outroServico) services.push('Outro serviço');
    
    return services.length > 0 ? services.join(', ') : 'Nenhum serviço específico';
  };

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Data/Hora</TableHead>
            <TableHead>Executante</TableHead>
            <TableHead>Função</TableHead>
            <TableHead>Supervisor</TableHead>
            <TableHead>Serviços</TableHead>
            <TableHead>Outro Serviço</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {records.map((record) => (
            <TableRow key={record.id}>
              <TableCell className="font-medium">
                {record.timestamp}
              </TableCell>
              <TableCell>{record.executante}</TableCell>
              <TableCell>
                <Badge variant="outline">{record.funcao}</Badge>
              </TableCell>
              <TableCell>{record.supervisor}</TableCell>
              <TableCell className="max-w-xs truncate" title={getServicesSummary(record)}>
                {getServicesSummary(record)}
              </TableCell>
              <TableCell>
                <Badge 
                  variant={record.colaboradorOutroServico === 'SIM' ? 'default' : 'secondary'}
                >
                  {record.colaboradorOutroServico}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex gap-1 justify-end">
                  {onView && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onView(record)}
                      className="h-8 w-8 p-0"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                  {onEdit && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEdit(record)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  )}
                  {onDelete && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(record.id)}
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
          {records.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                Nenhum registro encontrado
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}