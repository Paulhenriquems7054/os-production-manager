import * as React from 'react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ProductionFormData } from '@/types/production';
import { Save, X } from 'lucide-react';

interface ProductionFormProps {
  onSave: (data: ProductionFormData) => void;
  onCancel: () => void;
}

export function ProductionForm({ onSave, onCancel }: ProductionFormProps) {
  const [formData, setFormData] = useState<ProductionFormData>({
    executante: '',
    funcao: '',
    supervisor: '',
    colaboradorOutroServico: 'NÃO'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleInputChange = (field: keyof ProductionFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Novo Registro de Produção</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="executante">Executante</Label>
              <Input
                id="executante"
                value={formData.executante}
                onChange={(e) => handleInputChange('executante', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="funcao">Função</Label>
              <Select value={formData.funcao} onValueChange={(value) => handleInputChange('funcao', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Torneiro">Torneiro</SelectItem>
                  <SelectItem value="Fresador">Fresador</SelectItem>
                  <SelectItem value="Supervisor">Supervisor</SelectItem>
                  <SelectItem value="Soldador">Soldador</SelectItem>
                  <SelectItem value="Ajudante">Ajudante</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="supervisor">Supervisor</Label>
              <Input
                id="supervisor"
                value={formData.supervisor}
                onChange={(e) => handleInputChange('supervisor', e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Peças 1</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="suspensorTC1A">Suspensor TC1A</Label>
                <Input
                  id="suspensorTC1A"
                  value={formData.suspensorTC1A || ''}
                  onChange={(e) => handleInputChange('suspensorTC1A', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="suspensorT16">Suspensor T16</Label>
                <Input
                  id="suspensorT16"
                  value={formData.suspensorT16 || ''}
                  onChange={(e) => handleInputChange('suspensorT16', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="anelSuspensor">Anel para suspensor</Label>
                <Input
                  id="anelSuspensor"
                  value={formData.anelSuspensor || ''}
                  onChange={(e) => handleInputChange('anelSuspensor', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="luva">Luva</Label>
                <Input
                  id="luva"
                  value={formData.luva || ''}
                  onChange={(e) => handleInputChange('luva', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="nipleLongo">Niple Longo</Label>
                <Input
                  id="nipleLongo"
                  value={formData.nipleLongo || ''}
                  onChange={(e) => handleInputChange('nipleLongo', e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Peças 2</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="difusor">Difusor</Label>
                <Input
                  id="difusor"
                  value={formData.difusor || ''}
                  onChange={(e) => handleInputChange('difusor', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="packer">Packer</Label>
                <Input
                  id="packer"
                  value={formData.packer || ''}
                  onChange={(e) => handleInputChange('packer', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="valvulaDreno">Válvula Dreno</Label>
                <Input
                  id="valvulaDreno"
                  value={formData.valvulaDreno || ''}
                  onChange={(e) => handleInputChange('valvulaDreno', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="valvulaCheck">Válvula Check</Label>
                <Input
                  id="valvulaCheck"
                  value={formData.valvulaCheck || ''}
                  onChange={(e) => handleInputChange('valvulaCheck', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="desareador">Desareador</Label>
                <Input
                  id="desareador"
                  value={formData.desareador || ''}
                  onChange={(e) => handleInputChange('desareador', e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Tubo Filtro e Peças 3</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="tuboFiltro">Tubo Filtro</Label>
                <Input
                  id="tuboFiltro"
                  value={formData.tuboFiltro || ''}
                  onChange={(e) => handleInputChange('tuboFiltro', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="acoplamentos">Acoplamentos</Label>
                <Input
                  id="acoplamentos"
                  value={formData.acoplamentos || ''}
                  onChange={(e) => handleInputChange('acoplamentos', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="cabecaDescarga">Cabeça de descarga</Label>
                <Input
                  id="cabecaDescarga"
                  value={formData.cabecaDescarga || ''}
                  onChange={(e) => handleInputChange('cabecaDescarga', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="outroServico">Outro serviço</Label>
                <Input
                  id="outroServico"
                  value={formData.outroServico || ''}
                  onChange={(e) => handleInputChange('outroServico', e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="colaboradorOutroServico">O colaborador fará outro serviço?</Label>
              <Select
                value={formData.colaboradorOutroServico}
                onValueChange={(value: 'SIM' | 'NÃO') => handleInputChange('colaboradorOutroServico', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="SIM">SIM</SelectItem>
                  <SelectItem value="NÃO">NÃO</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes || ''}
                onChange={(e) => handleInputChange('observacoes', e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="submit" className="flex items-center gap-2">
              <Save className="w-4 h-4" />
              Salvar Registro
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex items-center gap-2">
              <X className="w-4 h-4" />
              Cancelar
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}