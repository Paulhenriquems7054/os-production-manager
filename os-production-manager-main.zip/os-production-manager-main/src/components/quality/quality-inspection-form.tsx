import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ServiceOrder, QualityCheck, QualityChecklistItem, QualityDefect } from '@/types/order';
import { CheckCircle, XCircle, AlertTriangle, Plus, Trash2 } from 'lucide-react';

interface QualityInspectionFormProps {
  order: ServiceOrder;
  onSubmit: (qualityCheck: QualityCheck) => void;
  onCancel: () => void;
}

const defaultChecklistItems: QualityChecklistItem[] = [
  { id: '1', description: 'Dimensões conforme especificação', checked: false, required: true },
  { id: '2', description: 'Acabamento superficial adequado', checked: false, required: true },
  { id: '3', description: 'Ausência de rebarbas', checked: false, required: true },
  { id: '4', description: 'Roscas dentro do padrão', checked: false, required: false },
  { id: '5', description: 'Material conforme especificação', checked: false, required: true },
  { id: '6', description: 'Tratamento térmico adequado', checked: false, required: false },
];

export function QualityInspectionForm({ order, onSubmit, onCancel }: QualityInspectionFormProps) {
  const [inspector, setInspector] = useState('');
  const [checklistItems, setChecklistItems] = useState<QualityChecklistItem[]>(defaultChecklistItems);
  const [defects, setDefects] = useState<QualityDefect[]>([]);
  const [notes, setNotes] = useState('');
  const [newDefect, setNewDefect] = useState<Partial<QualityDefect>>({});

  const handleChecklistChange = (itemId: string, checked: boolean) => {
    setChecklistItems(items =>
      items.map(item =>
        item.id === itemId ? { ...item, checked } : item
      )
    );
  };

  const addDefect = () => {
    if (newDefect.description && newDefect.type && newDefect.severity) {
      const defect: QualityDefect = {
        id: Date.now().toString(),
        type: newDefect.type as QualityDefect['type'],
        description: newDefect.description,
        severity: newDefect.severity as QualityDefect['severity'],
        location: newDefect.location || '',
      };
      setDefects([...defects, defect]);
      setNewDefect({});
    }
  };

  const removeDefect = (defectId: string) => {
    setDefects(defects.filter(d => d.id !== defectId));
  };

  const getQualityResult = (): QualityCheck['result'] => {
    const requiredItemsChecked = checklistItems
      .filter(item => item.required)
      .every(item => item.checked);
    
    const hasCriticalDefects = defects.some(d => d.severity === 'critical');
    const hasHighDefects = defects.some(d => d.severity === 'high');

    if (hasCriticalDefects) return 'rejected';
    if (hasHighDefects || !requiredItemsChecked) return 'rework_required';
    return 'approved';
  };

  const handleSubmit = () => {
    const qualityCheck: QualityCheck = {
      id: Date.now().toString(),
      orderId: order.id,
      inspector,
      checklistItems,
      defects,
      result: getQualityResult(),
      notes,
      checkedAt: new Date().toISOString(),
    };
    onSubmit(qualityCheck);
  };

  const result = getQualityResult();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-primary" />
            Inspeção de Qualidade - OS #{order.id}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><strong>Funcionário:</strong> {order.employee}</div>
            <div><strong>Peça:</strong> {order.piece}</div>
            <div><strong>Serviço:</strong> {order.serviceName}</div>
            <div><strong>Quantidade:</strong> {order.quantity}</div>
          </div>
          
          <div>
            <Label htmlFor="inspector">Inspetor Responsável</Label>
            <Input
              id="inspector"
              value={inspector}
              onChange={(e) => setInspector(e.target.value)}
              placeholder="Nome do inspetor"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Checklist de Qualidade</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {checklistItems.map((item) => (
            <div key={item.id} className="flex items-center space-x-3">
              <Checkbox
                id={item.id}
                checked={item.checked}
                onCheckedChange={(checked) => handleChecklistChange(item.id, !!checked)}
              />
              <Label htmlFor={item.id} className="flex-1">
                {item.description}
                {item.required && <Badge variant="outline" className="ml-2">Obrigatório</Badge>}
              </Label>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Defeitos Identificados</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {defects.map((defect) => (
            <div key={defect.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={defect.severity === 'critical' ? 'destructive' : 
                                defect.severity === 'high' ? 'destructive' :
                                defect.severity === 'medium' ? 'default' : 'secondary'}>
                    {defect.severity}
                  </Badge>
                  <Badge variant="outline">{defect.type}</Badge>
                </div>
                <p className="text-sm">{defect.description}</p>
                {defect.location && <p className="text-xs text-muted-foreground">Local: {defect.location}</p>}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeDefect(defect.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}

          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Adicionar Defeito</h4>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <Select value={newDefect.type} onValueChange={(value) => setNewDefect({...newDefect, type: value as QualityDefect['type']})}>
                <SelectTrigger>
                  <SelectValue placeholder="Tipo do defeito" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dimensional">Dimensional</SelectItem>
                  <SelectItem value="surface">Superfície</SelectItem>
                  <SelectItem value="material">Material</SelectItem>
                  <SelectItem value="assembly">Montagem</SelectItem>
                  <SelectItem value="other">Outro</SelectItem>
                </SelectContent>
              </Select>

              <Select value={newDefect.severity} onValueChange={(value) => setNewDefect({...newDefect, severity: value as QualityDefect['severity']})}>
                <SelectTrigger>
                  <SelectValue placeholder="Severidade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baixa</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="critical">Crítica</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Input
              placeholder="Descrição do defeito"
              value={newDefect.description || ''}
              onChange={(e) => setNewDefect({...newDefect, description: e.target.value})}
              className="mb-3"
            />

            <Input
              placeholder="Localização (opcional)"
              value={newDefect.location || ''}
              onChange={(e) => setNewDefect({...newDefect, location: e.target.value})}
              className="mb-3"
            />

            <Button onClick={addDefect} variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Defeito
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Observações</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Observações adicionais sobre a inspeção..."
            rows={3}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {result === 'approved' && <CheckCircle className="h-5 w-5 text-green-500" />}
            {result === 'rejected' && <XCircle className="h-5 w-5 text-red-500" />}
            {result === 'rework_required' && <AlertTriangle className="h-5 w-5 text-yellow-500" />}
            Resultado da Inspeção
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Badge variant={result === 'approved' ? 'default' : 
                        result === 'rejected' ? 'destructive' : 'secondary'}
                 className="text-base px-4 py-2">
            {result === 'approved' && 'Aprovado'}
            {result === 'rejected' && 'Rejeitado'}
            {result === 'rework_required' && 'Retrabalho Necessário'}
          </Badge>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button onClick={handleSubmit} disabled={!inspector}>
          Confirmar Inspeção
        </Button>
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
      </div>
    </div>
  );
}