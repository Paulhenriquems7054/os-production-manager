import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ServiceOrder } from '@/types/order';
import { QualityInspectionForm } from './quality-inspection-form';
import { CheckCircle, XCircle, AlertTriangle, Clock, BarChart3, TrendingUp } from 'lucide-react';

interface QualityDashboardProps {
  orders: ServiceOrder[];
  onUpdateOrder: (order: ServiceOrder) => void;
}

export function QualityDashboard({ orders, onUpdateOrder }: QualityDashboardProps) {
  const [selectedOrder, setSelectedOrder] = useState<ServiceOrder | null>(null);

  // Filtrar ordens que precisam de inspeção
  const ordersAwaitingQuality = orders.filter(order => 
    order.status === 'completed' || order.status === 'awaiting_quality'
  );

  const ordersWithQuality = orders.filter(order => 
    order.qualityCheck && ['quality_approved', 'quality_rejected', 'rework'].includes(order.status)
  );

  // Estatísticas de qualidade
  const qualityStats = {
    total: ordersWithQuality.length,
    approved: ordersWithQuality.filter(o => o.status === 'quality_approved').length,
    rejected: ordersWithQuality.filter(o => o.status === 'quality_rejected').length,
    rework: ordersWithQuality.filter(o => o.status === 'rework').length,
    pending: ordersAwaitingQuality.length,
  };

  const qualityRate = qualityStats.total > 0 
    ? ((qualityStats.approved / qualityStats.total) * 100).toFixed(1)
    : '0';

  const reworkRate = qualityStats.total > 0 
    ? ((qualityStats.rework / qualityStats.total) * 100).toFixed(1)
    : '0';

  const handleQualitySubmit = (qualityCheck: any) => {
    if (!selectedOrder) return;

    const newStatus = qualityCheck.result === 'approved' ? 'quality_approved' :
                     qualityCheck.result === 'rejected' ? 'quality_rejected' : 'rework';

    const updatedOrder: ServiceOrder = {
      ...selectedOrder,
      status: newStatus,
      qualityCheck,
      reworkCount: newStatus === 'rework' ? (selectedOrder.reworkCount || 0) + 1 : selectedOrder.reworkCount,
      reworkHistory: newStatus === 'rework' ? [
        ...(selectedOrder.reworkHistory || []),
        {
          reason: qualityCheck.notes || 'Retrabalho necessário',
          date: new Date().toISOString(),
          inspector: qualityCheck.inspector
        }
      ] : selectedOrder.reworkHistory
    };

    onUpdateOrder(updatedOrder);
    setSelectedOrder(null);
  };

  if (selectedOrder) {
    return (
      <QualityInspectionForm
        order={selectedOrder}
        onSubmit={handleQualitySubmit}
        onCancel={() => setSelectedOrder(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Qualidade</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{qualityRate}%</div>
            <p className="text-xs text-muted-foreground">
              {qualityStats.approved} de {qualityStats.total} aprovadas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Retrabalho</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{reworkRate}%</div>
            <p className="text-xs text-muted-foreground">
              {qualityStats.rework} retrabalhos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{qualityStats.pending}</div>
            <p className="text-xs text-muted-foreground">
              Aguardando inspeção
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Inspecionado</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{qualityStats.total}</div>
            <p className="text-xs text-muted-foreground">
              Ordens processadas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Ordens aguardando inspeção */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Ordens Aguardando Inspeção de Qualidade ({ordersAwaitingQuality.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {ordersAwaitingQuality.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">
              Nenhuma ordem aguardando inspeção
            </p>
          ) : (
            <div className="space-y-3">
              {ordersAwaitingQuality.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-medium">OS #{order.id}</span>
                      <Badge variant="outline">{order.employee}</Badge>
                      <Badge>{order.piece}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {order.serviceName} - Qtd: {order.quantity}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Concluído em: {new Date(order.endTime).toLocaleString('pt-BR')}
                    </p>
                  </div>
                  <Button onClick={() => setSelectedOrder(order)}>
                    Iniciar Inspeção
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Histórico de inspeções */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Histórico de Inspeções
          </CardTitle>
        </CardHeader>
        <CardContent>
          {ordersWithQuality.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">
              Nenhuma inspeção realizada ainda
            </p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {ordersWithQuality
                .sort((a, b) => new Date(b.qualityCheck?.checkedAt || '').getTime() - new Date(a.qualityCheck?.checkedAt || '').getTime())
                .map((order) => (
                <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-medium">OS #{order.id}</span>
                      <Badge variant="outline">{order.employee}</Badge>
                      <Badge>{order.piece}</Badge>
                      {order.status === 'quality_approved' && (
                        <Badge className="bg-green-100 text-green-800">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Aprovado
                        </Badge>
                      )}
                      {order.status === 'quality_rejected' && (
                        <Badge variant="destructive">
                          <XCircle className="h-3 w-3 mr-1" />
                          Rejeitado
                        </Badge>
                      )}
                      {order.status === 'rework' && (
                        <Badge variant="secondary">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          Retrabalho
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Inspetor: {order.qualityCheck?.inspector}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Inspecionado em: {order.qualityCheck?.checkedAt ? new Date(order.qualityCheck.checkedAt).toLocaleString('pt-BR') : ''}
                    </p>
                    {order.qualityCheck?.defects && order.qualityCheck.defects.length > 0 && (
                      <p className="text-xs text-red-600 mt-1">
                        {order.qualityCheck.defects.length} defeito(s) identificado(s)
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}