import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 500); // Aguarda a animação de saída
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div 
      className={`fixed inset-0 z-[10000] bg-gradient-to-br from-primary/95 via-primary/90 to-primary/85 backdrop-blur-md flex flex-col items-center justify-center transition-all duration-500 ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
      }`}
    >
      {/* Enhanced background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-transparent" />
      
      {/* Logo Principal com efeitos melhorados */}
      <div className="mb-12 relative">
        <div className="absolute -inset-8 bg-white/10 rounded-full blur-3xl animate-pulse" />
        <div className="relative animate-scale-in">
          <img 
            src="/lovable-uploads/ee070c46-8346-42bb-8219-3f6f79c9bd07.png" 
            alt="DClamps Equipamentos" 
            className="w-80 h-auto max-w-[90vw] drop-shadow-2xl filter brightness-110"
          />
        </div>
      </div>

      {/* Título do Sistema melhorado */}
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-3 drop-shadow-2xl tracking-wide animate-fade-in">
          Sistema de Gestão Industrial
        </h1>
        <p className="text-xl md:text-2xl text-white/95 font-medium drop-shadow-lg">
          Controle e Gerenciamento Inteligente
        </p>
        <div className="flex items-center justify-center space-x-3 mt-4">
          <div className="w-2 h-2 rounded-full bg-white/70 animate-pulse" />
          <span className="text-white/80 text-sm font-medium tracking-wider">TECNOLOGIA AVANÇADA</span>
          <div className="w-2 h-2 rounded-full bg-white/70 animate-pulse" />
        </div>
      </div>

      {/* Loading Indicator melhorado */}
      <div className="flex flex-col items-center gap-4 text-white/90 mb-8">
        <div className="relative">
          <Loader2 className="w-8 h-8 animate-spin" />
          <div className="absolute inset-0 w-8 h-8 border-2 border-transparent border-t-white/50 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
        </div>
        <span className="text-lg font-medium tracking-wide animate-pulse">Inicializando sistema...</span>
      </div>

      {/* Versão simplificada */}
      <div className="absolute bottom-8 text-center">
        <p className="text-white/70 text-sm">
          Dclamps Equipamentos
        </p>
      </div>

      {/* Efeito de partículas melhorado */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-gradient-to-br from-white/30 to-transparent rounded-full animate-ping" style={{ animationDelay: '0s' }} />
        <div className="absolute top-3/4 right-1/4 w-2 h-2 bg-gradient-to-br from-white/40 to-transparent rounded-full animate-ping" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 right-1/3 w-4 h-4 bg-gradient-to-br from-white/25 to-transparent rounded-full animate-ping" style={{ animationDelay: '2s' }} />
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-gradient-to-br from-white/35 to-transparent rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
        <div className="absolute top-10 right-10 w-1 h-1 bg-white/50 rounded-full animate-ping" style={{ animationDelay: '1.5s' }} />
        <div className="absolute bottom-20 left-16 w-3 h-3 bg-gradient-to-br from-white/20 to-transparent rounded-full animate-ping" style={{ animationDelay: '2.5s' }} />
      </div>
    </div>
  );
};