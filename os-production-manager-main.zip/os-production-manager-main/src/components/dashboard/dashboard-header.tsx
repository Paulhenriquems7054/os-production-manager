import { Button } from '@/components/ui/button';
import { Logo } from '@/components/ui/logo';
import { ThemeToggle } from '@/components/theme/theme-toggle';
import { LogOut, User } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface DashboardHeaderProps {
  userType: 'admin' | 'supervisor' | 'user';
  username: string;
  onLogout: () => void;
}

export const DashboardHeader = ({ userType, username, onLogout }: DashboardHeaderProps) => {
  const isMobile = useIsMobile();

  return (
    <header className="professional-nav border-b border-border/40 p-3 md:p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 md:gap-4">
          <Logo size="sm" className="animate-scale-in" />
          <div className="hidden sm:block">
            <h1 className="text-lg md:text-xl font-bold gradient-text">Gestão de Funcionários</h1>
            <p className="text-xs md:text-sm text-muted-foreground">
              Sistema de Ordens de Serviço
            </p>
          </div>
          {isMobile && (
            <div className="animate-fade-in">
              <h1 className="text-sm font-bold gradient-text">GP</h1>
              <p className="text-xs text-muted-foreground">Sistema OS</p>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-2 md:gap-3">
          {!isMobile && (
            <div className="text-right">
              <p className="text-sm font-medium flex items-center gap-1">
                <User className="w-4 h-4 icon-soft" />
                {username}
              </p>
              <p className="text-xs text-muted-foreground capitalize">
                {userType === 'admin' ? 'Administrador' : userType === 'supervisor' ? 'Supervisor' : 'Usuário'}
              </p>
            </div>
          )}
          <ThemeToggle />
          <Button variant="outline" size={isMobile ? "sm" : "sm"} onClick={onLogout} className={isMobile ? "h-9 w-9 p-0" : "h-10"}>
            <LogOut className="w-4 h-4 icon-soft" />
            {!isMobile && <span className="ml-1">Sair</span>}
          </Button>
        </div>
      </div>
      
      {isMobile && (
        <div className="mt-2 text-center">
          <p className="text-sm font-medium text-foreground">{username}</p>
          <p className="text-xs text-muted-foreground capitalize">
            {userType === 'admin' ? 'Administrador' : userType === 'supervisor' ? 'Supervisor' : 'Usuário'}
          </p>
        </div>
      )}
    </header>
  );
};