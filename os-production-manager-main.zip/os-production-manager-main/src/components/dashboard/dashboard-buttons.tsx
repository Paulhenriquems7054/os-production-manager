import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Edit, BarChart3 } from 'lucide-react';

interface DashboardButtonsProps {
  userType: 'admin' | 'supervisor' | 'user';
  onNewOrder: () => void;
  onEditOrder: () => void;
  onAnalytics?: () => void;
}

export const DashboardButtons = ({ userType, onNewOrder, onEditOrder, onAnalytics }: DashboardButtonsProps) => {
  return (
    <div className="flex justify-center">
      <Button 
        onClick={onNewOrder}
        className="flex items-center gap-2"
        size="lg"
      >
        <Plus className="w-5 h-5" />
        Nova Ordem de Serviço
      </Button>
    </div>
  );
};