import { FC } from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24'
  };

  const textSize = {
    sm: 'text-[6px]',
    md: 'text-[8px]',
    lg: 'text-[10px]'
  };

  return (
    <div className={`${sizeClasses[size]} ${className} relative flex items-center justify-center bg-gradient-to-br from-primary to-primary-hover rounded-xl shadow-lg hover:shadow-xl hover:shadow-primary/25 transition-all duration-300 hover:scale-105`}>
      <div className={`text-primary-foreground font-extrabold ${textSize[size]} tracking-tight leading-none text-center`}>
        {size === 'sm' ? 'GP' : size === 'md' ? 'GP' : 'GESTÃO'}
      </div>
      <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse-glow"></div>
    </div>
  );
};