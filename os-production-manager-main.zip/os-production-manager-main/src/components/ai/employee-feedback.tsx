import * as React from 'react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EmployeeFeedback {
  id: string;
  name: string;
  department: string;
  performance: 'excellent' | 'good' | 'average' | 'needs-improvement';
  productivity: number;
  quality: number;
  punctuality: number;
  feedback: string;
  recommendations: string[];
  generatedAt: Date;
}

export function EmployeeFeedback() {
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');
  const [feedback, setFeedback] = useState<EmployeeFeedback | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Mock employees data (em produção viria do banco de dados)
  const employees = [
    { id: '1', name: 'João Silva', department: 'Produção' },
    { id: '2', name: 'Maria Santos', department: 'Qualidade' },
    { id: '3', name: 'Pedro Costa', department: 'Manutenção' },
    { id: '4', name: 'Ana Oliveira', department: 'Supervisão' },
  ];

  const generateFeedback = async (employeeId: string) => {
    setLoading(true);
    const employee = employees.find(e => e.id === employeeId);
    
    if (!employee) return;

    // Simular análise de IA baseada em dados do banco
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Mock feedback gerado pela IA
    const mockFeedback: EmployeeFeedback = {
      id: employeeId,
      name: employee.name,
      department: employee.department,
      performance: Math.random() > 0.3 ? 'good' : 'excellent',
      productivity: Math.floor(Math.random() * 30) + 70,
      quality: Math.floor(Math.random() * 25) + 75,
      punctuality: Math.floor(Math.random() * 20) + 80,
      feedback: generateAIFeedback(employee.name, employee.department),
      recommendations: generateRecommendations(employee.department),
      generatedAt: new Date()
    };

    setFeedback(mockFeedback);
    setLoading(false);
    
    toast({
      title: "Feedback Gerado",
      description: `Análise completa para ${employee.name} foi gerada com sucesso.`,
    });
  };

  const generateAIFeedback = (name: string, department: string) => {
    const feedbacks = {
      'Produção': `${name} demonstra excelente capacidade técnica na linha de produção. Suas métricas de produtividade estão acima da média, e a qualidade do trabalho é consistente. Recomenda-se manter o foco na otimização de processos.`,
      'Qualidade': `${name} mostra dedicação excepcional no controle de qualidade. Sua atenção aos detalhes e capacidade de identificar não conformidades contribuem significativamente para a melhoria contínua dos produtos.`,
      'Manutenção': `${name} apresenta sólidos conhecimentos técnicos e boa capacidade de resolução de problemas. Sua proatividade na manutenção preventiva tem contribuído para reduzir paradas não programadas.`,
      'Supervisão': `${name} demonstra excelentes habilidades de liderança e gestão de equipe. Sua capacidade de coordenação e tomada de decisões tem impacto positivo na produtividade geral do setor.`
    };
    
    return feedbacks[department as keyof typeof feedbacks] || 'Funcionário demonstra bom desempenho geral nas atividades designadas.';
  };

  const generateRecommendations = (department: string) => {
    const recommendations = {
      'Produção': [
        'Participar de treinamento em lean manufacturing',
        'Desenvolver habilidades em automação industrial',
        'Considerar certificação em gestão da qualidade'
      ],
      'Qualidade': [
        'Aprofundar conhecimentos em estatística aplicada',
        'Treinamento em novas tecnologias de inspeção',
        'Certificação em auditoria de qualidade'
      ],
      'Manutenção': [
        'Especialização em manutenção preditiva',
        'Curso de análise de vibração',
        'Treinamento em termografia industrial'
      ],
      'Supervisão': [
        'Curso de liderança avançada',
        'Treinamento em gestão de pessoas',
        'MBA em gestão industrial'
      ]
    };
    
    return recommendations[department as keyof typeof recommendations] || ['Desenvolvimento de habilidades técnicas', 'Participação em programas de capacitação'];
  };

  const getPerformanceBadge = (performance: string) => {
    const variants = {
      excellent: 'default',
      good: 'secondary',
      average: 'outline',
      'needs-improvement': 'destructive'
    };
    
    return (
      <Badge variant={variants[performance as keyof typeof variants] as any}>
        {performance === 'excellent' && <CheckCircle className="w-3 h-3 mr-1" />}
        {performance === 'good' && <TrendingUp className="w-3 h-3 mr-1" />}
        {performance === 'needs-improvement' && <AlertTriangle className="w-3 h-3 mr-1" />}
        {performance.charAt(0).toUpperCase() + performance.slice(1).replace('-', ' ')}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Seção de destaque do diferencial */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Brain className="w-5 h-5" />
            🏆 Nosso Diferencial: Feedback Inteligente
          </CardTitle>
          <CardDescription className="text-base leading-relaxed">
            <strong>Revolucione a gestão de pessoas!</strong> Nosso sistema usa IA avançada para analisar 
            automaticamente os dados de produção, qualidade e pontualidade, gerando <strong>feedbacks detalhados 
            e personalizados</strong> para cada funcionário. Diferente de sistemas convencionais que apenas 
            coletam dados, nossa plataforma <strong>interpreta e converte informações em insights acionáveis</strong>, 
            oferecendo recomendações específicas para desenvolvimento profissional e melhoria de performance.
          </CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Sistema de Feedback Inteligente
          </CardTitle>
          <CardDescription>
            IA que analisa dados de produção e gera feedback personalizado com base no desempenho real
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-[300px]">
                <SelectValue placeholder="Selecione um funcionário" />
              </SelectTrigger>
              <SelectContent>
                {employees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.name} - {employee.department}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button 
              onClick={() => generateFeedback(selectedEmployee)}
              disabled={!selectedEmployee || loading}
              className="flex items-center gap-2"
            >
              <Brain className="w-4 h-4" />
              {loading ? 'Analisando...' : 'Gerar Feedback'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {feedback && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Análise para {feedback.name}
              {getPerformanceBadge(feedback.performance)}
            </CardTitle>
            <CardDescription>
              Departamento: {feedback.department} • Gerado em {feedback.generatedAt.toLocaleString()}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{feedback.productivity}%</div>
                <div className="text-sm text-muted-foreground">Produtividade</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{feedback.quality}%</div>
                <div className="text-sm text-muted-foreground">Qualidade</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{feedback.punctuality}%</div>
                <div className="text-sm text-muted-foreground">Pontualidade</div>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Feedback da IA:</h4>
              <p className="text-muted-foreground leading-relaxed">{feedback.feedback}</p>
            </div>

            <div>
              <h4 className="font-medium mb-2">Recomendações de Desenvolvimento:</h4>
              <ul className="space-y-1">
                {feedback.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-3 h-3 text-primary" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}