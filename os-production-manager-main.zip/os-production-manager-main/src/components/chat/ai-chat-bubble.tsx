import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Settings, Trash2, Paperclip, FileText, Image, Download, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAiChat } from '@/hooks/use-ai-chat';
import { useGoogleSheetsSync } from '@/hooks/use-google-sheets-sync';

import { cn } from '@/lib/utils';

interface AttachedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  content?: string;
}

interface AiChatBubbleProps {
  context?: string;
  className?: string;
}

export const AiChatBubble: React.FC<AiChatBubbleProps> = ({ context, className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [tempGroqApiKey, setTempGroqApiKey] = useState('');
  const [tempGeminiApiKey, setTempGeminiApiKey] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isMobile, setIsMobile] = useState(false);
  
  // Hook para sincronização com Google Sheets
  const { isLoading: syncLoading, lastSync, recordsProcessed, syncNow } = useGoogleSheetsSync();

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  const { 
    messages, 
    isLoading, 
    sendMessage, 
    clearChat, 
    groqApiKey, 
    geminiApiKey, 
    setGroqApiKey, 
    setGeminiApiKey,
    currentProvider,
    setCurrentProvider
  } = useAiChat();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;
    
    // Preparar contexto com arquivos anexados
    let fullContext = context || '';
    
    if (attachedFiles.length > 0) {
      const filesContext = attachedFiles.map(file => {
        let fileInfo = `Arquivo: ${file.name} (${formatFileSize(file.size)})`;
        if (file.content) {
          fileInfo += `\nConteúdo: ${file.content}`;
        } else if (file.type.startsWith('image/')) {
          fileInfo += '\nTipo: Imagem (conteúdo visual não processado)';
        } else {
          fileInfo += '\nTipo: Documento';
        }
        return fileInfo;
      }).join('\n\n');
      
      fullContext += `\n\nArquivos anexados:\n${filesContext}`;
    }
    
    await sendMessage(inputMessage, fullContext);
    setInputMessage('');
    setAttachedFiles([]); // Limpar arquivos após envio
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSaveApiKeys = () => {
    if (tempGroqApiKey.trim()) {
      setGroqApiKey(tempGroqApiKey.trim());
      setTempGroqApiKey('');
    }
    if (tempGeminiApiKey.trim()) {
      setGeminiApiKey(tempGeminiApiKey.trim());
      setTempGeminiApiKey('');
    }
    setShowSettings(false);
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileId = Date.now().toString() + i;
      
      // Verificar tamanho do arquivo (máximo 10MB)
      if (file.size > 10 * 1024 * 1024) {
        console.error('Arquivo muito grande:', file.name);
        continue;
      }

      const url = URL.createObjectURL(file);
      let content = '';

      // Se for arquivo de texto, ler o conteúdo
      if (file.type.startsWith('text/') || file.name.toLowerCase().endsWith('.txt')) {
        try {
          content = await file.text();
        } catch (error) {
          console.error('Erro ao ler arquivo de texto:', error);
        }
      }

      const attachedFile: AttachedFile = {
        id: fileId,
        name: file.name,
        type: file.type,
        size: file.size,
        url,
        content
      };

      setAttachedFiles(prev => [...prev, attachedFile]);
    }

    // Limpar o input
    event.target.value = '';
  };

  const removeAttachedFile = (fileId: string) => {
    setAttachedFiles(prev => {
      const fileToRemove = prev.find(f => f.id === fileId);
      if (fileToRemove) {
        URL.revokeObjectURL(fileToRemove.url);
      }
      return prev.filter(f => f.id !== fileId);
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const currentApiKey = currentProvider === 'groq' ? groqApiKey : geminiApiKey;

  if (isMobile) {
    return (
      <>
        {!isOpen ? (
          <Button
            onClick={() => setIsOpen(true)}
            className="fixed bottom-4 right-4 h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90 z-[9999]"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        ) : (
          <div className="fixed inset-0 z-[9999] bg-background">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b">
                <div className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  <span className="font-semibold">
                    Chat com IA
                    {lastSync && (
                      <div className="text-xs text-muted-foreground font-normal">
                        Sincronizado: {lastSync.toLocaleTimeString('pt-BR')}
                      </div>
                    )}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={syncNow}
                    disabled={syncLoading}
                    title="Sincronizar com Google Sheets"
                  >
                    <RefreshCw className={`h-4 w-4 ${syncLoading ? 'animate-spin' : ''}`} />
                  </Button>
                  <Dialog open={showSettings} onOpenChange={setShowSettings}>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Configurações do Chat</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Provedor de IA</Label>
                          <Select value={currentProvider} onValueChange={setCurrentProvider}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="groq">Groq (Llama)</SelectItem>
                              <SelectItem value="gemini">Google Gemini</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Chave da API Groq</Label>
                          <Input
                            type="password"
                            placeholder="Digite sua chave da API Groq..."
                            value={tempGroqApiKey}
                            onChange={(e) => setTempGroqApiKey(e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Chave da API Gemini</Label>
                          <Input
                            type="password"
                            placeholder="Digite sua chave da API Gemini..."
                            value={tempGeminiApiKey}
                            onChange={(e) => setTempGeminiApiKey(e.target.value)}
                          />
                        </div>
                        <Button onClick={handleSaveApiKeys} className="w-full">
                          Salvar
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                  {messages.length > 0 && (
                    <Button variant="ghost" size="sm" onClick={clearChat}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
                <ScrollArea className="flex-1 p-4">
                {messages.length === 0 ? (
                  <div className="text-center text-muted-foreground mt-8 space-y-2">
                    {!currentApiKey ? (
                      <p>Configure sua chave da API para começar</p>
                    ) : (
                      <>
                        <p className="font-medium">🚀 Chat Inteligente com Acesso aos Dados</p>
                        <p className="text-sm">Pergunte sobre ordens de serviço, produção, qualidade, materiais ou funcionários</p>
                        <p className="text-xs">💡 Nosso diferencial: Respostas baseadas nos dados reais do seu sistema!</p>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={cn(
                          "flex",
                          message.role === 'user' ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-[80%] p-3 rounded-lg text-sm",
                            message.role === 'user'
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          )}
                        >
                          {message.content}
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-muted p-3 rounded-lg">
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>
              
              {attachedFiles.length > 0 && (
                <div className="border-t p-4">
                  <div className="text-sm text-muted-foreground mb-2">Arquivos:</div>
                  <div className="space-y-2">
                    {attachedFiles.map((file) => (
                      <div key={file.id} className="flex items-center gap-2 p-2 bg-muted rounded">
                        {file.type.startsWith('image/') ? (
                          <Image className="h-4 w-4" />
                        ) : (
                          <FileText className="h-4 w-4" />
                        )}
                        <span className="flex-1 truncate">{file.name}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeAttachedFile(file.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex gap-2 p-4 border-t">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={!currentApiKey || isLoading}
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Digite sua pergunta..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={!currentApiKey || isLoading}
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || !currentApiKey || isLoading}
                  size="sm"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx,.txt,.csv,.json"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-[9999]">
      {!isOpen ? (
        <Button
          onClick={() => setIsOpen(true)}
          size="lg"
          className="rounded-full h-14 w-14 shadow-lg hover:shadow-xl transition-all duration-300 bg-primary hover:bg-primary/90"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      ) : (
        <Card className="w-80 h-96 shadow-xl border-primary/20">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm flex items-center gap-2">
                <MessageCircle className="h-4 w-4" />
                <div>
                  Chat com IA
                  {lastSync && (
                    <div className="text-xs text-muted-foreground font-normal">
                      Sincronizado: {lastSync.toLocaleTimeString('pt-BR')}
                      {recordsProcessed > 0 && ` (${recordsProcessed} registros)`}
                    </div>
                  )}
                </div>
              </CardTitle>
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={syncNow}
                  disabled={syncLoading}
                  title="Sincronizar com Google Sheets"
                >
                  <RefreshCw className={`h-4 w-4 ${syncLoading ? 'animate-spin' : ''}`} />
                </Button>
                <Dialog open={showSettings} onOpenChange={setShowSettings}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Configurações do Chat</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="provider">Provedor de IA</Label>
                        <Select value={currentProvider} onValueChange={setCurrentProvider}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o provedor" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="groq">Groq (Llama)</SelectItem>
                            <SelectItem value="gemini">Google Gemini</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="groq-api-key">Chave da API Groq</Label>
                        <Input
                          id="groq-api-key"
                          type="password"
                          placeholder="Digite sua chave da API Groq..."
                          value={tempGroqApiKey}
                          onChange={(e) => setTempGroqApiKey(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Obtenha sua chave em{' '}
                          <a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer" className="underline">
                            console.groq.com
                          </a>
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="gemini-api-key">Chave da API Gemini</Label>
                        <Input
                          id="gemini-api-key"
                          type="password"
                          placeholder="Digite sua chave da API Gemini..."
                          value={tempGeminiApiKey}
                          onChange={(e) => setTempGeminiApiKey(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Obtenha sua chave em{' '}
                          <a href="https://makersuite.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="underline">
                            Google AI Studio
                          </a>
                        </p>
                      </div>
                      
                      <Button onClick={handleSaveApiKeys} className="w-full">
                        Salvar Configurações
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                
                {messages.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={clearChat}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
                
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-3">
            <div className={cn(
              "flex flex-col",
              isMobile ? "h-[calc(100vh-12rem)]" : "h-72"
            )}>
              <ScrollArea className="flex-1 pr-1 md:pr-2">
                {messages.length === 0 ? (
                  <div className="text-center text-muted-foreground text-xs md:text-sm mt-4 md:mt-8 px-2 space-y-1">
                    {!currentApiKey ? (
                      <p>Configure sua chave da API para começar</p>
                    ) : (
                      <>
                        <p className="font-medium">🤖 IA com acesso aos dados</p>
                        <p className="text-xs">Pergunte sobre seus dados reais!</p>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2 md:space-y-3">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={cn(
                          "flex",
                          message.role === 'user' ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-[85%] md:max-w-[80%] p-2 rounded-lg text-xs md:text-sm break-words",
                            message.role === 'user'
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          )}
                        >
                          {message.content}
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-muted p-2 rounded-lg text-xs md:text-sm">
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>
              
              {/* Seção de arquivos anexados */}
              {attachedFiles.length > 0 && (
                <div className="border-t pt-2 mt-2">
                  <div className="text-xs text-muted-foreground mb-1 px-1">Arquivos:</div>
                  <div className="space-y-1 max-h-20 overflow-y-auto">
                    {attachedFiles.map((file) => (
                      <div key={file.id} className="flex items-center gap-1 md:gap-2 p-1 md:p-2 bg-muted/50 rounded text-xs">
                        {file.type.startsWith('image/') ? (
                          <Image className="h-3 w-3 text-primary flex-shrink-0" />
                        ) : (
                          <FileText className="h-3 w-3 text-primary flex-shrink-0" />
                        )}
                        <span className="flex-1 truncate min-w-0">{file.name}</span>
                        <span className="text-muted-foreground text-xs hidden md:inline">{formatFileSize(file.size)}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-5 w-5 p-0 flex-shrink-0"
                          onClick={() => removeAttachedFile(file.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex gap-1 md:gap-2 mt-2 md:mt-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="px-2 flex-shrink-0"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={!currentApiKey || isLoading}
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Ex: Quantas ordens pendentes temos?"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={!currentApiKey || isLoading}
                  className="flex-1 min-w-0 text-sm"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || !currentApiKey || isLoading}
                  size="sm"
                  className="px-2 md:px-3 flex-shrink-0"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Input de arquivo oculto */}
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,.pdf,.doc,.docx,.txt,.csv,.json"
              onChange={handleFileSelect}
              className="hidden"
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
};