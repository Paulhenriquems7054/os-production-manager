import * as React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, BarChart3, Settings, FileSpreadsheet, ClipboardCheck } from 'lucide-react';
import { useProfile } from '@/hooks/use-profile';

export function FloatingNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { userType } = useProfile();

  const navItems = [
    { icon: Home, path: '/', label: 'Início' },
    ...(userType === 'admin' ? [
      { icon: BarChart3, path: '/analytics', label: 'Analytics' },
      { icon: FileSpreadsheet, path: '/production', label: 'Produção' },
      { icon: Settings, path: '/settings', label: 'Configurações' }
    ] : [])
  ];

  if (navItems.length <= 1) return null;

  return (
    <div className="floating-buttons">
      {navItems.map(({ icon: Icon, path, label }) => (
        <Button
          key={path}
          variant={location.pathname === path ? "default" : "ghost"}
          size="sm"
          onClick={() => navigate(path)}
          className={`
            w-14 h-14 rounded-2xl p-0 transition-all duration-300 ease-out group relative overflow-hidden
            ${location.pathname === path 
              ? 'bg-gradient-to-br from-primary to-primary-hover text-primary-foreground shadow-xl shadow-primary/30 scale-110' 
              : 'hover:bg-gradient-to-br hover:from-accent/20 hover:to-accent/10 hover:text-accent-foreground hover:scale-105 hover:shadow-lg'
            }
          `}
          title={label}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <Icon className={`w-6 h-6 relative z-10 transition-all duration-300 ${
            location.pathname === path ? 'animate-pulse-glow' : 'group-hover:scale-110'
          }`} />
        </Button>
      ))}
    </div>
  );
}