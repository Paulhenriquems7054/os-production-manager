export interface QualityCheck {
  id: string;
  orderId: string;
  inspector: string;
  checklistItems: QualityChecklistItem[];
  defects: QualityDefect[];
  result: 'approved' | 'rejected' | 'rework_required';
  notes?: string;
  checkedAt: string;
}

export interface QualityChecklistItem {
  id: string;
  description: string;
  checked: boolean;
  required: boolean;
}

export interface QualityDefect {
  id: string;
  type: 'dimensional' | 'surface' | 'material' | 'assembly' | 'other';
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  location?: string;
}

export interface ServiceOrder {
  id: string;
  user_id: string;
  order_number: string;
  employee: string;
  quantity: number;
  categoryId: string;
  categoryName: string;
  piece: string;
  serviceId: string;
  serviceName: string;
  startTime: string;
  endTime: string;
  observations?: string;
  createdAt: string;
  updated_at: string;
  status: 'active' | 'completed' | 'in-progress' | 'rejected' | 'awaiting_quality' | 'quality_approved' | 'quality_rejected' | 'rework';
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  qualityCheck?: QualityCheck;
  reworkCount?: number;
  reworkHistory?: { reason: string; date: string; inspector: string }[];
}

export interface ServiceOrderFormData {
  client_name: string;
  client_phone?: string;
  client_email?: string;
  service_type: string;
  description?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimated_hours?: number;
  total_cost?: number;
  scheduled_date?: string;
  notes?: string;
}