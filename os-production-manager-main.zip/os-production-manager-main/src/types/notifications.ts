export interface Notification {
  id: string;
  type: 'quality' | 'productivity' | 'approval' | 'system' | 'material';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  read: boolean;
  createdAt: string;
  orderId?: string;
  employeeId?: string;
  actionRequired?: boolean;
  metadata?: Record<string, any>;
}

export interface NotificationSettings {
  enablePush: boolean;
  enableEmail: boolean;
  enableSound: boolean;
  qualityAlerts: boolean;
  productivityAlerts: boolean;
  approvalAlerts: boolean;
  materialAlerts: boolean;
  webhookUrl?: string;
  emailRecipients: string[];
}