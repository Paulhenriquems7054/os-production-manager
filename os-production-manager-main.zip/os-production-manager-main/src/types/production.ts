
export interface GoogleSheetsProductionRecord {
  "Carimbo de data/hora": string;
  "Execultante:": string;
  "Função:": string;
  "Supervisor:": string;
  "Peças 1 - [Suspensor TC1A]": string;
  "Peças 1 - [Suspensor T16]": string;
  "Peças 1 - [Anel para suspensor]": string;
  "Peças 1 - [Luva]": string;
  "Peças 1 - [Niple Longo]": string;
  "Peças 2 - [Difusor]": string;
  "Peças 2 - [Packer]": string;
  "Peças 2 - [Válvula Dreno]": string;
  "Peças 2 - [Válvula Check]": string;
  "Peças 2 - [Desareador]": string;
  "Tubo Filtro [Tubo Filtro]": string;
  "Peças 3 -  [Acoplamentos]": string;
  "Peças 3 -  [Cabeça de descarga]": string;
  "Peças 3 -  [Outro serviço]": string;
  "O COLABORADOR FARÁ OUTRO SERVIÇO:": "SIM" | "NÃO";
  "Coluna 17": string;
}

export interface ProductionRecord {
  id: string;
  user_id: string;
  timestamp: string;
  executante: string;
  funcao: string;
  supervisor: string;
  suspensorTC1A: string;
  suspensorT16: string;
  anelSuspensor: string;
  luva: string;
  nipleLongo: string;
  difusor: string;
  packer: string;
  valvulaDreno: string;
  valvulaCheck: string;
  desareador: string;
  tuboFiltro: string;
  acoplamentos: string;
  cabecaDescarga: string;
  outroServico: string;
  colaboradorOutroServico: 'SIM' | 'NÃO';
  observacoes: string;
  created_at: string;
  updated_at: string;
}

export interface ProductionFormData {
  executante: string;
  funcao: string;
  supervisor: string;
  suspensorTC1A?: string;
  suspensorT16?: string;
  anelSuspensor?: string;
  luva?: string;
  nipleLongo?: string;
  difusor?: string;
  packer?: string;
  valvulaDreno?: string;
  valvulaCheck?: string;
  desareador?: string;
  tuboFiltro?: string;
  acoplamentos?: string;
  cabecaDescarga?: string;
  outroServico?: string;
  colaboradorOutroServico: 'SIM' | 'NÃO';
  observacoes?: string;
}

export interface ProductionStats {
  totalRecords: number;
  uniqueEmployees: number;
  servicesExecuted: number;
  topFunction: string;
  topEmployee: string;
  dailyProduction: Array<{
    date: string;
    count: number;
    employees: string[];
  }>;
  functionDistribution: Array<{
    funcao: string;
    count: number;
    percentage: number;
  }>;
  employeePerformance: Array<{
    executante: string;
    totalServices: number;
    functions: string[];
    lastActivity: string;
  }>;
}
