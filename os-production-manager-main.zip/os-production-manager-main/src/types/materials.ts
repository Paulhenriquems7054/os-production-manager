export interface Material {
  id: string;
  name: string;
  description?: string;
  unit: 'kg' | 'g' | 'l' | 'ml' | 'pcs' | 'm' | 'cm';
  currentStock: number;
  minStock: number;
  maxStock: number;
  unitCost: number;
  supplier?: string;
  location?: string;
  category: 'metal' | 'chemical' | 'tool' | 'consumable' | 'safety' | 'other';
}

export interface Tool {
  id: string;
  name: string;
  description?: string;
  serialNumber?: string;
  status: 'available' | 'in_use' | 'maintenance' | 'broken';
  category: 'cutting' | 'measuring' | 'safety' | 'pneumatic' | 'electric' | 'manual';
  condition: 'new' | 'good' | 'fair' | 'poor';
  maintenanceSchedule?: string;
  lastMaintenance?: string;
  nextMaintenance?: string;
  currentUser?: string;
  checkoutTime?: string;
  location?: string;
}

export interface MaterialConsumption {
  id: string;
  materialId: string;
  materialName: string;
  orderId: string;
  employeeId: string;
  quantity: number;
  unit: string;
  consumedAt: string;
  cost: number;
  notes?: string;
}

export interface ToolCheckout {
  id: string;
  toolId: string;
  toolName: string;
  employeeId: string;
  orderId?: string;
  checkedOutAt: string;
  checkedInAt?: string;
  condition: 'same' | 'worse' | 'damaged';
  notes?: string;
  damages?: string[];
}

export interface StockAlert {
  id: string;
  materialId: string;
  materialName: string;
  currentStock: number;
  minStock: number;
  severity: 'low' | 'critical' | 'out_of_stock';
  createdAt: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
}