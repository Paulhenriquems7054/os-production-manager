import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/App';
import { useToast } from '@/hooks/use-toast';

import { ServiceOrder } from '@/types/order';

import { ServiceOrderFormData } from '@/types/order';

export const useServiceOrders = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('service_orders')
        .select('*')
        .order('createdAt', { ascending: false });

      if (error) {
        setError(error.message);
        toast({
          title: "Erro ao carregar ordens",
          description: error.message,
          variant: "destructive",
        });
      } else {
        // Transform database column names to component expected names
        const transformedData: ServiceOrder[] = (data || []).map(record => ({
          id: record.id,
          user_id: record.user_id,
          order_number: record.order_number,
          employee: record.employee || '',
          quantity: Number(record.quantity) || 1,
          categoryId: record.category_id || '',
          categoryName: record.category_name || '',
          piece: record.piece || '',
          serviceId: record.service_id || '',
          serviceName: record.service_name || '',
          startTime: record.start_time || '',
          endTime: record.end_time || '',
          observations: record.observations || '',
          createdAt: record.createdAt,
          
          updated_at: record.updated_at,
          status: record.status as ServiceOrder['status'],
          approvedBy: record.approved_by,
          approvedAt: record.approved_at,
          rejectedBy: record.rejected_by,
          rejectedAt: record.rejected_at,
          reworkCount: record.rework_count,
          reworkHistory: Array.isArray(record.rework_history) ? record.rework_history as ServiceOrder['reworkHistory'] : [],
        }));
        setOrders(transformedData);
      }
    } catch (err) {
      const errorMessage = 'Erro ao carregar ordens de serviço';
      setError(errorMessage);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [user]);

  const addOrder = async (formData: ServiceOrderFormData): Promise<ServiceOrder> => {
    try {
      console.log('🚀 Iniciando criação de ordem...');
      console.log('👤 User from context:', user);
      
      if (!user?.id) {
        console.error('❌ Usuário não encontrado no contexto');
        throw new Error('Usuário não autenticado. Faça login para criar uma ordem de serviço.');
      }
      
      
      // Verificar se o usuário está autenticado no Supabase
      console.log('🔍 Verificando sessão Supabase...');
      const { data: { session } } = await supabase.auth.getSession();
      console.log('📝 Sessão Supabase:', session);
      
      // Se não há sessão do Supabase, usar um UUID genérico para o sistema local
      let actualUserId: string;
      if (session?.user?.id) {
        actualUserId = session.user.id;
        console.log('🔑 Usando ID do usuário Supabase:', actualUserId);
      } else {
        // Para o sistema local, criar um UUID fixo baseado no nome do usuário
        actualUserId = 'local-' + btoa(user.name).replace(/[^a-zA-Z0-9]/g, '').substring(0, 20);
        console.log('🔑 Usando ID local para usuário:', actualUserId);
      }

      // Generate order number
      const orderNumber = `OS-${Date.now()}`;
      console.log('📋 Gerando ordem número:', orderNumber);

      const newOrder = {
        user_id: actualUserId,
        order_number: orderNumber,
        client_name: formData.client_name,
        client_phone: formData.client_phone,
        client_email: formData.client_email,
        service_type: formData.service_type,
        description: formData.description,
        priority: formData.priority,
        estimated_hours: formData.estimated_hours,
        total_cost: formData.total_cost,
        scheduled_date: formData.scheduled_date,
        notes: formData.notes,
        employee: '',
        category_id: '',
        category_name: '',
        piece: '',
        service_id: '',
        service_name: '',
        start_time: '',
        end_time: '',
        quantity: 1,
      };
      
      console.log('📤 Dados da ordem a ser inserida:', newOrder);

      const { data, error } = await supabase
        .from('service_orders')
        .insert([newOrder])
        .select()
        .single();

      if (error) {
        toast({
          title: "Erro ao criar ordem",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      const transformedOrder: ServiceOrder = {
        id: data.id,
        user_id: data.user_id,
        order_number: data.order_number,
        employee: data.employee || '',
        piece: data.piece || '',
        serviceName: data.service_name || '',
        serviceId: data.service_id || '',
        quantity: Number(data.quantity) || 1,
        startTime: data.start_time || '',
        endTime: data.end_time || '',
        observations: data.observations || '',
        status: data.status as ServiceOrder['status'],
        categoryId: data.category_id || '',
        categoryName: data.category_name || '',
        approvedBy: data.approved_by,
        approvedAt: data.approved_at,
        createdAt: data.createdAt,
        
        updated_at: data.updated_at,
        reworkHistory: Array.isArray(data.rework_history) ? data.rework_history as ServiceOrder['reworkHistory'] : []
      };

      setOrders(prev => [transformedOrder, ...prev]);
      toast({
        title: "Ordem criada",
        description: `Ordem ${orderNumber} criada com sucesso`,
      });

      return transformedOrder;
    } catch (error) {
      console.error('Error in addOrder:', error);
      throw error;
    }
  };

  const updateOrder = async (id: string, updates: Partial<ServiceOrder>) => {
    const { error } = await supabase
      .from('service_orders')
      .update(updates)
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao atualizar ordem",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setOrders(prev => prev.map(order => 
      order.id === id ? { ...order, ...updates } : order
    ));

    toast({
      title: "Ordem atualizada",
      description: "Ordem atualizada com sucesso",
    });
  };

  const deleteOrder = async (id: string) => {
    const { error } = await supabase
      .from('service_orders')
      .delete()
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao excluir ordem",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setOrders(prev => prev.filter(order => order.id !== id));
    toast({
      title: "Ordem excluída",
      description: "Ordem excluída com sucesso",
    });
  };

  const getOrderById = (id: string) => {
    return orders.find(order => order.id === id);
  };

  return {
    orders,
    loading,
    error,
    addOrder,
    updateOrder,
    deleteOrder,
    getOrderById,
    refetch: fetchOrders,
  };
};