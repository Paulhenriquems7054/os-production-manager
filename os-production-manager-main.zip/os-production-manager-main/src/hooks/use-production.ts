
import { useState, useEffect } from 'react';
import { ProductionRecord, ProductionFormData, ProductionStats } from '@/types/production';
import { useGoogleSheets } from './use-google-sheets';
import { format, startOfDay, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const useProduction = () => {
  const { data: googleSheetsData, loading, error, lastSync, syncData } = useGoogleSheets();
  const [records, setRecords] = useState<ProductionRecord[]>([]);

  useEffect(() => {
    if (googleSheetsData.length > 0) {
      setRecords(googleSheetsData);
    }
  }, [googleSheetsData]);

  const addRecord = (formData: ProductionFormData): ProductionRecord => {
    const newRecord: ProductionRecord = {
      id: Date.now().toString(),
      user_id: `local-${Date.now()}`,
      timestamp: new Date().toLocaleString('pt-BR'),
      ...formData,
      suspensorTC1A: formData.suspensorTC1A || '',
      suspensorT16: formData.suspensorT16 || '',
      anelSuspensor: formData.anelSuspensor || '',
      luva: formData.luva || '',
      nipleLongo: formData.nipleLongo || '',
      difusor: formData.difusor || '',
      packer: formData.packer || '',
      valvulaDreno: formData.valvulaDreno || '',
      valvulaCheck: formData.valvulaCheck || '',
      desareador: formData.desareador || '',
      tuboFiltro: formData.tuboFiltro || '',
      acoplamentos: formData.acoplamentos || '',
      cabecaDescarga: formData.cabecaDescarga || '',
      outroServico: formData.outroServico || '',
      observacoes: formData.observacoes || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Em produção, aqui você enviaria para o Google Sheets
    const updatedRecords = [newRecord, ...records];
    setRecords(updatedRecords);
    return newRecord;
  };

  const updateRecord = (id: string, updates: Partial<ProductionRecord>) => {
    const updatedRecords = records.map(record =>
      record.id === id ? { ...record, ...updates } : record
    );
    setRecords(updatedRecords);
  };

  const deleteRecord = (id: string) => {
    const filteredRecords = records.filter(record => record.id !== id);
    setRecords(filteredRecords);
  };

  const getRecordById = (id: string): ProductionRecord | undefined => {
    return records.find(record => record.id === id);
  };

  const getStats = (): ProductionStats => {
    const uniqueEmployees = [...new Set(records.map(r => r.executante))];
    const functionCounts = records.reduce((acc, record) => {
      acc[record.funcao] = (acc[record.funcao] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const employeeServiceCounts = records.reduce((acc, record) => {
      if (!acc[record.executante]) {
        acc[record.executante] = {
          executante: record.executante,
          totalServices: 0,
          functions: new Set<string>(),
          lastActivity: record.timestamp
        };
      }
      
      // Contar quantos serviços foram executados
      let serviceCount = 0;
      if (record.suspensorTC1A) serviceCount++;
      if (record.suspensorT16) serviceCount++;
      if (record.anelSuspensor) serviceCount++;
      if (record.luva) serviceCount++;
      if (record.nipleLongo) serviceCount++;
      if (record.difusor) serviceCount++;
      if (record.packer) serviceCount++;
      if (record.valvulaDreno) serviceCount++;
      if (record.valvulaCheck) serviceCount++;
      if (record.desareador) serviceCount++;
      if (record.tuboFiltro) serviceCount++;
      if (record.acoplamentos) serviceCount++;
      if (record.cabecaDescarga) serviceCount++;
      if (record.outroServico) serviceCount++;

      acc[record.executante].totalServices += Math.max(serviceCount, 1);
      acc[record.executante].functions.add(record.funcao);
      
      return acc;
    }, {} as Record<string, any>);

    const dailyProduction = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      const dayRecords = records.filter(record => {
        const recordDate = new Date(record.timestamp.split(' ')[0].split('/').reverse().join('-'));
        return startOfDay(recordDate).getTime() === startOfDay(date).getTime();
      });
      
      return {
        date: format(date, 'dd/MM', { locale: ptBR }),
        count: dayRecords.length,
        employees: [...new Set(dayRecords.map(r => r.executante))]
      };
    });

    const totalServicesExecuted = records.reduce((total, record) => {
      let serviceCount = 0;
      if (record.suspensorTC1A) serviceCount++;
      if (record.suspensorT16) serviceCount++;
      if (record.anelSuspensor) serviceCount++;
      if (record.luva) serviceCount++;
      if (record.nipleLongo) serviceCount++;
      if (record.difusor) serviceCount++;
      if (record.packer) serviceCount++;
      if (record.valvulaDreno) serviceCount++;
      if (record.valvulaCheck) serviceCount++;
      if (record.desareador) serviceCount++;
      if (record.tuboFiltro) serviceCount++;
      if (record.acoplamentos) serviceCount++;
      if (record.cabecaDescarga) serviceCount++;
      if (record.outroServico) serviceCount++;
      
      return total + Math.max(serviceCount, 1);
    }, 0);

    return {
      totalRecords: records.length,
      uniqueEmployees: uniqueEmployees.length,
      servicesExecuted: totalServicesExecuted,
      topFunction: Object.entries(functionCounts).sort(([,a], [,b]) => b - a)[0]?.[0] || '',
      topEmployee: Object.values(employeeServiceCounts).sort((a, b) => b.totalServices - a.totalServices)[0]?.executante || '',
      dailyProduction,
      functionDistribution: Object.entries(functionCounts).map(([funcao, count]) => ({
        funcao,
        count,
        percentage: Math.round((count / records.length) * 100)
      })).sort((a, b) => b.count - a.count),
      employeePerformance: Object.values(employeeServiceCounts).map(emp => ({
        ...emp,
        functions: Array.from(emp.functions)
      })).sort((a, b) => b.totalServices - a.totalServices)
    };
  };

  return {
    records,
    loading,
    error,
    lastSync,
    stats: getStats(),
    addRecord,
    updateRecord,
    deleteRecord,
    getRecordById,
    syncData,
    isConnected: !error && records.length > 0
  };
};
