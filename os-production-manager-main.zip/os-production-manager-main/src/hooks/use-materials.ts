import { useState, useEffect, useCallback } from 'react';
import { Material, Tool, MaterialConsumption, ToolCheckout, StockAlert } from '@/types/materials';
import { useNotifications } from '@/hooks/use-notifications';

const MATERIALS_STORAGE_KEY = 'materials';
const TOOLS_STORAGE_KEY = 'tools';
const CONSUMPTION_STORAGE_KEY = 'material-consumption';
const CHECKOUTS_STORAGE_KEY = 'tool-checkouts';
const ALERTS_STORAGE_KEY = 'stock-alerts';

const defaultMaterials: Material[] = [
  {
    id: '1',
    name: 'Aço Inoxidável 316L',
    description: 'Barra redonda 25mm',
    unit: 'kg',
    currentStock: 50,
    minStock: 10,
    maxStock: 100,
    unitCost: 25.50,
    supplier: 'Aços Brasil',
    location: 'Estoque A1',
    category: 'metal'
  },
  {
    id: '2',
    name: 'Óleo de Corte',
    description: 'Óleo para usinagem',
    unit: 'l',
    currentStock: 20,
    minStock: 5,
    maxStock: 50,
    unitCost: 15.00,
    supplier: 'Quimicos Ind.',
    location: 'Estoque B2',
    category: 'chemical'
  },
  {
    id: '3',
    name: 'Rosca M10x1.5',
    description: 'Macho para rosca',
    unit: 'pcs',
    currentStock: 3,
    minStock: 5,
    maxStock: 20,
    unitCost: 45.00,
    supplier: 'Ferramentas Pro',
    location: 'Caixa de Ferramentas',
    category: 'tool'
  }
];

const defaultTools: Tool[] = [
  {
    id: '1',
    name: 'Torno CNC Romi',
    description: 'Torno automático',
    serialNumber: 'RO-2024-001',
    status: 'available',
    category: 'cutting',
    condition: 'good',
    location: 'Seção 1'
  },
  {
    id: '2',
    name: 'Paquímetro Digital',
    description: '150mm precisão 0.01mm',
    serialNumber: 'PAQ-001',
    status: 'available',
    category: 'measuring',
    condition: 'good',
    location: 'Bancada QC'
  },
  {
    id: '3',
    name: 'Furadeira Pneumática',
    description: 'Furadeira de bancada',
    serialNumber: 'FUR-P-003',
    status: 'in_use',
    category: 'pneumatic',
    condition: 'good',
    currentUser: 'João Silva',
    checkoutTime: new Date().toISOString(),
    location: 'Seção 2'
  }
];

export function useMaterials() {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [consumptions, setConsumptions] = useState<MaterialConsumption[]>([]);
  const [checkouts, setCheckouts] = useState<ToolCheckout[]>([]);
  const [alerts, setAlerts] = useState<StockAlert[]>([]);
  const { showNotification } = useNotifications();

  // Load data from localStorage
  useEffect(() => {
    const savedMaterials = localStorage.getItem(MATERIALS_STORAGE_KEY);
    const savedTools = localStorage.getItem(TOOLS_STORAGE_KEY);
    const savedConsumptions = localStorage.getItem(CONSUMPTION_STORAGE_KEY);
    const savedCheckouts = localStorage.getItem(CHECKOUTS_STORAGE_KEY);
    const savedAlerts = localStorage.getItem(ALERTS_STORAGE_KEY);

    setMaterials(savedMaterials ? JSON.parse(savedMaterials) : defaultMaterials);
    setTools(savedTools ? JSON.parse(savedTools) : defaultTools);
    setConsumptions(savedConsumptions ? JSON.parse(savedConsumptions) : []);
    setCheckouts(savedCheckouts ? JSON.parse(savedCheckouts) : []);
    setAlerts(savedAlerts ? JSON.parse(savedAlerts) : []);
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem(MATERIALS_STORAGE_KEY, JSON.stringify(materials));
  }, [materials]);

  useEffect(() => {
    localStorage.setItem(TOOLS_STORAGE_KEY, JSON.stringify(tools));
  }, [tools]);

  useEffect(() => {
    localStorage.setItem(CONSUMPTION_STORAGE_KEY, JSON.stringify(consumptions));
  }, [consumptions]);

  useEffect(() => {
    localStorage.setItem(CHECKOUTS_STORAGE_KEY, JSON.stringify(checkouts));
  }, [checkouts]);

  useEffect(() => {
    localStorage.setItem(ALERTS_STORAGE_KEY, JSON.stringify(alerts));
  }, [alerts]);

  // Check for low stock alerts
  const checkStockAlerts = useCallback(() => {
    materials.forEach(material => {
      if (material.currentStock <= material.minStock) {
        const existingAlert = alerts.find(alert => 
          alert.materialId === material.id && !alert.acknowledged
        );

        if (!existingAlert) {
          const severity = material.currentStock === 0 ? 'out_of_stock' : 
                          material.currentStock <= material.minStock / 2 ? 'critical' : 'low';
          
          const newAlert: StockAlert = {
            id: Date.now().toString(),
            materialId: material.id,
            materialName: material.name,
            currentStock: material.currentStock,
            minStock: material.minStock,
            severity,
            createdAt: new Date().toISOString(),
            acknowledged: false
          };

          setAlerts(prev => [...prev, newAlert]);

          // Send notification
          showNotification({
            type: 'material',
            title: severity === 'out_of_stock' ? 'Material Esgotado' : 'Estoque Baixo',
            message: `${material.name}: ${material.currentStock} ${material.unit} restante${material.currentStock !== 1 ? 's' : ''}`,
            priority: severity === 'out_of_stock' ? 'critical' : severity === 'critical' ? 'high' : 'medium',
            actionRequired: true,
            metadata: { materialId: material.id }
          });
        }
      }
    });
  }, [materials, alerts, showNotification]);

  // Run stock check when materials change
  useEffect(() => {
    checkStockAlerts();
  }, [checkStockAlerts]);

  // Material management
  const addMaterial = useCallback((material: Omit<Material, 'id'>) => {
    const newMaterial: Material = {
      ...material,
      id: Date.now().toString()
    };
    setMaterials(prev => [...prev, newMaterial]);
    return newMaterial;
  }, []);

  const updateMaterial = useCallback((id: string, updates: Partial<Material>) => {
    setMaterials(prev =>
      prev.map(material =>
        material.id === id ? { ...material, ...updates } : material
      )
    );
  }, []);

  const deleteMaterial = useCallback((id: string) => {
    setMaterials(prev => prev.filter(material => material.id !== id));
  }, []);

  // Tool management
  const addTool = useCallback((tool: Omit<Tool, 'id'>) => {
    const newTool: Tool = {
      ...tool,
      id: Date.now().toString()
    };
    setTools(prev => [...prev, newTool]);
    return newTool;
  }, []);

  const updateTool = useCallback((id: string, updates: Partial<Tool>) => {
    setTools(prev =>
      prev.map(tool =>
        tool.id === id ? { ...tool, ...updates } : tool
      )
    );
  }, []);

  const deleteTool = useCallback((id: string) => {
    setTools(prev => prev.filter(tool => tool.id !== id));
  }, []);

  // Material consumption
  const consumeMaterial = useCallback((consumption: Omit<MaterialConsumption, 'id'>) => {
    const newConsumption: MaterialConsumption = {
      ...consumption,
      id: Date.now().toString()
    };

    setConsumptions(prev => [...prev, newConsumption]);

    // Update material stock
    setMaterials(prev =>
      prev.map(material =>
        material.id === consumption.materialId
          ? { ...material, currentStock: material.currentStock - consumption.quantity }
          : material
      )
    );

    return newConsumption;
  }, []);

  // Tool checkout/checkin
  const checkoutTool = useCallback((checkout: Omit<ToolCheckout, 'id' | 'checkedOutAt'>) => {
    const newCheckout: ToolCheckout = {
      ...checkout,
      id: Date.now().toString(),
      checkedOutAt: new Date().toISOString()
    };

    setCheckouts(prev => [...prev, newCheckout]);

    // Update tool status
    updateTool(checkout.toolId, {
      status: 'in_use',
      currentUser: checkout.employeeId,
      checkoutTime: newCheckout.checkedOutAt
    });

    return newCheckout;
  }, [updateTool]);

  const checkinTool = useCallback((checkoutId: string, condition: ToolCheckout['condition'], notes?: string, damages?: string[]) => {
    const checkout = checkouts.find(c => c.id === checkoutId);
    if (!checkout) return;

    setCheckouts(prev =>
      prev.map(c =>
        c.id === checkoutId
          ? {
              ...c,
              checkedInAt: new Date().toISOString(),
              condition,
              notes,
              damages
            }
          : c
      )
    );

    // Update tool status
    const toolStatus = condition === 'damaged' ? 'maintenance' : 'available';
    updateTool(checkout.toolId, {
      status: toolStatus,
      currentUser: undefined,
      checkoutTime: undefined,
      condition: condition === 'same' ? 'good' : condition === 'worse' ? 'fair' : 'poor'
    });
  }, [checkouts, updateTool]);

  // Alert management
  const acknowledgeAlert = useCallback((alertId: string, acknowledgedBy: string) => {
    setAlerts(prev =>
      prev.map(alert =>
        alert.id === alertId
          ? {
              ...alert,
              acknowledged: true,
              acknowledgedBy,
              acknowledgedAt: new Date().toISOString()
            }
          : alert
      )
    );
  }, []);

  // Statistics
  const getStockValue = useCallback(() => {
    return materials.reduce((total, material) => 
      total + (material.currentStock * material.unitCost), 0
    );
  }, [materials]);

  const getLowStockCount = useCallback(() => {
    return materials.filter(material => material.currentStock <= material.minStock).length;
  }, [materials]);

  const getToolsInUse = useCallback(() => {
    return tools.filter(tool => tool.status === 'in_use').length;
  }, [tools]);

  const getActiveCheckouts = useCallback(() => {
    return checkouts.filter(checkout => !checkout.checkedInAt).length;
  }, [checkouts]);

  return {
    // Data
    materials,
    tools,
    consumptions,
    checkouts,
    alerts: alerts.filter(alert => !alert.acknowledged),
    allAlerts: alerts,

    // Material operations
    addMaterial,
    updateMaterial,
    deleteMaterial,
    consumeMaterial,

    // Tool operations
    addTool,
    updateTool,
    deleteTool,
    checkoutTool,
    checkinTool,

    // Alert operations
    acknowledgeAlert,

    // Statistics
    getStockValue,
    getLowStockCount,
    getToolsInUse,
    getActiveCheckouts,
  };
}