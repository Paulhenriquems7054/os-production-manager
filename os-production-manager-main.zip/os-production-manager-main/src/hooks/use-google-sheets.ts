
import { useState, useEffect } from 'react';
import { GoogleSheetsProductionRecord, ProductionRecord } from '@/types/production';

// ID da planilha extraído da URL fornecida
const SHEET_ID = '1AhgzO2tRdmHUjk_4YMBqP1orLJ0rR2UPQFOkqCoBTiM';
const SHEET_GID = '1598789956'; // GID específico da aba da planilha
const MOCK_DATA: GoogleSheetsProductionRecord[] = [
  {
    "Carimbo de data/hora": "02/07/2025 08:26:59",
    "Execultante:": "Ronald de Oliveira",
    "Função:": "Torneiro",
    "Supervisor:": "Welber Oliveira",
    "Peças 1 - [Suspensor TC1A]": "",
    "Peças 1 - [Suspensor T16]": "",
    "Peças 1 - [Anel para suspensor]": "",
    "Peças 1 - [Luva]": "",
    "Peças 1 - [Niple Longo]": "",
    "Peças 2 - [Difusor]": "",
    "Peças 2 - [Packer]": "",
    "Peças 2 - [Válvula Dreno]": "",
    "Peças 2 - [Válvula Check]": "",
    "Peças 2 - [Desareador]": "",
    "Tubo Filtro [Tubo Filtro]": "Abrir canais p/passagem de óleo",
    "Peças 3 -  [Acoplamentos]": "",
    "Peças 3 -  [Cabeça de descarga]": "",
    "Peças 3 -  [Outro serviço]": "",
    "O COLABORADOR FARÁ OUTRO SERVIÇO:": "NÃO",
    "Coluna 17": ""
  },
  {
    "Carimbo de data/hora": "02/07/2025 08:29:23",
    "Execultante:": "João Paulo",
    "Função:": "Torneiro",
    "Supervisor:": "Welber Oliveira",
    "Peças 1 - [Suspensor TC1A]": "",
    "Peças 1 - [Suspensor T16]": "",
    "Peças 1 - [Anel para suspensor]": "",
    "Peças 1 - [Luva]": "Abrir rosca de um lado",
    "Peças 1 - [Niple Longo]": "",
    "Peças 2 - [Difusor]": "",
    "Peças 2 - [Packer]": "",
    "Peças 2 - [Válvula Dreno]": "",
    "Peças 2 - [Válvula Check]": "",
    "Peças 2 - [Desareador]": "",
    "Tubo Filtro [Tubo Filtro]": "",
    "Peças 3 -  [Acoplamentos]": "",
    "Peças 3 -  [Cabeça de descarga]": "",
    "Peças 3 -  [Outro serviço]": "",
    "O COLABORADOR FARÁ OUTRO SERVIÇO:": "NÃO",
    "Coluna 17": ""
  },
  {
    "Carimbo de data/hora": "02/07/2025 08:30:44",
    "Execultante:": "Jacques Thadeu",
    "Função:": "Fresador",
    "Supervisor:": "Welber Oliveira",
    "Peças 1 - [Suspensor TC1A]": "",
    "Peças 1 - [Suspensor T16]": "",
    "Peças 1 - [Anel para suspensor]": "",
    "Peças 1 - [Luva]": "",
    "Peças 1 - [Niple Longo]": "",
    "Peças 2 - [Difusor]": "",
    "Peças 2 - [Packer]": "",
    "Peças 2 - [Válvula Dreno]": "",
    "Peças 2 - [Válvula Check]": "",
    "Peças 2 - [Desareador]": "",
    "Tubo Filtro [Tubo Filtro]": "",
    "Peças 3 -  [Acoplamentos]": "",
    "Peças 3 -  [Cabeça de descarga]": "",
    "Peças 3 -  [Outro serviço]": "",
    "O COLABORADOR FARÁ OUTRO SERVIÇO:": "SIM",
    "Coluna 17": ""
  },
  {
    "Carimbo de data/hora": "02/07/2025 08:31:53",
    "Execultante:": "Silvio Cezar",
    "Função:": "Torneiro",
    "Supervisor:": "Welber Oliveira",
    "Peças 1 - [Suspensor TC1A]": "",
    "Peças 1 - [Suspensor T16]": "",
    "Peças 1 - [Anel para suspensor]": "",
    "Peças 1 - [Luva]": "Abrir rosca de um lado",
    "Peças 1 - [Niple Longo]": "",
    "Peças 2 - [Difusor]": "",
    "Peças 2 - [Packer]": "",
    "Peças 2 - [Válvula Dreno]": "",
    "Peças 2 - [Válvula Check]": "",
    "Peças 2 - [Desareador]": "",
    "Tubo Filtro [Tubo Filtro]": "",
    "Peças 3 -  [Acoplamentos]": "",
    "Peças 3 -  [Cabeça de descarga]": "",
    "Peças 3 -  [Outro serviço]": "",
    "O COLABORADOR FARÁ OUTRO SERVIÇO:": "NÃO",
    "Coluna 17": ""
  },
  {
    "Carimbo de data/hora": "02/07/2025 08:32:39",
    "Execultante:": "Welber Oliveira",
    "Função:": "Supervisor",
    "Supervisor:": "Welber Oliveira",
    "Peças 1 - [Suspensor TC1A]": "",
    "Peças 1 - [Suspensor T16]": "",
    "Peças 1 - [Anel para suspensor]": "",
    "Peças 1 - [Luva]": "",
    "Peças 1 - [Niple Longo]": "",
    "Peças 2 - [Difusor]": "",
    "Peças 2 - [Packer]": "",
    "Peças 2 - [Válvula Dreno]": "",
    "Peças 2 - [Válvula Check]": "",
    "Peças 2 - [Desareador]": "",
    "Tubo Filtro [Tubo Filtro]": "",
    "Peças 3 -  [Acoplamentos]": "",
    "Peças 3 -  [Cabeça de descarga]": "",
    "Peças 3 -  [Outro serviço]": "",
    "O COLABORADOR FARÁ OUTRO SERVIÇO:": "SIM",
    "Coluna 17": ""
  }
];

const transformGoogleSheetsData = (data: GoogleSheetsProductionRecord[]): ProductionRecord[] => {
  return data.map((item, index) => ({
    id: `gs-${index + 1}`,
    user_id: `gs-user-${index + 1}`,
    timestamp: item["Carimbo de data/hora"],
    executante: item["Execultante:"],
    funcao: item["Função:"],
    supervisor: item["Supervisor:"],
    suspensorTC1A: item["Peças 1 - [Suspensor TC1A]"] || "",
    suspensorT16: item["Peças 1 - [Suspensor T16]"] || "",
    anelSuspensor: item["Peças 1 - [Anel para suspensor]"] || "",
    luva: item["Peças 1 - [Luva]"] || "",
    nipleLongo: item["Peças 1 - [Niple Longo]"] || "",
    difusor: item["Peças 2 - [Difusor]"] || "",
    packer: item["Peças 2 - [Packer]"] || "",
    valvulaDreno: item["Peças 2 - [Válvula Dreno]"] || "",
    valvulaCheck: item["Peças 2 - [Válvula Check]"] || "",
    desareador: item["Peças 2 - [Desareador]"] || "",
    tuboFiltro: item["Tubo Filtro [Tubo Filtro]"] || "",
    acoplamentos: item["Peças 3 -  [Acoplamentos]"] || "",
    cabecaDescarga: item["Peças 3 -  [Cabeça de descarga]"] || "",
    outroServico: item["Peças 3 -  [Outro serviço]"] || "",
    colaboradorOutroServico: item["O COLABORADOR FARÁ OUTRO SERVIÇO:"],
    observacoes: item["Coluna 17"] || "",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }));
};

export const useGoogleSheets = () => {
  const [data, setData] = useState<ProductionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastSync, setLastSync] = useState<Date | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Busca dados diretamente da planilha Google Sheets via export CSV público
      const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${SHEET_GID}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Erro HTTP: ${response.status}`);
      }
      
      const csvText = await response.text();
      
      if (!csvText.trim()) {
        throw new Error('Planilha vazia ou sem dados');
      }
      
      // Parse CSV para array de arrays
      const lines = csvText.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
      const rows = lines.slice(1).map(line => {
        // Parse CSV considerando vírgulas dentro de aspas
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      });
      
      // Converte array de arrays para array de objetos
      const sheetsData: GoogleSheetsProductionRecord[] = rows.map((row: string[]) => {
        const record: any = {};
        headers.forEach((header: string, index: number) => {
          record[header] = row[index] || "";
        });
        return record as GoogleSheetsProductionRecord;
      });
      
      const transformedData = transformGoogleSheetsData(sheetsData);
      setData(transformedData);
      setLastSync(new Date());
      
      console.log(`📊 Dados sincronizados do Google Sheets: ${transformedData.length} registros`);
    } catch (err) {
      console.error('Erro ao buscar dados do Google Sheets:', err);
      setError(`Erro ao conectar com Google Sheets: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
      
      // Em caso de erro, usa dados mock como fallback
      const transformedData = transformGoogleSheetsData(MOCK_DATA);
      setData(transformedData);
      setLastSync(new Date());
      console.log('🔄 Usando dados mock como fallback');
    } finally {
      setLoading(false);
    }
  };

  const syncData = () => {
    fetchData();
  };

  useEffect(() => {
    fetchData();
    
    // Sync automático a cada 5 minutos
    const interval = setInterval(fetchData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return {
    data,
    loading,
    error,
    lastSync,
    syncData,
    isConnected: !error && data.length > 0
  };
};
