import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/App';
import { useToast } from '@/hooks/use-toast';

import { ProductionRecord, ProductionFormData, ProductionStats } from '@/types/production';

export const useProductionRecords = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [records, setRecords] = useState<ProductionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRecords = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('production_records')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        setError(error.message);
        toast({
          title: "Erro ao carregar registros",
          description: error.message,
          variant: "destructive",
        });
      } else {
        // Transform database column names to component expected names
        const transformedData = (data || []).map(record => ({
          id: record.id,
          user_id: record.user_id,
          timestamp: record.timestamp,
          executante: record.executante,
          funcao: record.funcao,
          supervisor: record.supervisor,
          suspensorTC1A: record.suspensor_tc1a || '',
          suspensorT16: record.suspensor_t16 || '',
          anelSuspensor: record.anel_suspensor || '',
          luva: record.luva || '',
          nipleLongo: record.niple_longo || '',
          difusor: record.difusor || '',
          packer: record.packer || '',
          valvulaDreno: record.valvula_dreno || '',
          valvulaCheck: record.valvula_check || '',
          desareador: record.desareador || '',
          tuboFiltro: record.tubo_filtro || '',
          acoplamentos: record.acoplamentos || '',
          cabecaDescarga: record.cabeca_descarga || '',
          outroServico: record.outro_servico || '',
          colaboradorOutroServico: (record.colaborador_outro_servico || 'NÃO') as 'SIM' | 'NÃO',
          observacoes: record.observacoes || '',
          created_at: record.created_at,
          updated_at: record.updated_at
        }));
        setRecords(transformedData);
      }
    } catch (err) {
      const errorMessage = 'Erro ao carregar registros de produção';
      setError(errorMessage);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, [user]);

  const addRecord = async (formData: ProductionFormData): Promise<ProductionRecord> => {
    if (!user) throw new Error('Usuário não autenticado');

    // Transform camelCase to snake_case for database
    const newRecord = {
      user_id: user.id,
      timestamp: new Date().toLocaleString('pt-BR'),
      executante: formData.executante,
      funcao: formData.funcao,
      supervisor: formData.supervisor,
      suspensor_tc1a: formData.suspensorTC1A,
      suspensor_t16: formData.suspensorT16,
      anel_suspensor: formData.anelSuspensor,
      luva: formData.luva,
      niple_longo: formData.nipleLongo,
      difusor: formData.difusor,
      packer: formData.packer,
      valvula_dreno: formData.valvulaDreno,
      valvula_check: formData.valvulaCheck,
      desareador: formData.desareador,
      tubo_filtro: formData.tuboFiltro,
      acoplamentos: formData.acoplamentos,
      cabeca_descarga: formData.cabecaDescarga,
      outro_servico: formData.outroServico,
      colaborador_outro_servico: formData.colaboradorOutroServico,
      observacoes: formData.observacoes,
    };

    const { data, error } = await supabase
      .from('production_records')
      .insert([newRecord])
      .select()
      .single();

    if (error) {
      toast({
        title: "Erro ao criar registro",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    // Transform database column names to component expected names
    const transformedData = {
      id: data.id,
      user_id: data.user_id,
      timestamp: data.timestamp,
      executante: data.executante,
      funcao: data.funcao,
      supervisor: data.supervisor,
      suspensorTC1A: data.suspensor_tc1a || '',
      suspensorT16: data.suspensor_t16 || '',
      anelSuspensor: data.anel_suspensor || '',
      luva: data.luva || '',
      nipleLongo: data.niple_longo || '',
      difusor: data.difusor || '',
      packer: data.packer || '',
      valvulaDreno: data.valvula_dreno || '',
      valvulaCheck: data.valvula_check || '',
      desareador: data.desareador || '',
      tuboFiltro: data.tubo_filtro || '',
      acoplamentos: data.acoplamentos || '',
      cabecaDescarga: data.cabeca_descarga || '',
      outroServico: data.outro_servico || '',
      colaboradorOutroServico: (data.colaborador_outro_servico || 'NÃO') as 'SIM' | 'NÃO',
      observacoes: data.observacoes || '',
      created_at: data.created_at,
      updated_at: data.updated_at
    };

    setRecords(prev => [transformedData, ...prev]);
    toast({
      title: "Registro criado",
      description: "Registro de produção criado com sucesso",
    });

    return transformedData;
  };

  const updateRecord = async (id: string, updates: Partial<ProductionRecord>) => {
    // Transform camelCase to snake_case for database
    const transformedUpdates: any = {};
    
    Object.keys(updates).forEach(key => {
      switch (key) {
        case 'suspensorTC1A':
          transformedUpdates.suspensor_tc1a = updates[key];
          break;
        case 'suspensorT16':
          transformedUpdates.suspensor_t16 = updates[key];
          break;
        case 'anelSuspensor':
          transformedUpdates.anel_suspensor = updates[key];
          break;
        case 'nipleLongo':
          transformedUpdates.niple_longo = updates[key];
          break;
        case 'valvulaDreno':
          transformedUpdates.valvula_dreno = updates[key];
          break;
        case 'valvulaCheck':
          transformedUpdates.valvula_check = updates[key];
          break;
        case 'tuboFiltro':
          transformedUpdates.tubo_filtro = updates[key];
          break;
        case 'cabecaDescarga':
          transformedUpdates.cabeca_descarga = updates[key];
          break;
        case 'outroServico':
          transformedUpdates.outro_servico = updates[key];
          break;
        case 'colaboradorOutroServico':
          transformedUpdates.colaborador_outro_servico = updates[key];
          break;
        default:
          transformedUpdates[key] = updates[key];
          break;
      }
    });

    const { error } = await supabase
      .from('production_records')
      .update(transformedUpdates)
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao atualizar registro",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setRecords(prev => prev.map(record => 
      record.id === id ? { ...record, ...updates } : record
    ));

    toast({
      title: "Registro atualizado",
      description: "Registro atualizado com sucesso",
    });
  };

  const deleteRecord = async (id: string) => {
    const { error } = await supabase
      .from('production_records')
      .delete()
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao excluir registro",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setRecords(prev => prev.filter(record => record.id !== id));
    toast({
      title: "Registro excluído",
      description: "Registro excluído com sucesso",
    });
  };

  const getStats = (): ProductionStats => {
    const uniqueEmployees = new Set(records.map(r => r.executante));
    const uniqueFunctions = new Set(records.map(r => r.funcao));
    
    // Count services by looking at the service fields
    const servicesExecuted = records.length;
    
    // Get top function and employee
    const functionCounts = records.reduce((acc, r) => {
      acc[r.funcao] = (acc[r.funcao] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const employeeCounts = records.reduce((acc, r) => {
      acc[r.executante] = (acc[r.executante] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const topFunction = Object.entries(functionCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
    const topEmployee = Object.entries(employeeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';

    // Employee performance
    const employeePerformance = Array.from(uniqueEmployees).map(executante => {
      const employeeRecords = records.filter(r => r.executante === executante);
      return {
        executante,
        totalServices: employeeRecords.length,
        functions: Array.from(new Set(employeeRecords.map(r => r.funcao))),
        lastActivity: employeeRecords[0]?.timestamp || '',
      };
    });

    // Function distribution
    const totalRecords = records.length;
    const functionDistribution = Object.entries(functionCounts).map(([funcao, count]) => ({
      funcao,
      count,
      percentage: totalRecords > 0 ? (count / totalRecords) * 100 : 0,
    }));

    // Daily production (using timestamp field)
    const dailyCounts = records.reduce((acc, r) => {
      const date = r.timestamp.split(' ')[0]; // Get date part from timestamp
      if (!acc[date]) {
        acc[date] = { count: 0, employees: new Set<string>() };
      }
      acc[date].count += 1;
      acc[date].employees.add(r.executante);
      return acc;
    }, {} as Record<string, { count: number; employees: Set<string> }>);
    
    const dailyProduction = Object.entries(dailyCounts)
      .map(([date, data]) => ({ 
        date, 
        count: data.count, 
        employees: Array.from(data.employees) 
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    return {
      totalRecords,
      uniqueEmployees: uniqueEmployees.size,
      servicesExecuted,
      topFunction,
      topEmployee,
      employeePerformance,
      functionDistribution,
      dailyProduction,
    };
  };

  return {
    records,
    loading,
    error,
    addRecord,
    updateRecord,
    deleteRecord,
    getStats,
    refetch: fetchRecords,
  };
};