import { useState, useCallback } from 'react';
import { useDatabaseChat } from './use-database-chat';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

type AiProvider = 'groq' | 'gemini';

interface UseAiChatReturn {
  messages: ChatMessage[];
  isLoading: boolean;
  sendMessage: (message: string, context?: string) => Promise<void>;
  clearChat: () => void;
  groqApiKey: string | null;
  geminiApiKey: string | null;
  setGroqApiKey: (key: string) => void;
  setGeminiApiKey: (key: string) => void;
  currentProvider: AiProvider;
  setCurrentProvider: (provider: AiProvider) => void;
}

export const useAiChat = (): UseAiChatReturn => {
  const { queryDatabase } = useDatabaseChat();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [groqApiKey, setGroqApiKey] = useState<string | null>(
    localStorage.getItem('groq-api-key')
  );
  const [geminiApiKey, setGeminiApiKey] = useState<string | null>(
    localStorage.getItem('gemini-api-key')
  );
  const [currentProvider, setCurrentProvider] = useState<AiProvider>(() => {
    const stored = localStorage.getItem('ai-provider') as AiProvider;
    if (!stored) {
      // Definir Gemini como padrão
      localStorage.setItem('ai-provider', 'gemini');
      return 'gemini';
    }
    return stored;
  });

  const saveGroqApiKey = useCallback((key: string) => {
    localStorage.setItem('groq-api-key', key);
    setGroqApiKey(key);
  }, []);

  const saveGeminiApiKey = useCallback((key: string) => {
    localStorage.setItem('gemini-api-key', key);
    setGeminiApiKey(key);
  }, []);

  const saveCurrentProvider = useCallback((provider: AiProvider) => {
    localStorage.setItem('ai-provider', provider);
    setCurrentProvider(provider);
  }, []);

  const sendMessage = useCallback(async (message: string, context?: string) => {
    console.log('Enviando mensagem:', message);
    console.log('Provider atual:', currentProvider);
    console.log('API Key presente:', !!geminiApiKey);
    
    const currentApiKey = currentProvider === 'groq' ? groqApiKey : geminiApiKey;
    
    if (!currentApiKey) {
      const providerName = currentProvider === 'groq' ? 'Groq' : 'Gemini';
      console.error('API Key não encontrada para:', providerName);
      alert(`Por favor, configure sua chave da API do ${providerName} primeiro`);
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // 🔥 NOVA FUNCIONALIDADE: Buscar dados do banco automaticamente
      console.log('Consultando banco de dados para:', message);
      const dbResult = await queryDatabase(message);
      
      let systemPrompt = `Você é um assistente especializado em análise de dados e relatórios de produção industrial. 
      Responda SEMPRE em português brasileiro de forma concisa e útil sobre os dados apresentados. 
      Forneça insights práticos e sugestões de melhoria quando relevante.
      Seja educado, profissional e sempre responda em português.
      
      🎯 NOSSO DIFERENCIAL: Você tem acesso direto aos dados reais do sistema e pode fornecer 
      feedbacks detalhados e personalizados baseados nas informações atuais da empresa.
      
      DADOS DO BANCO DE DADOS:
      Resumo: ${dbResult.summary}
      Insights automáticos: ${dbResult.insights.join(', ')}
      Dados específicos: ${JSON.stringify(dbResult.data).substring(0, 2000)}...
      
      ${context ? `\n\nContexto adicional: ${context}` : ''}
      
      Use esses dados reais para dar uma resposta precisa e útil ao usuário.`;

      let response;
      
      if (currentProvider === 'groq') {
        response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${currentApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'llama3-8b-8192',
            messages: [
              { role: 'system', content: systemPrompt },
              ...messages.map(msg => ({ role: msg.role, content: msg.content })),
              { role: 'user', content: message }
            ],
            temperature: 0.7,
            max_tokens: 1000,
          }),
        });
      } else {
        // Gemini API
        console.log('Fazendo chamada para Gemini API...');
        const requestBody = {
          contents: [
            {
              parts: [
                {
                  text: `${systemPrompt}\n\nUsuário: ${message}`
                }
              ]
            }
          ]
        };
        console.log('Request body:', requestBody);
        
        response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${currentApiKey}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });
        
        console.log('Resposta da API:', response.status, response.statusText);
      }

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Erro da API:', response.status, errorData);
        const providerName = currentProvider === 'groq' ? 'Groq' : 'Gemini';
        throw new Error(`Erro na API do ${providerName}: ${response.status} - ${errorData}`);
      }

      const data = await response.json();
      console.log('Dados da resposta:', data);
      let aiContent = '';
      
      if (currentProvider === 'groq') {
        aiContent = data.choices[0].message.content;
      } else {
        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
          aiContent = data.candidates[0].content.parts[0].text;
        } else {
          console.error('Estrutura de resposta inesperada:', data);
          throw new Error('Resposta da API do Gemini em formato inesperado');
        }
      }
      
      console.log('Conteúdo da IA:', aiContent);

      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiContent,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Erro no chat com IA:', error);
      alert('Erro ao enviar mensagem. Verifique sua chave da API.');
    } finally {
      setIsLoading(false);
    }
  }, [currentProvider, groqApiKey, geminiApiKey, messages, queryDatabase]);

  const clearChat = useCallback(() => {
    setMessages([]);
  }, []);

  return {
    messages,
    isLoading,
    sendMessage,
    clearChat,
    groqApiKey,
    geminiApiKey,
    setGroqApiKey: saveGroqApiKey,
    setGeminiApiKey: saveGeminiApiKey,
    currentProvider,
    setCurrentProvider: saveCurrentProvider,
  };
};