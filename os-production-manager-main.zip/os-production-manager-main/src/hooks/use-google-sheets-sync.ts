import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface SyncStatus {
  isLoading: boolean;
  lastSync: Date | null;
  error: string | null;
  recordsProcessed: number;
}

export const useGoogleSheetsSync = () => {
  const [status, setStatus] = useState<SyncStatus>({
    isLoading: false,
    lastSync: null,
    error: null,
    recordsProcessed: 0
  });
  const { toast } = useToast();

  const syncWithSheets = useCallback(async () => {
    try {
      setStatus(prev => ({ ...prev, isLoading: true, error: null }));
      
      console.log('🔄 Iniciando sincronização com Google Sheets...');
      
      // Buscar dados da planilha via Edge Function
      const { data, error } = await supabase.functions.invoke('sync-google-sheets', {
        body: {
          sheetId: '1AhgzO2tRdmHUjk_4YMBqP1orLJ0rR2UPQFOkqCoBTiM',
          sheetName: 'Ordens de Serviços'
        }
      });

      if (error) {
        throw new Error(`Erro na Edge Function: ${error.message}`);
      }

      const { employees, production_records, sync_log } = data;
      
      console.log(`📊 Sincronização concluída:`, {
        employees: employees?.length || 0,
        production_records: production_records?.length || 0
      });

      setStatus({
        isLoading: false,
        lastSync: new Date(),
        error: null,
        recordsProcessed: (employees?.length || 0) + (production_records?.length || 0)
      });

      toast({
        title: "Sincronização concluída",
        description: `${status.recordsProcessed} registros processados com sucesso`,
      });

    } catch (error) {
      console.error('❌ Erro na sincronização:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      
      setStatus(prev => ({
        ...prev,
        isLoading: false,
        error: errorMessage
      }));

      toast({
        title: "Erro na sincronização",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [toast, status.recordsProcessed]);

  // Obter último log de sincronização ao carregar
  useEffect(() => {
    const getLastSync = async () => {
      try {
        const { data } = await supabase
          .from('sheet_sync_log')
          .select('*')
          .order('last_sync', { ascending: false })
          .limit(1)
          .single();

        if (data) {
          setStatus(prev => ({
            ...prev,
            lastSync: new Date(data.last_sync),
            recordsProcessed: data.records_processed || 0
          }));
        }
      } catch (error) {
        console.log('Nenhum log de sincronização encontrado');
      }
    };

    getLastSync();
  }, []);

  // Sincronização automática a cada 10 minutos
  useEffect(() => {
    const interval = setInterval(() => {
      if (!status.isLoading) {
        syncWithSheets();
      }
    }, 10 * 60 * 1000); // 10 minutos

    return () => clearInterval(interval);
  }, [syncWithSheets, status.isLoading]);

  return {
    ...status,
    syncNow: syncWithSheets
  };
};