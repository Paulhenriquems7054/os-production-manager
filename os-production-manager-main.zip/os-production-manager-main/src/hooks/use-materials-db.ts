import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/App';
import { useToast } from '@/hooks/use-toast';

export interface Material {
  id: string;
  name: string;
  description?: string;
  category: string;
  unit: string;
  current_stock: number;
  minimum_stock: number;
  unit_cost?: number;
  supplier?: string;
  location?: string;
  created_at: string;
  updated_at: string;
}

export interface MaterialMovement {
  id: string;
  material_id: string;
  user_id: string;
  movement_type: 'in' | 'out';
  quantity: number;
  reason?: string;
  order_id?: string;
  created_at: string;
}

export interface MaterialFormData {
  name: string;
  description?: string;
  category: string;
  unit: string;
  current_stock: number;
  minimum_stock: number;
  unit_cost?: number;
  supplier?: string;
  location?: string;
}

export interface MovementFormData {
  material_id: string;
  movement_type: 'in' | 'out';
  quantity: number;
  reason?: string;
  order_id?: string;
}

export const useMaterialsDB = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [materials, setMaterials] = useState<Material[]>([]);
  const [movements, setMovements] = useState<MaterialMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMaterials = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('materials')
        .select('*')
        .order('name');

      if (error) {
        setError(error.message);
        toast({
          title: "Erro ao carregar materiais",
          description: error.message,
          variant: "destructive",
        });
      } else {
        setMaterials(data || []);
      }
    } catch (err) {
      const errorMessage = 'Erro ao carregar materiais';
      setError(errorMessage);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMovements = async () => {
    try {
      const { data, error } = await supabase
        .from('material_movements')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching movements:', error);
      } else {
        setMovements((data || []) as MaterialMovement[]);
      }
    } catch (err) {
      console.error('Error fetching movements:', err);
    }
  };

  useEffect(() => {
    fetchMaterials();
    fetchMovements();
  }, []);

  const addMaterial = async (formData: MaterialFormData): Promise<Material> => {
    const { data, error } = await supabase
      .from('materials')
      .insert([formData])
      .select()
      .single();

    if (error) {
      toast({
        title: "Erro ao criar material",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setMaterials(prev => [...prev, data]);
    toast({
      title: "Material criado",
      description: `Material ${data.name} criado com sucesso`,
    });

    return data;
  };

  const updateMaterial = async (id: string, updates: Partial<Material>) => {
    const { error } = await supabase
      .from('materials')
      .update(updates)
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao atualizar material",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setMaterials(prev => prev.map(material => 
      material.id === id ? { ...material, ...updates } : material
    ));

    toast({
      title: "Material atualizado",
      description: "Material atualizado com sucesso",
    });
  };

  const deleteMaterial = async (id: string) => {
    const { error } = await supabase
      .from('materials')
      .delete()
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao excluir material",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setMaterials(prev => prev.filter(material => material.id !== id));
    toast({
      title: "Material excluído",
      description: "Material excluído com sucesso",
    });
  };

  const addMovement = async (formData: MovementFormData): Promise<MaterialMovement> => {
    if (!user) throw new Error('Usuário não autenticado');

    const newMovement = {
      ...formData,
      user_id: user.id,
    };

    const { data, error } = await supabase
      .from('material_movements')
      .insert([newMovement])
      .select()
      .single();

    if (error) {
      toast({
        title: "Erro ao registrar movimentação",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setMovements(prev => [data as MaterialMovement, ...prev]);
    
    // Refresh materials to get updated stock
    await fetchMaterials();

    toast({
      title: "Movimentação registrada",
      description: `${formData.movement_type === 'in' ? 'Entrada' : 'Saída'} registrada com sucesso`,
    });

    return data as MaterialMovement;
  };

  const getLowStockMaterials = () => {
    return materials.filter(material => 
      material.current_stock <= material.minimum_stock
    );
  };

  const getMaterialById = (id: string) => {
    return materials.find(material => material.id === id);
  };

  const getMaterialMovements = (materialId: string) => {
    return movements.filter(movement => movement.material_id === materialId);
  };

  return {
    materials,
    movements,
    loading,
    error,
    addMaterial,
    updateMaterial,
    deleteMaterial,
    addMovement,
    getLowStockMaterials,
    getMaterialById,
    getMaterialMovements,
    refetch: fetchMaterials,
  };
};