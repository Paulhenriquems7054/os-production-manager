import { useState, useEffect } from 'react';
import { useAuth } from '@/App';
import { supabase } from '@/integrations/supabase/client';

export interface UserProfile {
  id: string;
  user_id?: string;
  nome_completo: string | null;
  full_name?: string | null; // For backward compatibility
  role: string;
  department: string | null;
  avatar_url?: string | null;
  senha_hash?: string;
  created_at: string;
  updated_at: string;
}

export const useProfile = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Criar profile baseado nos dados do usuário logado
  const profile: UserProfile | null = user ? {
    id: user.id,
    user_id: user.id,
    nome_completo: user.name,
    role: user.role,
    department: user.department,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  } : null;

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user || !profile) return false;

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('user_id', user.id);

      if (error) {
        setError(error.message);
        return false;
      }

      return true;
    } catch (err) {
      setError('Erro ao atualizar perfil');
      return false;
    }
  };

  // Helper functions para compatibilidade com código antigo
  const getUserType = (): 'admin' | 'supervisor' | 'user' => {
    if (!user) return 'user';
    // Usar o role diretamente do usuário logado
    if (user.role === 'admin') return 'admin';
    if (user.role === 'supervisor') return 'supervisor';
    return 'user';
  };

  const getUsername = (): string => {
    return user?.name || 'Usuário';
  };

  return {
    profile,
    loading,
    error,
    updateProfile,
    // Helpers para compatibilidade
    userType: getUserType(),
    username: getUsername(),
  };
};