import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/App';
import { useToast } from '@/hooks/use-toast';

export interface QualityInspection {
  id: string;
  order_id: string;
  inspector_id: string;
  inspection_type: string;
  status: 'pending' | 'approved' | 'rejected' | 'needs_review';
  score?: number;
  observations?: string;
  corrective_actions?: string;
  inspection_date: string;
  created_at: string;
  updated_at: string;
}

export interface QualityInspectionFormData {
  order_id: string;
  inspection_type: string;
  status: 'pending' | 'approved' | 'rejected' | 'needs_review';
  score?: number;
  observations?: string;
  corrective_actions?: string;
}

export const useQualityInspections = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [inspections, setInspections] = useState<QualityInspection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchInspections = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('quality_inspections')
        .select('*')
        .order('inspection_date', { ascending: false });

      if (error) {
        setError(error.message);
        toast({
          title: "Erro ao carregar inspeções",
          description: error.message,
          variant: "destructive",
        });
      } else {
        setInspections((data || []) as QualityInspection[]);
      }
    } catch (err) {
      const errorMessage = 'Erro ao carregar inspeções de qualidade';
      setError(errorMessage);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInspections();
  }, []);

  const addInspection = async (formData: QualityInspectionFormData): Promise<QualityInspection> => {
    if (!user) throw new Error('Usuário não autenticado');

    const newInspection = {
      ...formData,
      inspector_id: user.id,
    };

    const { data, error } = await supabase
      .from('quality_inspections')
      .insert([newInspection])
      .select()
      .single();

    if (error) {
      toast({
        title: "Erro ao criar inspeção",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setInspections(prev => [data as QualityInspection, ...prev]);
    toast({
      title: "Inspeção criada",
      description: "Inspeção de qualidade criada com sucesso",
    });

    return data as QualityInspection;
  };

  const updateInspection = async (id: string, updates: Partial<QualityInspection>) => {
    const { error } = await supabase
      .from('quality_inspections')
      .update(updates)
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao atualizar inspeção",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setInspections(prev => prev.map(inspection => 
      inspection.id === id ? { ...inspection, ...updates } : inspection
    ));

    toast({
      title: "Inspeção atualizada",
      description: "Inspeção atualizada com sucesso",
    });
  };

  const deleteInspection = async (id: string) => {
    const { error } = await supabase
      .from('quality_inspections')
      .delete()
      .eq('id', id);

    if (error) {
      toast({
        title: "Erro ao excluir inspeção",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }

    setInspections(prev => prev.filter(inspection => inspection.id !== id));
    toast({
      title: "Inspeção excluída",
      description: "Inspeção excluída com sucesso",
    });
  };

  const getInspectionsByOrder = (orderId: string) => {
    return inspections.filter(inspection => inspection.order_id === orderId);
  };

  const getInspectionStats = () => {
    const total = inspections.length;
    const approved = inspections.filter(i => i.status === 'approved').length;
    const rejected = inspections.filter(i => i.status === 'rejected').length;
    const pending = inspections.filter(i => i.status === 'pending').length;
    const needsReview = inspections.filter(i => i.status === 'needs_review').length;

    const averageScore = inspections
      .filter(i => i.score !== null && i.score !== undefined)
      .reduce((sum, i) => sum + (i.score || 0), 0) / 
      inspections.filter(i => i.score !== null && i.score !== undefined).length || 0;

    return {
      total,
      approved,
      rejected,
      pending,
      needsReview,
      averageScore: Math.round(averageScore * 100) / 100,
      approvalRate: total > 0 ? Math.round((approved / total) * 100) : 0,
    };
  };

  return {
    inspections,
    loading,
    error,
    addInspection,
    updateInspection,
    deleteInspection,
    getInspectionsByOrder,
    getInspectionStats,
    refetch: fetchInspections,
  };
};