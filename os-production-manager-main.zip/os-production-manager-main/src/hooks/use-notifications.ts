import { useState, useEffect, useCallback } from 'react';
import type { Notification, NotificationSettings } from '@/types/notifications';
import { ServiceOrder } from '@/types/order';
import { useToast } from '@/hooks/use-toast';
import { createClient } from '@supabase/supabase-js';

const NOTIFICATION_STORAGE_KEY = 'notifications';
const SETTINGS_STORAGE_KEY = 'notification-settings';

// Initialize Supabase client only if env vars are present
const supabase = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY
  ? createClient(
      import.meta.env.VITE_SUPABASE_URL,
      import.meta.env.VITE_SUPABASE_ANON_KEY
    )
  : null;

const defaultSettings: NotificationSettings = {
  enablePush: true,
  enableEmail: false,
  enableSound: true,
  qualityAlerts: true,
  productivityAlerts: true,
  approvalAlerts: true,
  materialAlerts: true,
  emailRecipients: [],
};

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>(defaultSettings);
  const { toast } = useToast();

  // Load notifications and settings from localStorage
  useEffect(() => {
    const storedNotifications = localStorage.getItem(NOTIFICATION_STORAGE_KEY);
    const storedSettings = localStorage.getItem(SETTINGS_STORAGE_KEY);

    if (storedNotifications) {
      setNotifications(JSON.parse(storedNotifications));
    }
    if (storedSettings) {
      setSettings({ ...defaultSettings, ...JSON.parse(storedSettings) });
    }
  }, []);

  // Save notifications to localStorage
  useEffect(() => {
    localStorage.setItem(NOTIFICATION_STORAGE_KEY, JSON.stringify(notifications));
  }, [notifications]);

  // Save settings to localStorage
  useEffect(() => {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  // Request permission for push notifications
  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }

    return false;
  }, []);

  // Send email notification
  const sendEmailNotification = useCallback(async (notification: Notification) => {
    if (!settings.enableEmail || !settings.emailRecipients || settings.emailRecipients.length === 0 || !supabase) {
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('send-notification-email', {
        body: {
          notification,
          recipients: settings.emailRecipients,
        }
      });

      if (error) {
        console.error('Erro ao enviar email:', error);
        toast({
          title: 'Erro no Email',
          description: 'Falha ao enviar notificação por email',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Email Enviado',
          description: 'Notificação enviada por email com sucesso',
        });
      }
    } catch (error) {
      console.error('Erro ao enviar email:', error);
      toast({
        title: 'Erro no Email',
        description: 'Falha ao enviar notificação por email',
        variant: 'destructive',
      });
    }
  }, [settings.enableEmail, settings.emailRecipients, toast]);

  // Send Zapier webhook
  const sendWebhook = useCallback(async (notification: Notification) => {
    if (!settings.webhookUrl) return;

    try {
      await fetch(settings.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        mode: 'no-cors',
        body: JSON.stringify({
          notification,
          timestamp: new Date().toISOString(),
          source: 'OS Production Manager',
        }),
      });
    } catch (error) {
      console.error('Error sending webhook:', error);
    }
  }, [settings.webhookUrl]);

  // Show notification
  const showNotification = useCallback(async (notificationData: Omit<Notification, 'id' | 'read' | 'createdAt'>) => {
    const notification: Notification = {
      ...notificationData,
      id: Date.now().toString(),
      read: false,
      createdAt: new Date().toISOString(),
    };

    setNotifications(prev => [notification, ...prev]);

    // Show toast
    toast({
      title: notification.title,
      description: notification.message,
      variant: notification.priority === 'critical' || notification.priority === 'high' ? 'destructive' : 'default',
    });

    // Show browser notification
    if (settings.enablePush && Notification.permission === 'granted') {
      new Notification(notification.title, {
        body: notification.message,
        icon: '/placeholder.svg',
        tag: notification.id,
      });
    }

    // Play sound
    if (settings.enableSound && notification.priority === 'critical') {
      // Create audio element for critical notifications
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmUfCDuJ0fPTgjEFJny8z+OWPwgUYrPq564WGAk+ktXxuGUdBjdyjd3SFTF');
      audio.play().catch(() => {}); // Ignore errors
    }

    // Send email notification if enabled
    if (settings.enableEmail) {
      await sendEmailNotification(notification);
    }

    // Send webhook if configured
    if (settings.webhookUrl) {
      await sendWebhook(notification);
    }

    return notification;
  }, [settings, toast, sendWebhook, sendEmailNotification]);

  // Mark notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  }, []);

  // Mark all as read
  const markAllAsRead = useCallback(() => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  }, []);

  // Clear notification
  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  }, []);

  // Clear all notifications
  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Update settings
  const updateSettings = useCallback((newSettings: Partial<NotificationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  // Auto-generate notifications for quality issues
  const checkQualityIssues = useCallback((orders: ServiceOrder[]) => {
    orders.forEach(order => {
      if (order.status === 'quality_rejected' && order.qualityCheck) {
        const criticalDefects = order.qualityCheck.defects?.filter(d => d.severity === 'critical') || [];
        
        if (criticalDefects.length > 0 && settings.qualityAlerts) {
          showNotification({
            type: 'quality',
            title: 'Defeito Crítico Identificado',
            message: `OS #${order.id}: ${criticalDefects.length} defeito(s) crítico(s) encontrado(s)`,
            priority: 'critical',
            orderId: order.id,
            actionRequired: true,
          });
        }
      }

      if (order.status === 'rework' && (order.reworkCount || 0) >= 2 && settings.qualityAlerts) {
        showNotification({
          type: 'quality',
          title: 'Múltiplos Retrabalhos',
          message: `OS #${order.id}: ${order.reworkCount} retrabalhos. Investigação necessária.`,
          priority: 'high',
          orderId: order.id,
          actionRequired: true,
        });
      }
    });
  }, [settings.qualityAlerts, showNotification]);

  // Auto-generate productivity alerts
  const checkProductivityAlerts = useCallback((orders: ServiceOrder[]) => {
    if (!settings.productivityAlerts) return;

    const today = new Date().toDateString();
    const todayOrders = orders.filter(order => 
      new Date(order.createdAt).toDateString() === today
    );

    const completedToday = todayOrders.filter(order => 
      order.status === 'quality_approved' || order.status === 'completed'
    ).length;

    // Alert if less than 5 orders completed today (example threshold)
    if (todayOrders.length > 0 && completedToday < 5) {
      showNotification({
        type: 'productivity',
        title: 'Meta de Produtividade',
        message: `Apenas ${completedToday} ordens concluídas hoje. Meta: 5+`,
        priority: 'medium',
        actionRequired: false,
      });
    }
  }, [settings.productivityAlerts, showNotification]);

  // Auto-generate approval alerts
  const checkApprovalAlerts = useCallback((orders: ServiceOrder[]) => {
    if (!settings.approvalAlerts) return;

    const pendingApproval = orders.filter(order => 
      order.status === 'awaiting_quality' || order.status === 'active'
    );

    if (pendingApproval.length > 10) {
      showNotification({
        type: 'approval',
        title: 'Muitas Aprovações Pendentes',
        message: `${pendingApproval.length} ordens aguardando aprovação`,
        priority: 'high',
        actionRequired: true,
      });
    }
  }, [settings.approvalAlerts, showNotification]);

  const unreadCount = notifications.filter(n => !n.read).length;
  const criticalCount = notifications.filter(n => !n.read && n.priority === 'critical').length;

  return {
    notifications,
    settings,
    unreadCount,
    criticalCount,
    showNotification,
    markAsRead,
    markAllAsRead,
    clearNotification,
    clearAll,
    updateSettings,
    requestPermission,
    checkQualityIssues,
    checkProductivityAlerts,
    checkApprovalAlerts,
  };
}