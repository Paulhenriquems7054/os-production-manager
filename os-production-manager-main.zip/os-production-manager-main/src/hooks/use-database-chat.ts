import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DatabaseQueryResult {
  data: any[];
  summary: string;
  insights: string[];
}

export const useDatabaseChat = () => {
  const queryDatabase = useCallback(async (userMessage: string): Promise<DatabaseQueryResult> => {
    console.log('Analisando pergunta do usuário:', userMessage);
    
    try {
      // Analisar a pergunta e determinar que dados buscar
      const queryType = analyzeQuery(userMessage);
      let data: any[] = [];
      let summary = '';
      let insights: string[] = [];

      switch (queryType) {
        case 'orders':
          const { data: orders } = await supabase
            .from('service_orders')
            .select('*')
            .order('createdAt', { ascending: false })
            .limit(50);
          
          data = orders || [];
          summary = `Encontradas ${data.length} ordens de serviço. Status: ${getStatusSummary(data)}`;
          insights = generateOrderInsights(data);
          break;

        case 'production':
          const { data: production } = await supabase
            .from('production_records')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(50);
          
          data = production || [];
          summary = `Dados de ${data.length} registros de produção analisados.`;
          insights = generateProductionInsights(data);
          break;

        case 'quality':
          const { data: quality } = await supabase
            .from('quality_inspections')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(50);
          
          data = quality || [];
          summary = `${data.length} inspeções de qualidade no sistema.`;
          insights = generateQualityInsights(data);
          break;

        case 'materials':
          const { data: materials } = await supabase
            .from('materials')
            .select('*')
            .order('current_stock', { ascending: true });
          
          data = materials || [];
          summary = `Inventário com ${data.length} materiais cadastrados.`;
          insights = generateMaterialInsights(data);
          break;

        case 'employees':
          const { data: employees } = await supabase
            .from('employees')
            .select('*');
          
          data = employees || [];
          summary = `${data.length} funcionários cadastrados no sistema.`;
          insights = generateEmployeeInsights(data);
          break;

        default:
          // Busca geral em múltiplas tabelas
          const [ordersRes, productionRes, qualityRes, materialsRes, employeesRes] = await Promise.all([
            supabase.from('service_orders').select('*').limit(10),
            supabase.from('production_records').select('*').limit(10),
            supabase.from('quality_inspections').select('*').limit(10),
            supabase.from('materials').select('*').limit(10),
            supabase.from('employees').select('*').limit(10)
          ]);

          data = [
            ...(ordersRes.data || []),
            ...(productionRes.data || []),
            ...(qualityRes.data || []),
            ...(materialsRes.data || []),
            ...(employeesRes.data || [])
          ];
          
          summary = 'Visão geral dos dados do sistema';
          insights = ['Dados de todas as áreas foram analisados para responder sua pergunta'];
      }

      return { data, summary, insights };

    } catch (error) {
      console.error('Erro ao consultar banco de dados:', error);
      return {
        data: [],
        summary: 'Erro ao acessar os dados',
        insights: ['Não foi possível acessar o banco de dados no momento']
      };
    }
  }, []);

  const analyzeQuery = (message: string): string => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('ordem') || lowerMessage.includes('serviço') || lowerMessage.includes('os')) {
      return 'orders';
    }
    if (lowerMessage.includes('produção') || lowerMessage.includes('produtividade')) {
      return 'production';
    }
    if (lowerMessage.includes('qualidade') || lowerMessage.includes('inspeção')) {
      return 'quality';
    }
    if (lowerMessage.includes('material') || lowerMessage.includes('estoque') || lowerMessage.includes('inventário')) {
      return 'materials';
    }
    if (lowerMessage.includes('funcionário') || lowerMessage.includes('colaborador') || lowerMessage.includes('pessoa')) {
      return 'employees';
    }
    
    return 'general';
  };

  const getStatusSummary = (orders: any[]) => {
    const statusCount = orders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {});
    
    return Object.entries(statusCount)
      .map(([status, count]) => `${count} ${status}`)
      .join(', ');
  };

  const generateOrderInsights = (orders: any[]): string[] => {
    const insights = [];
    
    const pendingOrders = orders.filter(o => o.status === 'pending').length;
    const completedOrders = orders.filter(o => o.status === 'completed').length;
    const rejectedOrders = orders.filter(o => o.status === 'rejected').length;
    
    if (pendingOrders > 0) {
      insights.push(`${pendingOrders} ordens pendentes necessitam atenção`);
    }
    
    if (rejectedOrders > 0) {
      insights.push(`${rejectedOrders} ordens rejeitadas podem indicar problemas de qualidade`);
    }
    
    const completionRate = orders.length > 0 ? (completedOrders / orders.length * 100).toFixed(1) : 0;
    insights.push(`Taxa de conclusão: ${completionRate}%`);
    
    return insights;
  };

  const generateProductionInsights = (production: any[]): string[] => {
    const insights = [];
    
    if (production.length > 0) {
      const executors = [...new Set(production.map(p => p.executante))];
      insights.push(`${executors.length} executores diferentes identificados`);
      
      const supervisors = [...new Set(production.map(p => p.supervisor))];
      insights.push(`${supervisors.length} supervisores atuando`);
      
      const recentRecords = production.filter(p => {
        const recordDate = new Date(p.created_at);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return recordDate > weekAgo;
      }).length;
      
      insights.push(`${recentRecords} registros na última semana`);
    }
    
    return insights;
  };

  const generateQualityInsights = (quality: any[]): string[] => {
    const insights = [];
    
    if (quality.length > 0) {
      const avgScore = quality
        .filter(q => q.score)
        .reduce((sum, q) => sum + q.score, 0) / quality.filter(q => q.score).length;
      
      if (!isNaN(avgScore)) {
        insights.push(`Pontuação média de qualidade: ${avgScore.toFixed(1)}`);
      }
      
      const pendingInspections = quality.filter(q => q.status === 'pending').length;
      if (pendingInspections > 0) {
        insights.push(`${pendingInspections} inspeções pendentes`);
      }
    }
    
    return insights;
  };

  const generateMaterialInsights = (materials: any[]): string[] => {
    const insights = [];
    
    if (materials.length > 0) {
      const lowStock = materials.filter(m => m.current_stock <= m.minimum_stock).length;
      if (lowStock > 0) {
        insights.push(`⚠️ ${lowStock} materiais com estoque baixo`);
      }
      
      const totalValue = materials.reduce((sum, m) => sum + (m.current_stock * (m.unit_cost || 0)), 0);
      insights.push(`Valor total em estoque: R$ ${totalValue.toFixed(2)}`);
      
      const categories = [...new Set(materials.map(m => m.category))];
      insights.push(`${categories.length} categorias de materiais`);
    }
    
    return insights;
  };

  const generateEmployeeInsights = (employees: any[]): string[] => {
    const insights = [];
    
    if (employees.length > 0) {
      const functions = employees.reduce((acc, emp) => {
        acc[emp.funcao] = (acc[emp.funcao] || 0) + 1;
        return acc;
      }, {});
      
      Object.entries(functions).forEach(([funcao, count]) => {
        insights.push(`${count} ${funcao}(s)`);
      });
      
      const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
      if (departments.length > 0) {
        insights.push(`${departments.length} departamentos ativos`);
      }
      
      const supervisors = [...new Set(employees.map(e => e.supervisor).filter(Boolean))];
      insights.push(`${supervisors.length} supervisores diferentes`);
      
      const activeEmployees = employees.filter(e => e.status === 'active').length;
      insights.push(`${activeEmployees} funcionários ativos`);
    }
    
    return insights;
  };

  return { queryDatabase };
};