import { ServiceOrder } from '@/types/order';
import { ProductionRecord } from '@/types/production';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import jsPDF from 'jspdf';

export const generateOrderPDF = async (order: ServiceOrder): Promise<void> => {
  console.log('🔧 Iniciando geração de PDF para ordem:', order);
  
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy HH:mm', { locale: ptBR });
    } catch (error) {
      console.error('Erro ao formatar data:', dateString, error);
      return 'Data inválida';
    }
  };

  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 'N/A';
    try {
      const startDate = new Date(start);
      const endDate = new Date(end);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return 'N/A';
      const diffMs = endDate.getTime() - startDate.getTime();
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m`;
    } catch {
      return 'N/A';
    }
  };

  try {
    // Create PDF
    const pdf = new jsPDF();
    
    // Header
    pdf.setFontSize(20);
    pdf.setTextColor(220, 38, 38); // Brand red color
    pdf.text('DClamps', 105, 20, { align: 'center' });
    
    pdf.setFontSize(14);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Ordem de Serviço #${order.order_number || order.id.substring(0, 8)}`, 105, 30, { align: 'center' });
    
    // Reset color for content
    pdf.setTextColor(0, 0, 0);
    
    // Content sections
    let yPosition = 50;
    
    // Section: Informações Gerais
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Informações Gerais', 20, yPosition);
    yPosition += 10;
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Funcionário: ${order.employee || 'N/A'}`, 20, yPosition);
    pdf.text(`Status: ${order.status === 'completed' ? 'Concluída' : 'Em andamento'}`, 110, yPosition);
    yPosition += 7;
    
    pdf.text(`Data de Criação: ${formatDate(order.createdAt)}`, 20, yPosition);
    pdf.text(`Quantidade: ${order.quantity}`, 110, yPosition);
    yPosition += 15;
    
    // Section: Detalhes da Produção
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Detalhes da Produção', 20, yPosition);
    yPosition += 10;
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Categoria: ${order.categoryName || 'N/A'}`, 20, yPosition);
    pdf.text(`Peça: ${order.piece || 'N/A'}`, 110, yPosition);
    yPosition += 7;
    
    pdf.text(`Serviço: ${order.serviceName || 'N/A'}`, 20, yPosition);
    pdf.text(`Duração: ${calculateDuration(order.startTime, order.endTime)}`, 110, yPosition);
    yPosition += 15;
    
    // Section: Horários
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Horários', 20, yPosition);
    yPosition += 10;
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Início: ${order.startTime ? formatDate(order.startTime) : 'N/A'}`, 20, yPosition);
    pdf.text(`Término: ${order.endTime ? formatDate(order.endTime) : 'N/A'}`, 110, yPosition);
    yPosition += 15;
    
    // Section: Observações (if any)
    if (order.observations) {
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Observações', 20, yPosition);
      yPosition += 10;
      
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      const splitText = pdf.splitTextToSize(order.observations, 170);
      pdf.text(splitText, 20, yPosition);
      yPosition += splitText.length * 5 + 10;
    }
    
    // Footer
    yPosition = Math.max(yPosition, 250); // Ensure footer is at bottom
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Ordem de Serviço gerada em ${formatDate(new Date().toISOString())}`, 105, yPosition, { align: 'center' });
    pdf.text('DClamps - Sistema de Gestão de Produção', 105, yPosition + 5, { align: 'center' });
    
    // Generate filename
    const fileName = `OS_${order.order_number || order.id.substring(0, 8)}_${(order.employee || 'SemFuncionario').replace(/\s+/g, '_')}.pdf`;
    console.log('📄 Gerando arquivo PDF:', fileName);
    
    // Return promise that resolves when download is complete
    return new Promise((resolve, reject) => {
      try {
        // Create blob and download link
        const pdfBlob = pdf.output('blob');
        const url = window.URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        
        link.href = url;
        link.download = fileName;
        link.style.display = 'none';
        
        // Add to DOM temporarily
        document.body.appendChild(link);
        
        // Trigger download
        link.click();
        
        // Clean up after a short delay to ensure download started
        setTimeout(() => {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
          console.log('✅ PDF gerado e download iniciado com sucesso');
          resolve();
        }, 100);
        
      } catch (error) {
        console.error('❌ Erro ao gerar PDF:', error);
        reject(error);
      }
    });
    
  } catch (error) {
    console.error('❌ Erro durante criação do PDF:', error);
    throw error;
  }
};

export const generateMultipleOrdersPDF = async (orders: ServiceOrder[]): Promise<void> => {
  console.log('🔧 Iniciando geração de PDF múltiplo para', orders.length, 'ordens');
  
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy HH:mm', { locale: ptBR });
    } catch (error) {
      console.error('Erro ao formatar data:', dateString, error);
      return 'Data inválida';
    }
  };

  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 'N/A';
    try {
      const startDate = new Date(start);
      const endDate = new Date(end);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return 'N/A';
      const diffMs = endDate.getTime() - startDate.getTime();
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m`;
    } catch {
      return 'N/A';
    }
  };

  try {
    // Create PDF
    const pdf = new jsPDF();
    
    // Header
    pdf.setFontSize(20);
    pdf.setTextColor(220, 38, 38);
    pdf.text('DClamps', 105, 20, { align: 'center' });
    
    pdf.setFontSize(14);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Relatório de Ordens de Serviço (${orders.length} ordens)`, 105, 30, { align: 'center' });
    
    pdf.setTextColor(0, 0, 0);
    
    let yPosition = 50;
    let pageHeight = pdf.internal.pageSize.height;
    
    orders.forEach((order, index) => {
      // Check if we need a new page
      if (yPosition > pageHeight - 60) {
        pdf.addPage();
        yPosition = 20;
      }
      
      // Order header
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(220, 38, 38);
      pdf.text(`OS #${order.order_number || order.id.substring(0, 8)} - ${order.employee}`, 20, yPosition);
      pdf.setTextColor(0, 0, 0);
      yPosition += 10;
      
      // Order details
      pdf.setFontSize(9);
      pdf.setFont('helvetica', 'normal');
      
      pdf.text(`Peça: ${order.piece}`, 20, yPosition);
      pdf.text(`Serviço: ${order.serviceName}`, 110, yPosition);
      yPosition += 6;
      
      pdf.text(`Quantidade: ${order.quantity}`, 20, yPosition);
      pdf.text(`Duração: ${calculateDuration(order.startTime, order.endTime)}`, 110, yPosition);
      yPosition += 6;
      
      pdf.text(`Início: ${formatDate(order.startTime)}`, 20, yPosition);
      pdf.text(`Término: ${formatDate(order.endTime)}`, 110, yPosition);
      yPosition += 6;
      
      pdf.text(`Status: ${order.status === 'completed' ? 'Concluída' : 'Em andamento'}`, 20, yPosition);
      yPosition += 6;
      
      // Observations if any
      if (order.observations) {
        pdf.text('Observações:', 20, yPosition);
        yPosition += 4;
        const splitText = pdf.splitTextToSize(order.observations, 170);
        pdf.text(splitText, 20, yPosition);
        yPosition += splitText.length * 4 + 2;
      }
      
      // Add separator line between orders
      if (index < orders.length - 1) {
        pdf.setDrawColor(200, 200, 200);
        pdf.line(20, yPosition + 2, 190, yPosition + 2);
        yPosition += 8;
      }
    });
    
    // Footer on last page
    const lastPageY = Math.max(yPosition + 20, pageHeight - 20);
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Relatório gerado em ${formatDate(new Date().toISOString())}`, 105, lastPageY, { align: 'center' });
    pdf.text('DClamps - Sistema de Gestão de Produção', 105, lastPageY + 5, { align: 'center' });
    
    // Generate filename
    const fileName = `Relatorio_Ordens_${format(new Date(), 'dd-MM-yyyy_HH-mm', { locale: ptBR })}.pdf`;
    console.log('📄 Gerando relatório PDF:', fileName);
    
    // Return promise that resolves when download is complete
    return new Promise((resolve, reject) => {
      try {
        // Create blob and download link
        const pdfBlob = pdf.output('blob');
        const url = window.URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        
        link.href = url;
        link.download = fileName;
        link.style.display = 'none';
        
        // Add to DOM temporarily
        document.body.appendChild(link);
        
        // Trigger download
        link.click();
        
        // Clean up after a short delay to ensure download started
        setTimeout(() => {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
          console.log('✅ Relatório PDF gerado e download iniciado com sucesso');
          resolve();
        }, 100);
        
      } catch (error) {
        console.error('❌ Erro ao gerar relatório PDF:', error);
        reject(error);
      }
    });
    
  } catch (error) {
    console.error('❌ Erro durante criação do relatório PDF:', error);
    throw error;
  }
};

export const generateProductionReportPDF = async (records: ProductionRecord[]): Promise<void> => {
  console.log('🔧 Iniciando geração de relatório de produção para', records.length, 'registros');
  
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy HH:mm', { locale: ptBR });
    } catch (error) {
      console.error('Erro ao formatar data:', dateString, error);
      return 'Data inválida';
    }
  };

  try {
    // Create PDF
    const pdf = new jsPDF();
    
    // Header
    pdf.setFontSize(20);
    pdf.setTextColor(220, 38, 38);
    pdf.text('DClamps', 105, 20, { align: 'center' });
    
    pdf.setFontSize(14);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Relatório de Produção (${records.length} registros)`, 105, 30, { align: 'center' });
    
    pdf.setTextColor(0, 0, 0);
    
    let yPosition = 50;
    let pageHeight = pdf.internal.pageSize.height;
    
    records.forEach((record, index) => {
      // Check if we need a new page
      if (yPosition > pageHeight - 80) {
        pdf.addPage();
        yPosition = 20;
      }
      
      // Record header
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(220, 38, 38);
      pdf.text(`Registro #${index + 1} - ${record.executante}`, 20, yPosition);
      pdf.setTextColor(0, 0, 0);
      yPosition += 10;
      
      // Record details
      pdf.setFontSize(9);
      pdf.setFont('helvetica', 'normal');
      
      pdf.text(`Data: ${formatDate(record.timestamp)}`, 20, yPosition);
      pdf.text(`Função: ${record.funcao}`, 110, yPosition);
      yPosition += 6;
      
      pdf.text(`Supervisor: ${record.supervisor}`, 20, yPosition);
      yPosition += 8;
      
      // Peças/Serviços section
      pdf.setFont('helvetica', 'bold');
      pdf.text('Peças/Serviços:', 20, yPosition);
      yPosition += 6;
      pdf.setFont('helvetica', 'normal');
      
      const pecas = [
        { label: 'Suspensor TC1A', value: record.suspensorTC1A },
        { label: 'Suspensor T16', value: record.suspensorT16 },
        { label: 'Anel Suspensor', value: record.anelSuspensor },
        { label: 'Luva', value: record.luva },
        { label: 'Niple Longo', value: record.nipleLongo },
        { label: 'Difusor', value: record.difusor },
        { label: 'Packer', value: record.packer },
        { label: 'Válvula Dreno', value: record.valvulaDreno },
        { label: 'Válvula Check', value: record.valvulaCheck },
        { label: 'Desareador', value: record.desareador },
        { label: 'Tubo Filtro', value: record.tuboFiltro },
        { label: 'Acoplamentos', value: record.acoplamentos },
        { label: 'Cabeça Descarga', value: record.cabecaDescarga },
        { label: 'Outro Serviço', value: record.outroServico }
      ];
      
      // Display only non-empty pieces
      const nonEmptyPecas = pecas.filter(p => p.value && p.value.trim() !== '');
      
      nonEmptyPecas.forEach((peca, i) => {
        if (i % 2 === 0) {
          pdf.text(`• ${peca.label}: ${peca.value}`, 20, yPosition);
          if (nonEmptyPecas[i + 1]) {
            pdf.text(`• ${nonEmptyPecas[i + 1].label}: ${nonEmptyPecas[i + 1].value}`, 110, yPosition);
          }
          yPosition += 5;
        }
      });
      
      yPosition += 3;
      
      // Additional info
      if (record.colaboradorOutroServico === 'SIM') {
        pdf.text('✓ Colaborador fará outro serviço', 20, yPosition);
        yPosition += 5;
      }
      
      // Observations if any
      if (record.observacoes && record.observacoes.trim()) {
        pdf.setFont('helvetica', 'bold');
        pdf.text('Observações:', 20, yPosition);
        yPosition += 4;
        pdf.setFont('helvetica', 'normal');
        const splitText = pdf.splitTextToSize(record.observacoes, 170);
        pdf.text(splitText, 20, yPosition);
        yPosition += splitText.length * 4 + 2;
      }
      
      // Add separator line between records
      if (index < records.length - 1) {
        pdf.setDrawColor(200, 200, 200);
        pdf.line(20, yPosition + 2, 190, yPosition + 2);
        yPosition += 8;
      }
    });
    
    // Footer on last page
    const lastPageY = Math.max(yPosition + 20, pageHeight - 20);
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Relatório gerado em ${formatDate(new Date().toISOString())}`, 105, lastPageY, { align: 'center' });
    pdf.text('DClamps - Sistema de Gestão de Produção', 105, lastPageY + 5, { align: 'center' });
    
    // Generate filename
    const fileName = `Relatorio_Producao_${format(new Date(), 'dd-MM-yyyy_HH-mm', { locale: ptBR })}.pdf`;
    console.log('📄 Gerando relatório de produção:', fileName);
    
    // Return promise that resolves when download is complete
    return new Promise((resolve, reject) => {
      try {
        // Create blob and download link
        const pdfBlob = pdf.output('blob');
        const url = window.URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        
        link.href = url;
        link.download = fileName;
        link.style.display = 'none';
        
        // Add to DOM temporarily
        document.body.appendChild(link);
        
        // Trigger download
        link.click();
        
        // Clean up after a short delay to ensure download started
        setTimeout(() => {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
          console.log('✅ Relatório de produção gerado e download iniciado com sucesso');
          resolve();
        }, 100);
        
      } catch (error) {
        console.error('❌ Erro ao gerar relatório de produção:', error);
        reject(error);
      }
    });
    
  } catch (error) {
    console.error('❌ Erro durante criação do relatório de produção:', error);
    throw error;
  }
};