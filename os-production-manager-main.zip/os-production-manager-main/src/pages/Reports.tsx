import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useServiceOrders } from '@/hooks/use-service-orders';
import { ArrowLeft, Download, TrendingUp, Clock, Target, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AiChatBubble } from '@/components/chat/ai-chat-bubble';

const Reports = () => {
  const navigate = useNavigate();
  const { orders } = useServiceOrders();
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const [selectedEmployee, setSelectedEmployee] = useState('all');

  const getDateRange = (period: string) => {
    const now = new Date();
    const start = new Date();
    
    switch (period) {
      case 'today':
        start.setHours(0, 0, 0, 0);
        break;
      case 'week':
        start.setDate(now.getDate() - 7);
        break;
      case 'month':
        start.setMonth(now.getMonth() - 1);
        break;
      case 'quarter':
        start.setMonth(now.getMonth() - 3);
        break;
      default:
        start.setDate(now.getDate() - 7);
    }
    
    return { start, end: now };
  };

  const getFilteredOrders = () => {
    const { start, end } = getDateRange(selectedPeriod);
    return orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      const inPeriod = orderDate >= start && orderDate <= end;
      const matchesEmployee = selectedEmployee === 'all' || order.employee === selectedEmployee;
      return inPeriod && matchesEmployee;
    });
  };

  const calculateProductivityMetrics = () => {
    const filteredOrders = getFilteredOrders();
    const completedOrders = filteredOrders.filter(order => order.status === 'completed');
    
    const totalOrders = filteredOrders.length;
    const completionRate = totalOrders > 0 ? (completedOrders.length / totalOrders) * 100 : 0;
    
    const avgTimePerOrder = completedOrders.length > 0 
      ? completedOrders.reduce((acc, order) => {
          if (order.startTime && order.endTime) {
            const start = new Date(`2000-01-01T${order.startTime}`);
            const end = new Date(`2000-01-01T${order.endTime}`);
            return acc + (end.getTime() - start.getTime());
          }
          return acc;
        }, 0) / completedOrders.length / (1000 * 60) // em minutos
      : 0;

    const employeeProductivity = new Map();
    completedOrders.forEach(order => {
      if (!employeeProductivity.has(order.employee)) {
        employeeProductivity.set(order.employee, { orders: 0, totalTime: 0 });
      }
      const stats = employeeProductivity.get(order.employee);
      stats.orders++;
      
      if (order.startTime && order.endTime) {
        const start = new Date(`2000-01-01T${order.startTime}`);
        const end = new Date(`2000-01-01T${order.endTime}`);
        stats.totalTime += (end.getTime() - start.getTime()) / (1000 * 60);
      }
    });

    const topPerformers = Array.from(employeeProductivity.entries())
      .map(([name, stats]) => ({
        name,
        orders: stats.orders,
        avgTime: stats.orders > 0 ? stats.totalTime / stats.orders : 0
      }))
      .sort((a, b) => b.orders - a.orders)
      .slice(0, 5);

    return {
      totalOrders,
      completedOrders: completedOrders.length,
      completionRate,
      avgTimePerOrder,
      topPerformers
    };
  };

  const calculateTimeComparison = () => {
    const { start: currentStart, end: currentEnd } = getDateRange(selectedPeriod);
    const previousStart = new Date(currentStart);
    const previousEnd = new Date(currentStart);
    
    // Período anterior com mesma duração
    const duration = currentEnd.getTime() - currentStart.getTime();
    previousStart.setTime(currentStart.getTime() - duration);

    const currentOrders = orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      return orderDate >= currentStart && orderDate <= currentEnd;
    });

    const previousOrders = orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      return orderDate >= previousStart && orderDate < currentStart;
    });

    const currentCompleted = currentOrders.filter(o => o.status === 'completed').length;
    const previousCompleted = previousOrders.filter(o => o.status === 'completed').length;
    
    const growth = previousCompleted > 0 
      ? ((currentCompleted - previousCompleted) / previousCompleted) * 100 
      : 0;

    return {
      current: currentCompleted,
      previous: previousCompleted,
      growth: Math.round(growth)
    };
  };

  const generateReport = (type: string) => {
    const metrics = calculateProductivityMetrics();
    const comparison = calculateTimeComparison();
    
    const reportData = `
RELATÓRIO DE PRODUTIVIDADE - ${selectedPeriod.toUpperCase()}
Data: ${new Date().toLocaleDateString('pt-BR')}
Funcionário: ${selectedEmployee === 'all' ? 'Todos' : selectedEmployee}

=== RESUMO EXECUTIVO ===
Total de Ordens: ${metrics.totalOrders}
Ordens Concluídas: ${metrics.completedOrders}
Taxa de Conclusão: ${metrics.completionRate.toFixed(1)}%
Tempo Médio por Ordem: ${metrics.avgTimePerOrder.toFixed(0)} minutos

=== COMPARAÇÃO COM PERÍODO ANTERIOR ===
Período Atual: ${comparison.current} ordens concluídas
Período Anterior: ${comparison.previous} ordens concluídas
Crescimento: ${comparison.growth > 0 ? '+' : ''}${comparison.growth}%

=== TOP PERFORMERS ===
${metrics.topPerformers.map((p, i) => 
  `${i + 1}. ${p.name} - ${p.orders} ordens (${p.avgTime.toFixed(0)}min média)`
).join('\n')}

=== DETALHAMENTO POR FUNCIONÁRIO ===
${getFilteredOrders().reduce((acc, order) => {
  if (!acc[order.employee]) {
    acc[order.employee] = { total: 0, completed: 0 };
  }
  acc[order.employee].total++;
  if (order.status === 'completed') acc[order.employee].completed++;
  return acc;
}, {} as Record<string, any>)}
    `.trim();

    const blob = new Blob([reportData], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio-produtividade-${selectedPeriod}-${new Date().toISOString().split('T')[0]}.txt`;
    link.click();

    toast({
      title: "Relatório Gerado",
      description: "Download iniciado com sucesso",
    });
  };

  const metrics = calculateProductivityMetrics();
  const comparison = calculateTimeComparison();
  const uniqueEmployees = [...new Set(orders.map(order => order.employee))];

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-6xl mx-auto p-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Relatórios Avançados</h1>
              <p className="text-muted-foreground">Análise detalhada de produtividade e desempenho</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {/* Filtros */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtros de Relatório</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 flex-wrap">
              <div className="space-y-2">
                <label className="text-sm font-medium">Período</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Hoje</SelectItem>
                    <SelectItem value="week">Última Semana</SelectItem>
                    <SelectItem value="month">Último Mês</SelectItem>
                    <SelectItem value="quarter">Último Trimestre</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Funcionário</label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Funcionários</SelectItem>
                    {uniqueEmployees.map(employee => (
                      <SelectItem key={employee} value={employee}>
                        {employee}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Exportar</label>
                <Button onClick={() => generateReport('productivity')}>
                  <Download className="w-4 h-4 mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="productivity" className="space-y-6">
          <TabsList>
            <TabsTrigger value="productivity">Produtividade</TabsTrigger>
            <TabsTrigger value="performance">Desempenho</TabsTrigger>
            <TabsTrigger value="comparison">Comparação</TabsTrigger>
            <TabsTrigger value="goals">Metas</TabsTrigger>
          </TabsList>

          <TabsContent value="productivity" className="space-y-6">
            {/* Métricas Principais */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Ordens</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics.totalOrders}</div>
                  <p className="text-xs text-muted-foreground">
                    No período selecionado
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics.completionRate.toFixed(1)}%</div>
                  <p className="text-xs text-muted-foreground">
                    {metrics.completedOrders} de {metrics.totalOrders} ordens
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tempo Médio</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics.avgTimePerOrder.toFixed(0)}min</div>
                  <p className="text-xs text-muted-foreground">
                    Por ordem de serviço
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Crescimento</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {comparison.growth > 0 ? '+' : ''}{comparison.growth}%
                  </div>
                  <p className="text-xs text-muted-foreground">
                    vs. período anterior
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Top Performers */}
            <Card>
              <CardHeader>
                <CardTitle>Top Performers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {metrics.topPerformers.map((performer, index) => (
                    <div key={performer.name} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge variant={index === 0 ? "default" : "secondary"}>
                          #{index + 1}
                        </Badge>
                        <div>
                          <p className="font-medium">{performer.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {performer.avgTime.toFixed(0)} min/ordem em média
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold">{performer.orders}</div>
                        <div className="text-sm text-muted-foreground">ordens</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Análise de Desempenho Individual</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {uniqueEmployees.map(employee => {
                    const employeeOrders = getFilteredOrders().filter(o => o.employee === employee);
                    const completed = employeeOrders.filter(o => o.status === 'completed').length;
                    const rate = employeeOrders.length > 0 ? (completed / employeeOrders.length) * 100 : 0;
                    
                    return (
                      <div key={employee} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">{employee}</p>
                          <p className="text-sm text-muted-foreground">
                            {completed}/{employeeOrders.length} ordens concluídas
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold">{rate.toFixed(1)}%</div>
                          <div className="text-sm text-muted-foreground">eficiência</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="comparison" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Comparação de Períodos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Período Atual</h3>
                    <div className="text-2xl font-bold">{comparison.current}</div>
                    <p className="text-sm text-muted-foreground">ordens concluídas</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Período Anterior</h3>
                    <div className="text-2xl font-bold">{comparison.previous}</div>
                    <p className="text-sm text-muted-foreground">ordens concluídas</p>
                  </div>
                </div>
                
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="text-center">
                    <span className="text-lg font-bold">
                      {comparison.growth > 0 ? 'Crescimento' : 'Redução'} de {Math.abs(comparison.growth)}%
                    </span>
                    <br />
                    <span className="text-sm text-muted-foreground">
                      em relação ao período anterior
                    </span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Metas vs. Realizado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-8 border-2 border-dashed rounded-lg">
                    <Target className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium mb-2">Sistema de Metas</h3>
                    <p className="text-muted-foreground mb-4">
                      Configure metas de produtividade para acompanhar o desempenho da equipe
                    </p>
                    <Button onClick={() => navigate('/settings')}>
                      Configurar Metas
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <AiChatBubble context="Relatórios de produtividade e performance de funcionários" />
    </div>
  );
};

export default Reports;