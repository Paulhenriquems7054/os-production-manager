import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { NotificationTrigger } from '@/components/notifications/notification-trigger';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import { DashboardButtons } from '@/components/dashboard/dashboard-buttons';
import { NewOrderForm } from '@/components/orders/new-order-form';
import { EditOrderForm } from '@/components/orders/edit-order-form';
import { OrderList } from '@/components/orders/order-list';
import { BulkPDFGenerator } from '@/components/orders/bulk-pdf-generator';
import { QualityDashboard } from '@/components/quality/quality-dashboard';
import { MaterialsDashboard } from '@/components/materials/materials-dashboard';
import { InstallPrompt } from '@/components/pwa/install-prompt';
import { EmployeeFeedback } from '@/components/ai/employee-feedback';
import { MobileLayout } from '@/components/mobile/mobile-layout';
import { useServiceOrders } from '@/hooks/use-service-orders';
import { ServiceOrder } from '@/types/order';
import { Plus, FileText, Settings as SettingsIcon, BarChart3, ClipboardCheck, Package, FileSpreadsheet } from 'lucide-react';
import { Supervisor } from './Supervisor';
import { generateOrderPDF } from '@/utils/pdf-generator';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../App';
import { useProfile } from '@/hooks/use-profile';
import { AiChatBubble } from '@/components/chat/ai-chat-bubble';

function Index() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { userType, username, loading } = useProfile();
  const { toast } = useToast();
  const { orders, addOrder, updateOrder, deleteOrder } = useServiceOrders();
  
  const [isNewOrderOpen, setIsNewOrderOpen] = useState(false);
  const [isEditOrderOpen, setIsEditOrderOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<ServiceOrder | null>(null);
  const [showSupervisorDashboard, setShowSupervisorDashboard] = useState(false);
  const [activeTab, setActiveTab] = useState('orders');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      </div>
    );
  }

  const handleEditOrder = (order: ServiceOrder) => {
    setSelectedOrder(order);
    setIsEditOrderOpen(true);
  };

  const handleOrderSaved = (order: ServiceOrder) => {
    try {
      generateOrderPDF(order);
      toast({
        title: "Ordem salva",
        description: "PDF gerado com sucesso",
      });
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Ordem salva",
        description: "Ordem criada, mas houve erro na geração do PDF",
        variant: "destructive"
      });
    }
  };

  if (showSupervisorDashboard && userType === 'supervisor') {
    return (
      <Supervisor 
        username={username} 
        onBack={() => setShowSupervisorDashboard(false)} 
      />
    );
  }

  return (
    <MobileLayout>
      <DashboardHeader 
        userType={userType}
        username={username}
        onLogout={logout}
      />
      
      {/* Dashboard Overview Card para Admin */}
      {userType === 'admin' && (
        <div className="animate-fade-in">
          <div className="modern-card rounded-xl p-4 md:p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-lg md:text-xl font-bold gradient-text">Dashboard Administrativo</h2>
                <p className="text-sm text-muted-foreground">Acesso completo ao sistema</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <Button 
                variant="outline" 
                onClick={() => navigate('/analytics')}
                className="flex items-center gap-2 h-12 md:h-14 text-sm md:text-base button-hover glass-effect"
              >
                <BarChart3 className="w-5 h-5 icon-soft" />
                Analytics
              </Button>
              <Button 
                variant="outline" 
                onClick={() => navigate('/production')}
                className="flex items-center gap-2 h-12 md:h-14 text-sm md:text-base button-hover glass-effect"
              >
                <FileSpreadsheet className="w-5 h-5 icon-soft" />
                Produção
              </Button>
              <Button 
                variant="outline" 
                onClick={() => navigate('/settings')}
                className="flex items-center gap-2 h-12 md:h-14 text-sm md:text-base button-hover glass-effect"
              >
                <SettingsIcon className="w-5 h-5 icon-soft" />
                Configurações
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Dashboard Overview Card para Supervisor */}
      {userType === 'supervisor' && (
        <div className="animate-fade-in">
          <div className="modern-card rounded-xl p-4 md:p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-accent to-primary rounded-xl flex items-center justify-center">
                <ClipboardCheck className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-lg md:text-xl font-bold gradient-text">Painel Supervisão</h2>
                <p className="text-sm text-muted-foreground">Acesso restrito a funções supervisórias</p>
              </div>
            </div>
            <div className="text-center py-4">
              <p className="text-muted-foreground text-sm">
                Acesso limitado às funções básicas de supervisão.
                <br />
                Para funcionalidades avançadas, entre em contato com a administração.
              </p>
            </div>
          </div>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 animate-fade-in">
        <TabsList className={`grid w-full h-auto glass-effect rounded-xl p-1 ${userType === 'admin' ? 'grid-cols-2 md:grid-cols-4' : 'grid-cols-2 md:grid-cols-3'}`}>
          <TabsTrigger 
            value="orders" 
            className="text-xs md:text-sm px-2 py-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200 hover:bg-muted/50"
          >
            <Plus className="h-4 w-4 mr-1 md:mr-2 icon-soft" />
            <span className="hidden sm:inline">Ordens de Serviço</span>
            <span className="sm:hidden">Ordens</span>
          </TabsTrigger>
          <TabsTrigger 
            value="quality" 
            className="text-xs md:text-sm px-2 py-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200 hover:bg-muted/50"
          >
            <ClipboardCheck className="h-4 w-4 mr-1 md:mr-2 icon-soft" />
            <span className="hidden sm:inline">Controle de Qualidade</span>
            <span className="sm:hidden">Qualidade</span>
          </TabsTrigger>
          <TabsTrigger 
            value="materials" 
            className="text-xs md:text-sm px-2 py-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200 hover:bg-muted/50"
          >
            <Package className="h-4 w-4 mr-1 md:mr-2 icon-soft" />
            <span className="hidden sm:inline">Materiais</span>
            <span className="sm:hidden">Materiais</span>
          </TabsTrigger>
          {userType === 'admin' && (
            <TabsTrigger 
              value="ai-feedback" 
              className="text-xs md:text-sm px-2 py-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200 hover:bg-muted/50"
            >
              <BarChart3 className="h-4 w-4 mr-1 md:mr-2 icon-soft" />
              <span className="hidden sm:inline">IA Feedback</span>
              <span className="sm:hidden">IA</span>
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="orders" className="space-y-4">
          <Card className="animate-fade-in card-hover glass-effect">
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <CardTitle className="text-lg md:text-xl gradient-text">Ordens de Serviço</CardTitle>
                <div className="flex flex-col sm:flex-row gap-2">
                  <BulkPDFGenerator orders={orders} />
                  <Dialog open={isNewOrderOpen} onOpenChange={setIsNewOrderOpen}>
                    <DialogTrigger asChild>
                      <Button className="h-11 w-full sm:w-auto">
                        <Plus className="w-4 h-4 mr-2" />
                        Nova Ordem
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="w-[95vw] max-w-lg max-h-[90vh] flex flex-col">
                      <DialogHeader className="flex-shrink-0">
                        <DialogTitle>Nova Ordem de Serviço</DialogTitle>
                      </DialogHeader>
                      <div className="overflow-y-auto flex-1 px-1 -mx-1">
                        <NewOrderForm
                          onBack={() => setIsNewOrderOpen(false)}
                          onSave={async (orderData) => {
                            try {
                              const newOrder = await addOrder(orderData);
                              handleOrderSaved(newOrder);
                              setIsNewOrderOpen(false);
                              return newOrder;
                            } catch (error) {
                              console.error('Error creating order:', error);
                              throw error;
                            }
                          }}
                        />
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <OrderList orders={orders} onEditOrder={handleEditOrder} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quality" className="space-y-4 animate-fade-in">
          <QualityDashboard 
            orders={orders} 
            onUpdateOrder={(order) => updateOrder(order.id, order)}
          />
        </TabsContent>

        <TabsContent value="materials" className="space-y-4 animate-fade-in">
          <MaterialsDashboard />
        </TabsContent>

        {userType === 'admin' && (
          <TabsContent value="ai-feedback" className="space-y-4 animate-fade-in">
            <EmployeeFeedback />
          </TabsContent>
        )}
      </Tabs>

      {isEditOrderOpen && selectedOrder && (
        <Dialog open={isEditOrderOpen} onOpenChange={setIsEditOrderOpen}>
          <DialogContent className="w-[95vw] max-w-lg max-h-[90vh] flex flex-col">
            <DialogHeader className="flex-shrink-0">
              <DialogTitle className="text-lg">Editar Ordem de Serviço</DialogTitle>
            </DialogHeader>
            <div className="overflow-y-auto flex-1 px-1 -mx-1">
              <EditOrderForm
                order={selectedOrder}
                onBack={() => setIsEditOrderOpen(false)}
                onSave={async (id, updates) => {
                  try {
                    await updateOrder(id, updates);
                    setIsEditOrderOpen(false);
                  } catch (error) {
                    console.error('Error updating order:', error);
                  }
                }}
                onDelete={async (id) => {
                  try {
                    await deleteOrder(id);
                    setIsEditOrderOpen(false);
                  } catch (error) {
                    console.error('Error deleting order:', error);
                  }
                }}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
      
      <InstallPrompt />
    </MobileLayout>
  );
}

export default Index;