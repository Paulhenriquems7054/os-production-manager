import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Trash2, Key, Lock, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Auth() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Verificar se há um usuário logado ao carregar a página
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setCurrentUser(parsedUser);
      } catch (error) {
        localStorage.removeItem('user');
      }
    }
  }, []);


  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
    department: ''
  });

  const [signupData, setSignupData] = useState({
    password: '',
    confirmPassword: '',
    fullName: '',
    department: 'supervisão'
  });

  const [resetData, setResetData] = useState({
    username: '',
    newPassword: ''
  });

  const [deleteData, setDeleteData] = useState({
    username: '',
    password: ''
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {

      // Primeiro tentar login com tabela usuarios (sistema legado)
      const { data: usuarios, error: usuariosError } = await supabase
        .from('usuarios')
        .select('*');

      if (!usuariosError && usuarios && usuarios.length > 0) {
        const user = usuarios.find(u => {
          if (!u.nome || !u.senha) return false;
          
          const senhaMatch = u.senha.trim() === loginData.password.trim();
          const inputUsername = loginData.username.toLowerCase().trim();
          const userNome = u.nome.toLowerCase().trim();
          
          // Verifica se a senha está correta primeiro
          if (!senhaMatch) return false;
          
          // Verifica várias formas de match do nome (mais flexível)
          const nomeCompleto = userNome === inputUsername;
          const primeiroNome = userNome.split(' ')[0] === inputUsername;
          const contemNome = userNome.includes(inputUsername);
          const inputContemNome = inputUsername.includes(userNome.split(' ')[0]);
          const primeiroUltimoNome = inputUsername.includes(userNome.split(' ')[0]) && 
                                    inputUsername.includes(userNome.split(' ').pop() || '');
          const palavrasIguais = inputUsername.split(' ').some(palavra => 
            userNome.split(' ').includes(palavra) && palavra.length > 2);
          
          const match = nomeCompleto || primeiroNome || contemNome || inputContemNome || 
                       primeiroUltimoNome || palavrasIguais;
          
          return match;
        });
        
        if (user) {
          const userData = {
            id: user.id,
            name: user.nome,
            role: user.role || 'user',
            department: user.departamento || 'geral'
          };
          
          localStorage.setItem('user', JSON.stringify(userData));
          window.dispatchEvent(new Event('userLoggedIn'));
          
          toast({
            title: "Login realizado com sucesso!",
            description: "Bem-vindo de volta.",
          });
          
          setTimeout(() => navigate('/'), 100);
          return;
        }
      }

      // Segundo, tentar login com tabela profiles (para usuários criados via Auth)
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*');

      if (!profilesError && profiles && profiles.length > 0) {
        const profile = profiles.find(p => {
          if (!p.nome_completo || !p.senha_hash) return false;
          
          const senhaMatch = p.senha_hash.trim() === loginData.password.trim();
          const inputUsername = loginData.username.toLowerCase().trim();
          const userNome = p.nome_completo.toLowerCase().trim();
          
          // Verifica se a senha está correta primeiro
          if (!senhaMatch) return false;
          
          // Verifica várias formas de match do nome (mais flexível)
          const nomeCompleto = userNome === inputUsername;
          const primeiroNome = userNome.split(' ')[0] === inputUsername;
          const contemNome = userNome.includes(inputUsername);
          const inputContemNome = inputUsername.includes(userNome.split(' ')[0]);
          const primeiroUltimoNome = inputUsername.includes(userNome.split(' ')[0]) && 
                                    inputUsername.includes(userNome.split(' ').pop() || '');
          const palavrasIguais = inputUsername.split(' ').some(palavra => 
            userNome.split(' ').includes(palavra) && palavra.length > 2);
          
          const match = nomeCompleto || primeiroNome || contemNome || inputContemNome || 
                       primeiroUltimoNome || palavrasIguais;
          
          return match;
        });

        if (profile) {
          const userData = {
            id: profile.id,
            name: profile.nome_completo,
            role: profile.role || 'user',
            department: profile.department || 'geral'
          };
          
          localStorage.setItem('user', JSON.stringify(userData));
          window.dispatchEvent(new Event('userLoggedIn'));
          
          toast({
            title: "Login realizado com sucesso!",
            description: "Bem-vindo de volta.",
          });
          
          setTimeout(() => navigate('/'), 100);
          return;
        }
      }
      
      setError('Usuário ou senha incorretos. Verifique suas credenciais.');
    } catch (err) {
      console.error('Erro no login:', err);
      setError('Erro interno do servidor. Verifique se os dados do Supabase estão corretos.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    if (signupData.password !== signupData.confirmPassword) {
      setError('As senhas não coincidem');
      setIsLoading(false);
      return;
    }

    if (signupData.password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres');
      setIsLoading(false);
      return;
    }

    if (!signupData.department) {
      setError('Selecione um departamento');
      setIsLoading(false);
      return;
    }

    try {
      // Verificar se o usuário já existe na tabela profiles
      const { data: existingProfiles } = await supabase
        .from('profiles')
        .select('nome_completo')
        .eq('nome_completo', signupData.fullName);

      if (existingProfiles && existingProfiles.length > 0) {
        setError('Usuário já cadastrado com este nome');
        setIsLoading(false);
        return;
      }

      // Verificar se o usuário já existe na tabela usuarios
      const { data: existingUsuarios } = await supabase
        .from('usuarios')
        .select('nome')
        .eq('nome', signupData.fullName);

      if (existingUsuarios && existingUsuarios.length > 0) {
        setError('Usuário já cadastrado com este nome');
        setIsLoading(false);
        return;
      }

      // Determinar role baseado no departamento
      const role = signupData.department === 'administração' || signupData.department === 'desenvolvedor' ? 'admin' : 
                   signupData.department === 'supervisão' ? 'supervisor' : 'user';

      // Criar usuário na tabela profiles
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          nome_completo: signupData.fullName,
          department: signupData.department,
          role: role,
          senha_hash: signupData.password
        });

      if (profileError) {
        console.error('Erro ao criar perfil:', profileError);
        setError('Erro ao criar usuário: ' + profileError.message);
        setIsLoading(false);
        return;
      }

      toast({
        title: "Cadastro realizado!",
        description: `Usuário ${signupData.fullName} criado com sucesso!`,
      });
      
      // Limpar formulário
      setSignupData({
        password: '',
        confirmPassword: '',
        fullName: '',
        department: 'supervisão'
      });
    } catch (err) {
      console.error('Erro no cadastro:', err);
      setError('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!resetData.username) {
      setError('Digite o nome de usuário');
      return;
    }

    if (!resetData.newPassword) {
      setError('Digite a nova senha');
      return;
    }

    if (resetData.newPassword.length < 6) {
      setError('A nova senha deve ter pelo menos 6 caracteres');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Buscar usuário na tabela usuarios
      const { data: usuarios, error: userError } = await supabase
        .from('usuarios')
        .select('*');
      
      const user = usuarios?.find(u => 
        u.nome && u.nome.toLowerCase().trim() === resetData.username.toLowerCase().trim()
      );

      if (userError || !user) {
        setError('Usuário não encontrado');
        setIsLoading(false);
        return;
      }

      // Atualizar com nova senha
      const { error } = await supabase
        .from('usuarios')
        .update({ senha: resetData.newPassword })
        .eq('id', user.id);

      if (error) {
        setError('Erro ao alterar senha: ' + error.message);
      } else {
        toast({
          title: "Senha alterada!",
          description: "Sua senha foi alterada com sucesso.",
        });
        setResetData({ username: '', newPassword: '' });
      }
    } catch (err) {
      setError('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };


  const handleDeleteAccount = async () => {
    if (!deleteData.username || !deleteData.password) {
      setError('Preencha todos os campos');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Buscar usuário na tabela usuarios
      const { data: usuarios, error: userError } = await supabase
        .from('usuarios')
        .select('*');
      
      const user = usuarios?.find(u => 
        u.nome && u.nome.toLowerCase().trim() === deleteData.username.toLowerCase().trim()
      );

      if (userError || !user) {
        setError('Usuário não encontrado');
        setIsLoading(false);
        return;
      }

      // Verificar senha
      if (deleteData.password !== user.senha) {
        setError('Senha incorreta');
        setIsLoading(false);
        return;
      }

      // Excluir usuário
      const { error } = await supabase
        .from('usuarios')
        .delete()
        .eq('id', user.id);

      if (error) {
        setError('Erro ao excluir conta: ' + error.message);
      } else {
        toast({
          title: "Conta excluída!",
          description: "Sua conta foi excluída com sucesso.",
        });
        setDeleteData({ username: '', password: '' });
      }
    } catch (err) {
      setError('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <div className="w-full max-w-md">

        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <img 
                src="/lovable-uploads/6f4ef23e-e536-4a5f-b3e6-6fdbaee548f8.png" 
                alt="DClamps Equipamentos" 
                className="h-16 w-auto"
              />
            </div>
            <CardTitle className="text-2xl font-bold">Gestão de Produção</CardTitle>
            <CardDescription>
              Acesse sua conta ou crie uma nova
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Entrar</TabsTrigger>
                <TabsTrigger value="signup">
                  Cadastrar
                </TabsTrigger>
              </TabsList>

              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Nome de Usuário</Label>
                    <Input
                      id="username"
                      type="text"
                      value={loginData.username}
                      onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                      placeholder="Digite seu nome completo"
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input
                      id="password"
                      type="password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                      placeholder="Digite sua senha"
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Entrar
                  </Button>
                  
                  {/* Botão Esqueci a Senha */}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" className="w-full mt-2" disabled={isLoading}>
                        <Key className="mr-2 h-4 w-4" />
                        Esqueci a senha
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Resetar Senha</AlertDialogTitle>
                        <AlertDialogDescription>
                          Digite seu nome de usuário para resetar a senha.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                       <div className="space-y-4 py-4">
                         <div className="space-y-2">
                           <Label htmlFor="resetUsername">Nome de Usuário</Label>
                           <Input
                             id="resetUsername"
                             type="text"
                             value={resetData.username}
                             onChange={(e) => setResetData({...resetData, username: e.target.value})}
                             placeholder="Digite seu nome completo"
                           />
                         </div>
                         <div className="space-y-2">
                           <Label htmlFor="newPassword">Nova Senha</Label>
                           <Input
                             id="newPassword"
                             type="password"
                             value={resetData.newPassword}
                             onChange={(e) => setResetData({...resetData, newPassword: e.target.value})}
                             placeholder="Digite a nova senha (mín. 6 caracteres)"
                             minLength={6}
                           />
                         </div>
                       </div>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={handleForgotPassword}>
                          Resetar Senha
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <div className="mt-4">
                  {/* Autorização para cadastro */}
                  <div className="p-4 border rounded-lg bg-muted/20">
                    <h3 className="font-semibold text-sm mb-2 flex items-center">
                      <Shield className="mr-2 h-4 w-4" />
                      Autorização Necessária
                    </h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Clique no botão abaixo para inserir as credenciais de administrador e acessar o cadastro de usuários.
                    </p>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" className="w-full">
                          <Lock className="mr-2 h-4 w-4" />
                          Autorizar Acesso
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Autorização de Administrador</AlertDialogTitle>
                          <AlertDialogDescription>
                            Insira as credenciais de administrador para acessar o cadastro de usuários.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="adminUser">Usuário Admin</Label>
                            <Input
                              id="adminUser"
                              type="text"
                              placeholder="Digite o usuário admin"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="adminPassword">Senha Admin</Label>
                            <Input
                              id="adminPassword"
                              type="password"
                              placeholder="Digite a senha admin"
                            />
                          </div>
                        </div>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction>
                            Autorizar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}