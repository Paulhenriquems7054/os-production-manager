
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download, FileText, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ProductionSummary } from '@/components/analytics/production-summary';
import { ProductionChart } from '@/components/analytics/production-chart';
import { EmployeePerformanceChart } from '@/components/analytics/employee-performance-chart';
import { ServiceDistributionChart } from '@/components/analytics/service-distribution-chart';
import { useProduction } from '@/hooks/use-production';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { generateProductionReportPDF } from '@/utils/pdf-generator';
import { AiChatBubble } from '@/components/chat/ai-chat-bubble';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import { MobileLayout } from '@/components/mobile/mobile-layout';
import { useAuth } from '../App';
import { useProfile } from '@/hooks/use-profile';

const Analytics = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { userType, username, loading: profileLoading } = useProfile();
  const { records, stats, loading, error, lastSync, syncData, isConnected } = useProduction();
  const { toast } = useToast();

  if (profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      </div>
    );
  }

  const handleExportPDF = async () => {
    if (records.length === 0) {
      toast({
        title: "Nenhum registro encontrado",
        description: "Aguarde a sincronização com Google Sheets",
        variant: "destructive"
      });
      return;
    }
    
    try {
      console.log('🔧 Iniciando geração de PDF para Analytics com', records.length, 'registros');
      
      // Show loading toast
      toast({
        title: "Gerando relatório...",
        description: "Por favor, aguarde...",
        variant: "default"
      });
      
      await generateProductionReportPDF(records);
      
      // Success toast only after PDF is actually generated
      toast({
        title: "Relatório gerado com sucesso",
        description: `PDF com ${records.length} registros foi baixado`,
        variant: "default"
      });
    } catch (error) {
      console.error('❌ Erro ao gerar PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Ocorreu um erro durante a geração do relatório",
        variant: "destructive"
      });
    }
  };

  const handleExportCSV = () => {
    if (records.length === 0) {
      toast({
        title: "Nenhum registro encontrado",
        description: "Aguarde a sincronização com Google Sheets",
        variant: "destructive"
      });
      return;
    }

    const csvHeaders = [
      'Data/Hora', 'Executante', 'Função', 'Supervisor',
      'Suspensor TC1A', 'Suspensor T16', 'Anel Suspensor', 'Luva', 'Niple Longo',
      'Difusor', 'Packer', 'Válvula Dreno', 'Válvula Check', 'Desareador',
      'Tubo Filtro', 'Acoplamentos', 'Cabeça Descarga', 'Outro Serviço',
      'Fará Outro Serviço', 'Observações'
    ].join(',');
    
    const csvData = records.map(record => [
      record.timestamp,
      record.executante,
      record.funcao,
      record.supervisor,
      record.suspensorTC1A,
      record.suspensorT16,
      record.anelSuspensor,
      record.luva,
      record.nipleLongo,
      record.difusor,
      record.packer,
      record.valvulaDreno,
      record.valvulaCheck,
      record.desareador,
      record.tuboFiltro,
      record.acoplamentos,
      record.cabecaDescarga,
      record.outroServico,
      record.colaboradorOutroServico,
      record.observacoes
    ].map(field => `"${field}"`).join(','));
    
    const csvContent = [csvHeaders, ...csvData].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `producao-${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    toast({
      title: "CSV exportado",
      description: `Arquivo CSV com ${records.length} registros baixado`,
      variant: "default"
    });
  };

  const handleSync = () => {
    syncData();
    toast({
      title: "Sincronização iniciada",
      description: "Atualizando dados do Google Sheets...",
      variant: "default"
    });
  };

  return (
    <MobileLayout>
      <DashboardHeader 
        userType={userType}
        username={username}
        onLogout={logout}
      />
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <Button variant="outline" size="sm" onClick={() => navigate('/')} className="w-fit">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Análise de Produção</h1>
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mt-1">
              <Badge variant={isConnected ? "default" : "destructive"}>
                {isConnected ? "Google Sheets Conectado" : "Desconectado"}
              </Badge>
              {lastSync && (
                <span className="text-sm text-muted-foreground">
                  Última sync: {lastSync.toLocaleTimeString('pt-BR')}
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" size="sm" onClick={handleSync} disabled={loading} className="w-full sm:w-auto">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Sincronizar
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="w-full sm:w-auto">
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportPDF} className="w-full sm:w-auto">
            <FileText className="w-4 h-4 mr-2" />
            Relatório PDF
          </Button>
        </div>
      </div>

      {error && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-lg mb-6">
          <p className="font-medium">Erro de Conexão</p>
          <p className="text-sm">{error}</p>
        </div>
      )}
      
      <ProductionSummary records={records} stats={stats} loading={loading} />
      
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-6">
        <ProductionChart stats={stats} loading={loading} />
        <EmployeePerformanceChart stats={stats} loading={loading} />
      </div>
      
      <ServiceDistributionChart stats={stats} loading={loading} />

      <AiChatBubble context="Dados de analytics e produção da empresa" />
    </MobileLayout>
  );
};

export default Analytics;
