import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { NotificationSettingsComponent } from '@/components/notifications/notification-settings';
import { useNotifications } from '@/hooks/use-notifications';
import { useNavigate } from 'react-router-dom';
import { Settings as SettingsIcon, ArrowLeft } from 'lucide-react';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import { MobileLayout } from '@/components/mobile/mobile-layout';
import { useAuth } from '../App';
import { useProfile } from '@/hooks/use-profile';

export default function Settings() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { userType, username, loading } = useProfile();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      </div>
    );
  }
  const { settings, updateSettings } = useNotifications();

  return (
    <MobileLayout>
      <DashboardHeader 
        userType={userType}
        username={username}
        onLogout={logout}
      />
      
      <div className="flex items-center gap-3 mb-6">
        <Button variant="outline" size="sm" onClick={() => navigate('/')} className="w-fit">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>
      </div>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            <SettingsIcon className="h-6 w-6 md:h-8 md:w-8" />
            Configurações
          </h1>
          <p className="text-muted-foreground">
            Configure as preferências do sistema de produção
          </p>
        </div>

        <NotificationSettingsComponent
          settings={settings}
          onUpdateSettings={updateSettings}
        />

        <Card>
          <CardHeader>
            <CardTitle>Informações do Sistema</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Versão:</span> 1.0.0
              </div>
              <div>
                <span className="font-medium">Ambiente:</span> Produção
              </div>
              <div>
                <span className="font-medium">PWA:</span> Ativo
              </div>
              <div>
                <span className="font-medium">Offline:</span> Suportado
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MobileLayout>
  );
}