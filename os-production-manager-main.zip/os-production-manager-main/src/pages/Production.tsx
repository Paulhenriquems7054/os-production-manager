import * as React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ProductionForm } from '@/components/production/production-form';
import { ProductionTable } from '@/components/production/production-table';
import { MobileProductionTable } from '@/components/mobile/mobile-production-table';
import { MobileLayout } from '@/components/mobile/mobile-layout';
import { useProductionRecords } from '@/hooks/use-production-records';
import { ProductionRecord } from '@/types/production';
import { Plus, FileSpreadsheet, Download, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import { useAuth } from '../App';
import { useProfile } from '@/hooks/use-profile';
import { useIsMobile } from '@/hooks/use-mobile';

export default function Production() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { userType, username, loading: profileLoading } = useProfile();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<ProductionRecord | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  
  const { records, addRecord, deleteRecord, loading, error } = useProductionRecords();
  const { toast } = useToast();
  const isMobile = useIsMobile();

  // Debug logs
  console.log('🔍 Production Page - User:', user);
  console.log('🔍 Production Page - Records:', records);
  console.log('🔍 Production Page - Loading:', loading, 'Error:', error);
  console.log('🔍 Production Page - Profile Loading:', profileLoading);

  if (profileLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-xl font-semibold text-destructive">Erro ao carregar produção</h2>
          <p className="text-muted-foreground">{error}</p>
          <Button onClick={() => window.location.reload()}>
            Tentar novamente
          </Button>
        </div>
      </div>
    );
  }

  const handleSaveRecord = (formData: any) => {
    addRecord(formData);
    setIsFormOpen(false);
    toast({
      title: "Registro salvo",
      description: "Novo registro de produção criado com sucesso",
    });
  };

  const handleViewRecord = (record: ProductionRecord) => {
    setSelectedRecord(record);
    setIsViewDialogOpen(true);
  };

  const handleDeleteRecord = (id: string) => {
    deleteRecord(id);
    toast({
      title: "Registro excluído",
      description: "Registro removido com sucesso",
    });
  };

  const exportToCSV = () => {
    const headers = [
      'Data', 'Executante', 'Função', 'Supervisor', 'Serviços',
      'Observações'
    ];

    const csvContent = [
      headers.join(','),
      ...records.map(record => [
        record.timestamp,
        record.executante,
        record.funcao,
        record.supervisor,
        [record.suspensorTC1A, record.suspensorT16, record.anelSuspensor, record.luva, record.nipleLongo].filter(Boolean).join('; '),
        record.observacoes || ''
      ].map(field => `"${field}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `producao_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();

    toast({
      title: "Exportação concluída",
      description: "Planilha exportada com sucesso",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userType={userType}
        username={username}
        onLogout={logout}
      />
      <MobileLayout>
        <div className={isMobile ? "flex flex-col gap-4" : "flex items-center justify-between"}>
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Button variant="outline" size="sm" onClick={() => navigate('/')}>
                <ArrowLeft className="w-4 h-4" />
                {!isMobile && "Voltar"}
              </Button>
            </div>
            <h1 className={isMobile ? "text-2xl font-bold" : "text-3xl font-bold"}>
              Planilha de Produção
            </h1>
            <p className="text-muted-foreground">
              Controle de serviços e peças produzidas
            </p>
          </div>
          <div className={isMobile ? "flex flex-col gap-2" : "flex gap-2"}>
            <Button onClick={exportToCSV} variant="outline" size={isMobile ? "sm" : "default"}>
              <Download className="w-4 h-4 mr-2" />
              {isMobile ? "CSV" : "Exportar CSV"}
            </Button>
            <Button onClick={() => setIsFormOpen(true)} size={isMobile ? "sm" : "default"}>
              <Plus className="w-4 h-4 mr-2" />
              Novo Registro
            </Button>
          </div>
        </div>

        {isMobile ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5" />
                Registros
              </h2>
              <div className="text-sm text-muted-foreground">
                {records.length} registros
              </div>
            </div>
            <MobileProductionTable
              records={records}
              onView={handleViewRecord}
              onDelete={handleDeleteRecord}
            />
          </div>
        ) : (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5" />
                  Registros de Produção
                </CardTitle>
                <div className="text-sm text-muted-foreground">
                  Total: {records.length} registros
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ProductionTable
                records={records}
                onView={handleViewRecord}
                onDelete={handleDeleteRecord}
              />
            </CardContent>
          </Card>
        )}

        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogContent className={isMobile ? "max-w-[95vw] max-h-[90vh] overflow-y-auto" : "max-w-4xl max-h-[90vh] overflow-y-auto"}>
            <DialogHeader>
              <DialogTitle className={isMobile ? "text-lg" : ""}>
                Novo Registro de Produção
              </DialogTitle>
            </DialogHeader>
            <ProductionForm
              onSave={handleSaveRecord}
              onCancel={() => setIsFormOpen(false)}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className={isMobile ? "max-w-[95vw]" : "max-w-2xl"}>
            <DialogHeader>
              <DialogTitle className={isMobile ? "text-lg" : ""}>
                Detalhes do Registro
              </DialogTitle>
            </DialogHeader>
            {selectedRecord && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <strong>Data:</strong> {selectedRecord.timestamp}
                  </div>
                  <div>
                    <strong>Executante:</strong> {selectedRecord.executante}
                  </div>
                  <div>
                    <strong>Função:</strong> {selectedRecord.funcao}
                  </div>
                  <div>
                    <strong>Supervisor:</strong> {selectedRecord.supervisor}
                  </div>
                </div>

                {selectedRecord.observacoes && (
                  <div>
                    <strong>Observações:</strong>
                    <p className="mt-1 text-sm">{selectedRecord.observacoes}</p>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </MobileLayout>
    </div>
  );
}