import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useServiceOrders } from '@/hooks/use-service-orders';
import { ServiceOrder } from '@/types/order';
import { Clock, CheckCircle, AlertTriangle, Users, Activity, TrendingUp, ArrowLeft, BarChart3 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SupervisorProps {
  username: string;
  onBack: () => void;
}

export const Supervisor = ({ username, onBack }: SupervisorProps) => {
  const navigate = useNavigate();
  const { orders, updateOrder } = useServiceOrders();
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState('dashboard');

  // Calcular estatísticas em tempo real
  const pendingOrders = orders.filter(order => order.status === 'active');
  const completedToday = orders.filter(order => {
    const today = new Date().toDateString();
    const orderDate = new Date(order.createdAt).toDateString();
    return order.status === 'completed' && orderDate === today;
  });

  const avgTimePerOrder = completedToday.length > 0 
    ? completedToday.reduce((acc, order) => {
        if (order.startTime && order.endTime) {
          const start = new Date(`2000-01-01T${order.startTime}`);
          const end = new Date(`2000-01-01T${order.endTime}`);
          return acc + (end.getTime() - start.getTime());
        }
        return acc;
      }, 0) / completedToday.length / (1000 * 60) // em minutos
    : 0;

  const handleApproveOrder = (orderId: string) => {
    updateOrder(orderId, { 
      status: 'completed',
      approvedBy: username,
      approvedAt: new Date().toISOString()
    });
    toast({
      title: "Ordem Aprovada",
      description: "Ordem de serviço aprovada com sucesso",
    });
  };

  const handleRejectOrder = (orderId: string) => {
    updateOrder(orderId, { 
      status: 'active', // Retorna para ativo para correção
      rejectedBy: username,
      rejectedAt: new Date().toISOString()
    });
    toast({
      title: "Ordem Rejeitada",
      description: "Ordem retornada para correção",
      variant: "destructive"
    });
  };

  const getEmployeeStats = () => {
    const employeeMap = new Map();
    
    orders.forEach(order => {
      if (!employeeMap.has(order.employee)) {
        employeeMap.set(order.employee, {
          name: order.employee,
          total: 0,
          completed: 0,
          inProgress: 0
        });
      }
      
      const stats = employeeMap.get(order.employee);
      stats.total++;
      
      if (order.status === 'completed') stats.completed++;
      if (order.status === 'active') stats.inProgress++;
    });
    
    return Array.from(employeeMap.values());
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-6xl mx-auto p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Dashboard do Supervisor</h1>
                <p className="text-muted-foreground">Bem-vindo, {username}</p>
              </div>
            </div>
            <Badge variant="secondary">Supervisor</Badge>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="approvals">Aprovações</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoramento</TabsTrigger>
            <TabsTrigger value="reports">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Cards de Estatísticas */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ordens Pendentes</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{pendingOrders.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Aguardando aprovação
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Concluídas Hoje</CardTitle>
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{completedToday.length}</div>
                  <p className="text-xs text-muted-foreground">
                    +{Math.round((completedToday.length / orders.length) * 100)}% do total
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tempo Médio</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{Math.round(avgTimePerOrder)}min</div>
                  <p className="text-xs text-muted-foreground">
                    Por ordem de serviço
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Funcionários Ativos</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{getEmployeeStats().length}</div>
                  <p className="text-xs text-muted-foreground">
                    Trabalhando hoje
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Lista de Ordens Pendentes */}
            <Card>
              <CardHeader>
                <CardTitle>Ordens Aguardando Aprovação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pendingOrders.slice(0, 5).map(order => (
                    <div key={order.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">#{order.id}</Badge>
                          <span className="font-medium">{order.employee}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {order.piece} - {order.serviceName}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleRejectOrder(order.id)}
                        >
                          Rejeitar
                        </Button>
                        <Button 
                          size="sm"
                          onClick={() => handleApproveOrder(order.id)}
                        >
                          Aprovar
                        </Button>
                      </div>
                    </div>
                  ))}
                  {pendingOrders.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">
                      Nenhuma ordem pendente
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="approvals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Centro de Aprovações</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingOrders.map(order => (
                    <div key={order.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge>#{order.id}</Badge>
                            <span className="font-semibold">{order.employee}</span>
                          </div>
                          <div className="text-sm space-y-1">
                            <p><strong>Peça:</strong> {order.piece}</p>
                            <p><strong>Serviço:</strong> {order.serviceName}</p>
                            <p><strong>Quantidade:</strong> {order.quantity}</p>
                            <p><strong>Horário:</strong> {order.startTime} - {order.endTime}</p>
                            {order.observations && (
                              <p><strong>Observações:</strong> {order.observations}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Button 
                            size="sm"
                            onClick={() => handleApproveOrder(order.id)}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Aprovar
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => handleRejectOrder(order.id)}
                          >
                            <AlertTriangle className="w-4 h-4 mr-1" />
                            Rejeitar
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monitoramento em Tempo Real</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {getEmployeeStats().map(employee => (
                    <div key={employee.name} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {employee.completed} concluídas, {employee.inProgress} em andamento
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={employee.inProgress > 0 ? "default" : "secondary"}>
                          <Activity className="w-3 h-3 mr-1" />
                          {employee.inProgress > 0 ? "Ativo" : "Parado"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios do Supervisor</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <Button 
                    variant="outline" 
                    className="h-20 flex-col"
                    onClick={() => navigate('/analytics')}
                  >
                    <BarChart3 className="w-6 h-6 mb-2" />
                    Análise Completa
                  </Button>
                  <Button 
                    variant="outline" 
                    className="h-20 flex-col"
                    onClick={() => {
                      // Implementar relatório de produtividade
                      toast({
                        title: "Em Desenvolvimento",
                        description: "Relatório de produtividade em breve",
                      });
                    }}
                  >
                    <TrendingUp className="w-6 h-6 mb-2" />
                    Produtividade
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};