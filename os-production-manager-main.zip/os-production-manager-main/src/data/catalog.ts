export interface ServiceOption {
  id: string;
  name: string;
}

export interface PieceCategory {
  id: string;
  name: string;
  pieces: string[];
  services: ServiceOption[];
}

export const productionCatalog: PieceCategory[] = [
  {
    id: 'group1',
    name: 'Grupo 1',
    pieces: [
      'Suspensor TC1A',
      'Suspensor T16', 
      'Anel para suspensor',
      'Luva',
      'Niple Longo'
    ],
    services: [
      { id: 'fabricar_completa', name: 'Fabricar peça completa' },
      { id: 'furacao', name: 'Furação do material' },
      { id: 'aproximacao_diametro', name: 'Aproximação do diâmetro interno' },
      { id: 'rosca_um_lado', name: 'Abrir rosca de um lado' },
      { id: 'facear_externa', name: 'Facear parte externa' },
      { id: 'facear_ambas', name: 'Facear parte interna e externa' },
      { id: 'rosca_dois_lados', name: 'Abrir rosca dos dois lados' }
    ]
  },
  {
    id: 'group2',
    name: 'Grupo 2', 
    pieces: [
      'Difusor',
      'Packer',
      'Válvula Dreno',
      'Válvula Check',
      'Desareador'
    ],
    services: [
      { id: 'fabricar_completa', name: 'Fabricar peça completa' },
      { id: 'furacao', name: 'Furação do material' },
      { id: 'aproximacao_diametro', name: 'Aproximação do diâmetro interno' },
      { id: 'rosca_interna', name: 'Abrir rosca interna' },
      { id: 'rosca_externa', name: 'Abrir rosca externa' },
      { id: 'facear_externa', name: 'Facear parte externa' },
      { id: 'facear_ambas', name: 'Facear parte interna e externa' },
      { id: 'perfuracao_peca', name: 'Fazer perfuração da peça' },
      { id: 'faceamento_fresa', name: 'Faceamento externo com fresa' },
      { id: 'complemento_peca', name: 'Complemento da peça' }
    ]
  },
  {
    id: 'tubo_filtro',
    name: 'Tubo Filtro',
    pieces: ['Tubo Filtro'],
    services: [
      { id: 'abrir_canais', name: 'Abrir canais para passagem de óleo' },
      { id: 'rosca_tubo_filtro', name: 'Abrir rosca Tubo Filtro 2 7/8" (interno e externo)' },
      { id: 'usinar_luva_3_5', name: 'Usinar Luva 3 1/2" Tubo Filtro' },
      { id: 'usinar_luva_2_7_8', name: 'Usinar Luva 2 7/8" Tubo Filtro' },
      { id: 'fabricar_tampao', name: 'Fabricar tampão para luvas de Tubo Filtro' },
      { id: 'rosca_reducao', name: 'Abrir rosca do Tubo de Redução' }
    ]
  },
  {
    id: 'outros',
    name: 'Outros Componentes',
    pieces: [
      'Acoplamentos',
      'Cabeça de descarga'
    ],
    services: [
      { id: 'fabricar_completa', name: 'Fabricar peça completa' },
      { id: 'furacao', name: 'Furação do material' },
      { id: 'aproximacao_diametro', name: 'Aproximação do diâmetro interno' },
      { id: 'rosca_interna', name: 'Abrir rosca interna' },
      { id: 'rosca_externa', name: 'Abrir rosca externa' },
      { id: 'facear_externa', name: 'Facear parte externa' },
      { id: 'facear_interna_externa', name: 'Facear parte interna ou externa' },
      { id: 'perfuracao_peca', name: 'Fazer perfuração da peça' },
      { id: 'faceamento_fresa', name: 'Faceamento externo com fresa' },
      { id: 'complemento_peca', name: 'Complemento da peça' }
    ]
  }
];