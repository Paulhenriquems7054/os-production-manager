import React, { Suspense, lazy, useState, createContext, useContext, useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import { AiChatBubble } from '@/components/chat/ai-chat-bubble';
import { SplashScreen } from '@/components/splash/splash-screen';
import { OnboardingScreen } from '@/components/onboarding/onboarding-screen';
import { FloatingNav } from '@/components/navigation/floating-nav';
import { ThemeToggle } from '@/components/theme/theme-toggle';


const Analytics = lazy(() => import('./pages/Analytics'));
const Settings = lazy(() => import('./pages/Settings'));
const Reports = lazy(() => import('./pages/Reports'));
const Production = lazy(() => import('./pages/Production'));

type LocalUser = {
  id: string;
  name: string;
  role: string;
  department: string;
};

type AuthContextType = {
  user: LocalUser | null;
  session: Session | null;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

const queryClient = new QueryClient();

function App() {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [showSplash, setShowSplash] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check localStorage for existing user session
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
      } catch (error) {
        localStorage.removeItem('user');
      }
    }
    
    setLoading(false);
  }, []);

  // Listen for storage changes (when user logs in from another tab/window)
  useEffect(() => {
    const handleStorageChange = () => {
      const savedUser = localStorage.getItem('user');
      if (savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser);
          setUser(parsedUser);
        } catch (error) {
          localStorage.removeItem('user');
          setUser(null);
        }
      } else {
        setUser(null);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    // Also listen for custom event when login happens in same window
    window.addEventListener('userLoggedIn', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('userLoggedIn', handleStorageChange);
    };
  }, []);

  const logout = async () => {
    localStorage.removeItem('user');
    setUser(null);
    setSession(null);
  };

  // Mostrar splash screen primeiro
  if (showSplash) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <SplashScreen onComplete={() => {
            setShowSplash(false);
            // Verificar se já viu o onboarding
            const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
            if (!hasSeenOnboarding) {
              setShowOnboarding(true);
            }
          }} />
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  // Mostrar onboarding para novos usuários
  if (showOnboarding) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <OnboardingScreen onComplete={() => {
            setShowOnboarding(false);
            localStorage.setItem('hasSeenOnboarding', 'true');
          }} />
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  // Mostrar loading enquanto verifica autenticação
  if (loading) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted">
            <div className="text-center space-y-4">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground animate-pulse">Carregando...</p>
            </div>
          </div>
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        
        <AuthContext.Provider value={{ user, session, logout }}>
          <BrowserRouter>
            <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 transition-colors duration-300">
              <Suspense fallback={
                <div className="min-h-screen flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                    <p className="text-muted-foreground animate-pulse">Carregando...</p>
                  </div>
                </div>
              }>
                <Routes>
                  <Route path="/auth" element={<Auth />} />
                  {user ? (
                    <>
                      <Route path="/" element={<Index />} />
                      {user.role === 'admin' && (
                        <>
                          <Route path="/analytics" element={<Analytics />} />
                          <Route path="/settings" element={<Settings />} />
                          <Route path="/production" element={<Production />} />
                        </>
                      )}
                      <Route path="/reports" element={<Reports />} />
                    </>
                  ) : (
                    <Route path="*" element={<Auth />} />
                  )}
                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Suspense>
            </div>
            {user && user.role === 'admin' && (
              <>
                <AiChatBubble />
              </>
            )}
            <Toaster />
            <SonnerToaster />
          </BrowserRouter>
        </AuthContext.Provider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;